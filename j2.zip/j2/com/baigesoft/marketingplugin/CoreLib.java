package com.baigesoft.marketingplugin;

import android.content.Context;
import android.util.Log;

import com.baigesoft.marketingplugin.utils.LogUtils;

import java.io.File;

import dalvik.system.DexClassLoader;

/**
 * Created by Dawei on 05/09/2017.
 */

public class CoreLib {

    private static final String TAG = "CoreLib";

    private ClassLoader classLoader;

    private DexClassLoader dexClassLoader;

    public native DexClassLoader loadCore(Context context, String optimizedDir, ClassLoader classLoader);

    public CoreLib(Context self, Context context, String optimizedDir, ClassLoader classLoader) {
        this.classLoader = classLoader;

        if (MainModule.CORE_LOADED) {
            return;
        }

        File dirFile = new File("/data/data/com.baigesoft.marketingplugin/lib", "libcore.so");
        Log.d(TAG, "开始加载库：" + dirFile.getAbsolutePath());
        System.load(dirFile.getAbsolutePath());
        Log.d(TAG, "结束加载库");

        dexClassLoader = loadCore(self, optimizedDir, classLoader);
        MainModule.CORE_LOADED = true;

        LogUtils.log(TAG, "载入库完成：" + (dexClassLoader == null));
    }

    /**
     * 根据名称获取类
     *
     * @param className
     * @return
     */
    public Class<?> getClazz(String className) {
        if (dexClassLoader != null) {
            try {
                return dexClassLoader.loadClass(className);
            } catch (ClassNotFoundException ex) {
                ex.printStackTrace();
            }
        }
        if (classLoader != null) {
            try {
                return classLoader.loadClass(className);
            } catch (ClassNotFoundException ex) {
                ex.printStackTrace();
            }
        }
        return null;
    }

}
