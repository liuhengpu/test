package com.baigesoft.marketingplugin;


import android.app.Application;
import android.content.Context;
import android.content.IntentFilter;
import android.content.pm.PackageInfo;
import android.text.TextUtils;

import com.baigesoft.corelib.CommandReceiver;
import com.baigesoft.corelib.WechatHook;
import com.baigesoft.marketingplugin.utils.LogUtils;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

import static com.baigesoft.marketingplugin.Constants.WECHAT_PACKAGE_NAME;

/**
 * Created by Dawei on 12/13/16.
 */

public class MainModule implements IXposedHookLoadPackage {

    private static final String TAG = "Plugin_MainModule";

    public static boolean CORE_LOADED = false;

    public static boolean DEBUG = true;

    /**
     * 总的Hook入口
     *
     * @param packageParam
     * @throws Throwable
     */
    @Override
    public void handleLoadPackage(final XC_LoadPackage.LoadPackageParam packageParam) throws Throwable {
        try {
            if (packageParam.appInfo == null || (packageParam.appInfo.flags & 1) > 0 || (packageParam.appInfo.flags & 129) != 0) {
                return;
            }
            if (TextUtils.isEmpty(packageParam.packageName)) {
                return;
            }

            //HOOK微信
            hookWechat(packageParam);


        } catch (Exception e) {
            XposedBridge.log(TAG + ": " + e.getMessage());
        }
    }

    private void hookWechat(final XC_LoadPackage.LoadPackageParam packageParam) {
        if (packageParam.packageName.startsWith("com.android")) {
            return;
        }
        if (packageParam.packageName.startsWith(WECHAT_PACKAGE_NAME)) {
            if (packageParam.isFirstApplication && packageParam.processName.equals(packageParam.packageName) || !packageParam.processName.startsWith(packageParam.packageName)) {
                try {
                    XposedHelpers.findAndHookMethod(Application.class, "attach", Context.class, new XC_MethodHook() {
                        protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                            Class activityThread = XposedHelpers.findClass("android.app.ActivityThread", packageParam.classLoader);
                            if (activityThread == null) {
                                LogUtils.log(TAG, "[HOOK微信]activityThread==null");
                                return;
                            }
                            Object currentActivityThread = XposedHelpers.callStaticMethod(activityThread, "currentActivityThread");
                            if (currentActivityThread == null) {
                                LogUtils.log(TAG, "[HOOK微信]currentActivityThread==null");
                                return;
                            }
                            Context systemContext = (Context) XposedHelpers.callMethod(currentActivityThread, "getSystemContext");
                            if (systemContext == null) {
                                LogUtils.log(TAG, "[HOOK微信]systemContext==null");
                                return;
                            }
                            PackageInfo packageInfo = systemContext.getPackageManager().getPackageInfo(packageParam.packageName, 0);
                            if (packageInfo == null) {
                                LogUtils.log(TAG, "[HOOK微信]packageInfo==null");
                                return;
                            }
                            if (!TextUtils.isEmpty(packageInfo.versionName)) {
                                Constants.WECHAT_VERSION = packageInfo.versionName;
                            }
                            if (TextUtils.isEmpty(Constants.WECHAT_VERSION) || !Constants.isSupport(Constants.WECHAT_VERSION)) {
                                LogUtils.log(TAG, "不支持当前微信：" + packageInfo.versionName);
                                return;
                            }
                            LogUtils.log(TAG, "当前微信版本:" + Constants.WECHAT_VERSION);

                            Context context = (Context) param.args[0];
                            if (context == null) {
                                LogUtils.log(TAG, "[HOOK微信]context==null");
                                return;
                            }

                            //注册消息接收者
                            IntentFilter filter = new IntentFilter("COM_BAIGESOFT_PLUGIN_ACTION");
                            filter.setPriority(Integer.MAX_VALUE);

                            LogUtils.log(TAG, "开始注册接收器");

                            new WechatHook(context, Constants.WECHAT_VERSION).handleLoadPackage(packageParam);
                            XposedHelpers.callMethod(context, "registerReceiver", new Object[]{new CommandReceiver(packageParam), filter});
                            LogUtils.log(TAG, "DEBUG注册广播接收器到微信上下文");
                        }
                    });

                } catch (Exception ex) {
                    LogUtils.log(TAG, "Hook微信出错：" + ex.getMessage());
                    ex.printStackTrace();
                }
            }
        }
    }

}
