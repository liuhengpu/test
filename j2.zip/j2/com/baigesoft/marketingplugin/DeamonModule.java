package com.baigesoft.marketingplugin;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

/**
 * Created by Dawei on 14/06/2017.
 */

public class DeamonModule implements IXposedHookLoadPackage {

    private static final String TAG = "DeamonModule";


    @Override
    public void handleLoadPackage(XC_LoadPackage.LoadPackageParam lpparam) throws Throwable {
        if(lpparam.packageName.contains(Constants.WECHAT_PACKAGE_NAME)){
            if(lpparam.processName.equals("com.tencent.mm")){
//                new TestThread().start();
//                LogUtils.log(TAG, "线程已启动");
            }
        }

        //测试
//        if(lpparam.packageName.equals("com.instagram.android")) {
//
//            XposedHelpers.findAndHookMethod("com.instagram.common.l.g.g", lpparam.classLoader, "a",
//                    Context.class,
//                    int.class,
//                    boolean.class,
//                    int.class,
//                    int.class,
//                    boolean.class,
//                    boolean.class,
//                    boolean.class,
//                    boolean.class,
//                    boolean.class,
//                    boolean.class,
//                    boolean.class,
//                    boolean.class,
//                    int.class, new XC_MethodHook() {
//                @Override
//                protected void beforeHookedMethod(MethodHookParam param) throws Throwable {
//                    super.beforeHookedMethod(param);
//                    LogUtils.log(TAG, "去掉证书验证");
//                    param.args[7] = true;
//                }
//            });
//
////            XposedHelpers.findAndHookMethod("com.instagram.common.l.g.g", lpparam.classLoader, "b", XposedHelpers.findClass("com.instagram.common.l.a.cp", lpparam.classLoader), new XC_MethodHook() {
////                @Override
////                protected void beforeHookedMethod(MethodHookParam param) throws Throwable {
////                    super.beforeHookedMethod(param);
////                    LogUtils.log(TAG, "走了：com.instagram.common.l.g.g:b");
////                }
////            });
//
////            XposedHelpers.findAndHookMethod("com.instagram.api.c.b", lpparam.classLoader, "a", String.class, new XC_MethodHook() {
////                @Override
////                protected void afterHookedMethod(MethodHookParam param) throws Throwable {
////                    super.afterHookedMethod(param);
////                    LogUtils.log(TAG, "获取URL：" + param.getResult());
////                }
////            });
//
//
//        }





//
//        XposedHelpers.findAndHookMethod("com.baigesoft.marketing.MMApplication", lpparam.classLoader, "onCreate", new XC_MethodHook() {
//            @Override
//            protected void afterHookedMethod(MethodHookParam param) throws Throwable {
//                super.afterHookedMethod(param);
//
////                XSharedPreferences pre = new XSharedPreferences(this.getClass().getPackage().getName(), "prefs");
////                if(pre.contains("startup") && pre.getBoolean("startup", false)){
////                    LogUtils.log(TAG, "第二次启动");
////                }else {
////                    XSharedPreferences.Editor editor = pre.edit();
////                    editor.putBoolean("startup", true);
////                    editor.apply();
////                    LogUtils.log(TAG, "已启动");
////                }
//            }
//        });

//        if (!lpparam.packageName.equals("com.android.systemui"))
//            return;
//        LogUtils.log(TAG, "Hello SystemUI, Loaded app: " + lpparam.packageName);
//
//        new Thread(new Runnable() {
//            @Override
//            public void run() {
//                LogUtils.log(TAG, "线程循环");
//                try {
//                    Thread.sleep(5000);
//                } catch (InterruptedException e) {
//                    e.printStackTrace();
//                }
//            }
//        }).start();
    }
}
