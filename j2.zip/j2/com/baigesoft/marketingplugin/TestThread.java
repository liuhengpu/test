package com.baigesoft.marketingplugin;

import com.baigesoft.corelib.utils.LogUtils;

/**
 * Created by Dawei on 04/01/2018.
 */

public class TestThread extends Thread {

    private static final String TAG = "TestThread";

    @Override
    public void run() {
        for(int i = 0; i < 100; i++){
            LogUtils.log(TAG, "线程【" + Thread.currentThread().getName() + "】" + i);
            try {
                Thread.sleep(5000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }
}
