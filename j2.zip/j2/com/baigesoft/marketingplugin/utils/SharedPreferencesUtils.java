package com.baigesoft.marketingplugin.utils;

import android.content.Context;
import android.content.SharedPreferences;

import com.baigesoft.marketingplugin.Constants;

import java.util.HashSet;
import java.util.Set;

/**
 * Time:2019/5/29-上午9:15
 * Author:liuhengpu
 * Description:
 */
public class SharedPreferencesUtils {

     public static SharedPreferences newInstance(Context context){
          return context.getSharedPreferences(Constants.Preferences_NAME, Context.MODE_WORLD_WRITEABLE);
     }

     public static String getString(String key, String defValue,Context context){
          return newInstance(context).getString(key, defValue);
     }

     public static void putString(String key, String value,Context context){
          SharedPreferences.Editor editor = newInstance(context).edit();
          editor.putString(key, value);
          editor.commit();
     }


}
