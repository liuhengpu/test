package com.baigesoft.marketingplugin.utils;

import android.text.TextUtils;

import java.util.Random;

/**
 * Created by Dawei on 12/12/16.
 */

public class NumberUtils {

    private static Random random = new Random();

    /**
     * 转换10进制为16进制
     *
     * @param number
     * @return
     */
    public static String toHex(int number) {
        return Integer.toHexString(number);
    }

    /**
     * 转换16进制为10进制数字
     *
     * @param hex
     * @return
     */
    public static int hexToInt(String hex) {
        return Integer.parseInt(hex, 16);
    }

    /**
     * 将字符串转换为数字
     * @param numberStr
     * @return
     */
    public static int toInt(String numberStr){
        return toInt(numberStr, 0);
    }

    /**
     * 将字符串转换为数字
     * @param numberStr
     * @param defValue
     * @return
     */
    public static int toInt(String numberStr, int defValue){
        if(TextUtils.isEmpty(numberStr)){
            return defValue;
        }
        try{
            return Integer.parseInt(numberStr);
        }catch(NumberFormatException ex){
            return defValue;
        }
    }

    /**
     * 将字符串转换为数字
     * @param numberStr
     * @return
     */
    public static long toLong(String numberStr){
        return toLong(numberStr, 0);
    }

    /**
     * 将字符串转换为数字
     * @param numberStr
     * @param defValue
     * @return
     */
    public static long toLong(String numberStr, long defValue){
        if(TextUtils.isEmpty(numberStr)){
            return defValue;
        }
        try{
            return Long.parseLong(numberStr);
        }catch(NumberFormatException ex){
            return defValue;
        }
    }

    /**
     * 将字符串转换为数字
     * @param numberStr
     * @param defValue
     * @return
     */
    public static double toDouble(String numberStr, double defValue){
        if(TextUtils.isEmpty(numberStr)){
            return defValue;
        }
        try{
            return Double.parseDouble(numberStr);
        }catch(NumberFormatException ex){
            return defValue;
        }
    }

    /**
     * 获取一个随机整数
     * @param max
     * @return
     */
    public static int randomInt(int max){
        return random.nextInt(max);
    }

    /**
     * 获取一个范围内的随机整数
     * @param min
     * @param max
     * @return
     */
    public static int randomInt(int min, int max){
        if(min >= max){
            return randomInt(max);
        }
        return random.nextInt(max - min + 1) + min;
    }

}
