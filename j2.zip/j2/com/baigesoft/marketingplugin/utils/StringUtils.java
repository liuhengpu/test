package com.baigesoft.marketingplugin.utils;

import java.security.MessageDigest;

/**
 * Created by Dawei on 22/05/2017.
 */

public class StringUtils {

    public static String subString(String source, String from, String to) {
        int start = source.indexOf(from);
        if (start != -1) {
            if (to.length() == 0) {
                return source.substring(from.length() + start);
            }
            int end = source.substring(from.length() + start).indexOf(to);
            if (end != -1) {
                return source.substring(from.length() + start, (from.length() + start) + end);
            }
        }
        return null;
    }

    public static String md5(String inStr) {
        try {
            int i;
            MessageDigest md5 = MessageDigest.getInstance("MD5");
            char[] charArray = inStr.toCharArray();
            byte[] byteArray = new byte[charArray.length];
            for (i = 0; i < charArray.length; i++) {
                byteArray[i] = (byte) charArray[i];
            }
            byte[] md5Bytes = md5.digest(byteArray);
            StringBuffer hexValue = new StringBuffer();
            for (byte b : md5Bytes) {
                int val = b & 255;
                if (val < 16) {
                    hexValue.append("0");
                }
                hexValue.append(Integer.toHexString(val));
            }
            return hexValue.toString();
        } catch (Exception e) {
            System.out.println(e.toString());
            e.printStackTrace();
            return "";
        }
    }

}
