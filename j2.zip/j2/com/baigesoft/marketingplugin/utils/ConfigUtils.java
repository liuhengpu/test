package com.baigesoft.marketingplugin.utils;

import android.text.TextUtils;

import com.baigesoft.marketingplugin.Constants;
import com.baigesoft.marketingplugin.model.LocationConfig;

import org.json.JSONObject;

import java.io.File;

/**
 * Created by Dawei on 4/21/17.
 */

public class ConfigUtils {

    private static final String TAG = "ConfigUtils";

    private static File getConfigFile(String fileName) {
        File configDirectory = new File(Constants.CONFIG_PATH);
        if (!configDirectory.exists()) {
            return null;
        }

        File file = new File(configDirectory, fileName);
        if (!file.exists()) {
            return null;
        }
        return file;
    }

    /**
     * 读取配置文件信息
     *
     * @param fileName
     * @return
     */
    private static JSONObject readConfig1(String fileName) {
        File file = getConfigFile(fileName);
        if (file == null) {
            return null;
        }

        String fileData = FileUtils.readFile(file);
        if (TextUtils.isEmpty(fileData)) {
            return null;
        }
        JSONObject jsonObject = null;
        try {
            jsonObject = new JSONObject(fileData);
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return jsonObject;
    }

    public static JSONObject readConfig(String fileName) {
        JSONObject jsonObject = readConfig1(fileName);
        return jsonObject;
    }

    /**
     * 读取定位设置
     *
     * @return
     */
    public static LocationConfig getLocationConfig() {
        LocationConfig locationConfig = new LocationConfig();
        JSONObject jsonObject = readConfig("gps.txt");
        if (jsonObject == null) {
            return locationConfig;
        }
        locationConfig.setLac(jsonObject.optInt("lac", -1));
        locationConfig.setCid(jsonObject.optInt("cid", -1));
        locationConfig.setLat(jsonObject.optDouble("lat", 0));
        locationConfig.setLng(jsonObject.optDouble("lng", 0));
        return locationConfig;
    }

}
