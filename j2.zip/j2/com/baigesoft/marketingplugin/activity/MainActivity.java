package com.baigesoft.marketingplugin.activity;

import android.app.Activity;
import android.app.backup.SharedPreferencesBackupHelper;
import android.content.Intent;
import android.os.Bundle;
import android.os.Debug;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Toast;

import com.baigesoft.corelib.Constants;
import com.baigesoft.corelib.actions.AddFriendAction;
import com.baigesoft.marketingplugin.BuildConfig;
import com.baigesoft.marketingplugin.R;
import com.baigesoft.marketingplugin.utils.SharedPreferencesUtils;

import de.robv.android.xposed.callbacks.XC_LoadPackage;

public class MainActivity extends Activity {

    private static final String TAG = "Plugin_MainActivity";
    Button  bt_change;
    EditText editText;
    LinearLayout  linearLayout;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        initDebugView();
    }
    //debug模式下可见
    public void initDebugView(){
         bt_change= (Button) findViewById(R.id.bt_url);
         editText = (EditText) findViewById(R.id.et_url);
         linearLayout = (LinearLayout) findViewById(R.id.ll_layout);

         if(BuildConfig.DEBUG){
              linearLayout.setVisibility(View.VISIBLE);
              if(!TextUtils.isEmpty(SharedPreferencesUtils.getString("WEBIP","",getApplicationContext()))){
                   Constants.SERVER_URL =SharedPreferencesUtils.getString("WEBIP","",getApplicationContext());
              }
         }
         bt_change.setOnClickListener(new View.OnClickListener() {
              @Override
              public void onClick(View view) {
                   if(!TextUtils.isEmpty(editText.getText().toString().trim())){
                        Constants.SERVER_URL = editText.getText().toString().trim();
                        SharedPreferencesUtils.newInstance(getApplicationContext());
                        SharedPreferencesUtils.putString("WEBIP",editText.getText().toString().trim(),getApplicationContext());
                        finish();
                        Intent intent = new Intent(MainActivity.this,MainActivity.class);
                        startActivity(intent);
                   }

              }
         });
    }
}
