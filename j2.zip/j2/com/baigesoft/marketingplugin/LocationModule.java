package com.baigesoft.marketingplugin;

import android.app.Application;
import android.content.Context;
import android.util.Log;

import com.baigesoft.marketingplugin.location.GeneralLocationHook;
import com.baigesoft.marketingplugin.location.LbsLocationHook;
import com.baigesoft.marketingplugin.location.TencentLocationHook;
import com.baigesoft.marketingplugin.model.LocationConfig;
import com.baigesoft.marketingplugin.utils.ConfigUtils;
import com.baigesoft.marketingplugin.utils.LogUtils;

import java.io.File;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

/**
 * Created by Dawei on 26/12/2017.
 */

public class LocationModule implements IXposedHookLoadPackage {

    private static final String TAG = "LocationModule";

    @Override
    public void handleLoadPackage(XC_LoadPackage.LoadPackageParam loadPackageParam) throws Throwable {
        try {
            if (loadPackageParam.appInfo != null
                    && (loadPackageParam.appInfo.flags & 1) <= 0
                    && (loadPackageParam.appInfo.flags & 129) == 0
                    && loadPackageParam.packageName != null
                    && !loadPackageParam.packageName.contains("com.baidu.mapapi")
                    && !loadPackageParam.packageName.contains("com.baidu.location")
                    && !loadPackageParam.packageName.contains("org.osmdroid")
                    && !loadPackageParam.packageName.contains("com.example")
                    && !loadPackageParam.packageName.contains("baigesoft")) {
                hook(loadPackageParam);
            }
        } catch (Exception ex) {
            LogUtils.log(TAG, ex.getMessage());
        }
    }

    public static void hook(XC_LoadPackage.LoadPackageParam lpparam) {
        File gpsConfig = new File(Constants.CONFIG_PATH + "/gps.txt");
        if(!gpsConfig.exists() || !gpsConfig.canRead()){
//            LogUtils.log(TAG, "[gps.txt]不存在，不进行模拟定位");
            return;
        }

        LocationConfig locationConfig = ConfigUtils.getLocationConfig();
        if(locationConfig == null
                || locationConfig.getLat() <= 0
                || locationConfig.getLng() <= 0){
//            LogUtils.log(TAG, "读取不到配置信息，不进行模拟定位");
            return;
        }

        int lac = locationConfig.getLac();
        int cid = locationConfig.getCid();
        try {
            double[] gps = bd09ToGcj02(locationConfig.getLat(), locationConfig.getLng());
            final double latitude = gps[0];
            final double longitude = gps[1];
//            LogUtils.log(TAG, "模拟位置:" + lpparam.processName + "," + latitude + "," + longitude + "," + lac + "," + cid);

            if ((lpparam.packageName.contains("com.tencen") && lpparam.packageName.contains("mm")) || lpparam.processName.contains("com.excelliance")) {
                Object[] objArr = new Object[2];
                objArr[0] = Context.class;
                final XC_LoadPackage.LoadPackageParam loadPackageParam = lpparam;
                objArr[1] = new XC_MethodHook() {
                    protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                        if (param.args[0] != null) {
                            TencentLocationHook.hook(loadPackageParam.classLoader, latitude, longitude);
                        }
                    }
                };
                XposedHelpers.findAndHookMethod(Application.class, "attach", objArr);
            }

            if(lac > -1 && cid > -1) {
                try {
                    LbsLocationHook.hook(lpparam.classLoader, lac, cid);
                } catch (Exception ex) {
//                    Log.d(TAG, "lbs:" + ex.getMessage());
                }
            }
            GeneralLocationHook.hook(lpparam.classLoader, latitude, longitude);
            return;
        } catch (Exception ex2) {
            Log.d(TAG, ex2.getMessage());
            return;
        }
    }

    static final double X_PI = 52.35987755982988d;
    public static double[] bd09ToGcj02(double bdLat, double bdLon) {
        double x = bdLon - 0.0065d;
        double y = bdLat - 0.006d;
        double z = Math.sqrt((x * x) + (y * y)) - (2.0E-5d * Math.sin(X_PI * y));
        double theta = Math.atan2(y, x) - (3.0E-6d * Math.cos(X_PI * x));
        double gcjLon = z * Math.cos(theta);
        double gcjLat = z * Math.sin(theta);
        return new double[]{gcjLat, gcjLon};
    }
}
