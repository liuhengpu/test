package com.baigesoft.marketingplugin.location;

import com.baigesoft.marketingplugin.utils.LogUtils;

import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedHelpers;

/**
 * Created by Dawei on 26/12/2017.
 */

public class TencentLocationHook {

    private static final String TAG = "TencentLocationHook";

    public static void hook(ClassLoader classLoader, final double latitude, final double longitude) {
        try {
            Class<?> tencentLocationClazz = XposedHelpers.findClass("com.tencent.map.geolocation.TencentLocation", classLoader);
            Class<?> geoFClazz = XposedHelpers.findClass("com.tencent.mm.modelgeo.f", classLoader);
            Class<?> geoEClazz = XposedHelpers.findClass("com.tencent.mm.modelgeo.e", classLoader);
            if (tencentLocationClazz != null) {
                XposedHelpers.findAndHookMethod(geoFClazz, "onLocationChanged", new Object[]{tencentLocationClazz, Integer.TYPE, String.class, new XC_MethodHook() {
                    protected void beforeHookedMethod(MethodHookParam param) throws Throwable {
                        gps(param.args[0], latitude, longitude);
                    }

                    protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                        gps(param.args[0], latitude, longitude);
                    }
                }});
                XposedHelpers.findAndHookMethod(geoEClazz, "onLocationChanged", new Object[]{tencentLocationClazz, Integer.TYPE, String.class, new XC_MethodHook() {
                    protected void beforeHookedMethod(MethodHookParam param) throws Throwable {
                        gps(param.args[0], latitude, longitude);
                    }

                    protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                        gps(param.args[0], latitude, longitude);
                    }
                }});
            }
        } catch (XposedHelpers.ClassNotFoundError ex) {
            LogUtils.log(TAG, ex.getMessage());
        } catch (XposedHelpers.InvocationTargetError error) {
            LogUtils.log(TAG, error.getMessage());
        }
    }

    private static void gps(Object obj, final double latitude, final double longitude) {
        XposedHelpers.findAndHookMethod(obj.getClass(), "getLatitude", new Object[]{new XC_MethodHook() {
            protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                try {
                    param.setResult(Double.valueOf(latitude));
                } catch (Exception e) {
                    LogUtils.log(TAG, e.getMessage());
                }
            }
        }});
        XposedHelpers.findAndHookMethod(obj.getClass(), "getLongitude", new Object[]{new XC_MethodHook() {
            protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                try {
                    param.setResult(Double.valueOf(longitude));
                } catch (Exception e) {
                    LogUtils.log(TAG, e.getMessage());
                }
            }
        }});
    }

}
