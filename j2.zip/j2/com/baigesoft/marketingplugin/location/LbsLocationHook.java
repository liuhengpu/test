package com.baigesoft.marketingplugin.location;

import android.os.Build;
import android.telephony.CellIdentityCdma;
import android.telephony.CellIdentityGsm;
import android.telephony.CellIdentityLte;
import android.telephony.CellIdentityWcdma;
import android.telephony.CellInfoCdma;
import android.telephony.CellInfoGsm;
import android.telephony.CellInfoLte;
import android.telephony.CellInfoWcdma;
import android.telephony.CellLocation;
import android.telephony.gsm.GsmCellLocation;

import java.util.ArrayList;
import java.util.List;

import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedHelpers;

/**
 * Created by Dawei on 26/12/2017.
 */

public class LbsLocationHook {

    public static void hook(ClassLoader classLoader, final int lac, final int cid) {
        XposedHelpers.findAndHookMethod("android.telephony.TelephonyManager", classLoader, "getCellLocation", new Object[]{new XC_MethodHook() {
            protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                GsmCellLocation gsmCellLocation = new GsmCellLocation();
                gsmCellLocation.setLacAndCid(lac, cid);
                param.setResult(gsmCellLocation);
            }
        }});
        XposedHelpers.findAndHookMethod("android.telephony.PhoneStateListener", classLoader, "onCellLocationChanged", new Object[]{CellLocation.class, new XC_MethodHook() {
            protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                GsmCellLocation gsmCellLocation = new GsmCellLocation();
                gsmCellLocation.setLacAndCid(lac, cid);
                param.setResult(gsmCellLocation);
            }
        }});
        if (Build.VERSION.SDK_INT > 22) {
            XposedHelpers.findAndHookMethod("android.telephony.TelephonyManager", classLoader, "getPhoneCount", new Object[]{new XC_MethodHook() {
                protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                    param.setResult(Integer.valueOf(1));
                }
            }});
        }
        if (Build.VERSION.SDK_INT < 23) {
            XposedHelpers.findAndHookMethod("android.telephony.TelephonyManager", classLoader, "getNeighboringCellInfo", new Object[]{new XC_MethodHook() {
                protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                    param.setResult(new ArrayList());
                }
            }});
        }
        if (Build.VERSION.SDK_INT > 16) {
            XposedHelpers.findAndHookMethod("android.telephony.TelephonyManager", classLoader, "getAllCellInfo", new Object[]{new XC_MethodHook() {
                protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                    param.setResult(getCell(460, 0, lac, cid, 0, 0));
                }
            }});
            XposedHelpers.findAndHookMethod("android.telephony.PhoneStateListener", classLoader, "onCellInfoChanged", new Object[]{List.class, new XC_MethodHook() {
                protected void beforeHookedMethod(MethodHookParam param) throws Throwable {
                    param.setResult(getCell(460, 0, lac, cid, 0, 0));
                }
            }});
        }
    }

    private static ArrayList getCell(int mcc, int mnc, int lac, int cid, int sid, int networkType) {
        ArrayList arrayList = new ArrayList();
        CellInfoGsm cellInfoGsm = (CellInfoGsm) XposedHelpers.newInstance(CellInfoGsm.class, new Object[0]);
        Object[] objArr = new Object[1];
        objArr[0] = XposedHelpers.newInstance(CellIdentityGsm.class, new Object[]{Integer.valueOf(mcc), Integer.valueOf(mnc), Integer.valueOf(lac), Integer.valueOf(cid)});
        XposedHelpers.callMethod(cellInfoGsm, "setCellIdentity", objArr);
        CellInfoCdma cellInfoCdma = (CellInfoCdma) XposedHelpers.newInstance(CellInfoCdma.class, new Object[0]);
        objArr = new Object[1];
        objArr[0] = XposedHelpers.newInstance(CellIdentityCdma.class, new Object[]{Integer.valueOf(lac), Integer.valueOf(sid), Integer.valueOf(cid), Integer.valueOf(0), Integer.valueOf(0)});
        XposedHelpers.callMethod(cellInfoCdma, "setCellIdentity", objArr);
        CellInfoWcdma cellInfoWcdma = (CellInfoWcdma) XposedHelpers.newInstance(CellInfoWcdma.class, new Object[0]);
        objArr = new Object[1];
        objArr[0] = XposedHelpers.newInstance(CellIdentityWcdma.class, new Object[]{Integer.valueOf(mcc), Integer.valueOf(mnc), Integer.valueOf(lac), Integer.valueOf(cid), Integer.valueOf(300)});
        XposedHelpers.callMethod(cellInfoWcdma, "setCellIdentity", objArr);
        CellInfoLte cellInfoLte = (CellInfoLte) XposedHelpers.newInstance(CellInfoLte.class, new Object[0]);
        objArr = new Object[1];
        objArr[0] = XposedHelpers.newInstance(CellIdentityLte.class, new Object[]{Integer.valueOf(mcc), Integer.valueOf(mnc), Integer.valueOf(cid), Integer.valueOf(300), Integer.valueOf(lac)});
        XposedHelpers.callMethod(cellInfoLte, "setCellIdentity", objArr);
        if (networkType == 1 || networkType == 2) {
            arrayList.add(cellInfoGsm);
        } else if (networkType == 13) {
            arrayList.add(cellInfoLte);
        } else if (networkType == 4 || networkType == 5 || networkType == 6 || networkType == 7 || networkType == 12 || networkType == 14) {
            arrayList.add(cellInfoCdma);
        } else if (networkType == 3 || networkType == 8 || networkType == 9 || networkType == 10 || networkType == 15) {
            arrayList.add(cellInfoWcdma);
        }
        return arrayList;
    }

}
