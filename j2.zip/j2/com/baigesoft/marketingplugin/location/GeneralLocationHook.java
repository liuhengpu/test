package com.baigesoft.marketingplugin.location;

import android.location.Criteria;
import android.location.GpsStatus;
import android.location.GpsStatus.Listener;
import android.location.GpsStatus.NmeaListener;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Build;
import android.os.SystemClock;

import com.baigesoft.corelib.utils.LogUtils;
import com.baigesoft.marketingplugin.BuildConfig;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.ArrayList;

import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;

/**
 * Created by Dawei on 26/12/2017.
 */

public class GeneralLocationHook {

    private static final String TAG = "GeneralLocationHook";

    public static void hook(ClassLoader classLoader, final double latitude, final double longtitude) {
        int i = 0;
        XposedHelpers.findAndHookMethod("android.telephony.TelephonyManager", classLoader, "getNetworkOperatorName", new Object[]{new XC_MethodHook() {
            protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                param.setResult(BuildConfig.FLAVOR);
            }
        }});
        XposedHelpers.findAndHookMethod("android.telephony.TelephonyManager", classLoader, "getNetworkOperator", new Object[]{new XC_MethodHook() {
            protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                param.setResult(BuildConfig.FLAVOR);
            }
        }});
        XposedHelpers.findAndHookMethod("android.telephony.TelephonyManager", classLoader, "getSimOperatorName", new Object[]{new XC_MethodHook() {
            protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                param.setResult(BuildConfig.FLAVOR);
            }
        }});
        XposedHelpers.findAndHookMethod("android.telephony.TelephonyManager", classLoader, "getSimOperator", new Object[]{new XC_MethodHook() {
            protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                param.setResult(null);
            }
        }});
        XposedHelpers.findAndHookMethod("android.telephony.TelephonyManager", classLoader, "getSimCountryIso", new Object[]{new XC_MethodHook() {
            protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                param.setResult(BuildConfig.FLAVOR);
            }
        }});
        XposedHelpers.findAndHookMethod("android.telephony.TelephonyManager", classLoader, "getNetworkCountryIso", new Object[]{new XC_MethodHook() {
            protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                param.setResult(BuildConfig.FLAVOR);
            }
        }});
        XposedHelpers.findAndHookMethod("android.telephony.TelephonyManager", classLoader, "getNetworkType", new Object[]{new XC_MethodHook() {
            protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                param.setResult(Integer.valueOf(0));
            }
        }});
        XposedHelpers.findAndHookMethod("android.telephony.TelephonyManager", classLoader, "getPhoneType", new Object[]{new XC_MethodHook() {
            protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                param.setResult(Integer.valueOf(0));
            }
        }});
        XposedHelpers.findAndHookMethod("android.telephony.TelephonyManager", classLoader, "getCurrentPhoneType", new Object[]{new XC_MethodHook() {
            protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                param.setResult(Integer.valueOf(0));
            }
        }});
        XposedHelpers.findAndHookMethod("android.telephony.TelephonyManager", classLoader, "getDataState", new Object[]{new XC_MethodHook() {
            protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                param.setResult(Integer.valueOf(0));
            }
        }});
        XposedHelpers.findAndHookMethod("android.telephony.TelephonyManager", classLoader, "getSimState", new Object[]{new XC_MethodHook() {
            protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                param.setResult(Integer.valueOf(0));
            }
        }});
        XposedHelpers.findAndHookMethod("android.net.wifi.WifiManager", classLoader, "getScanResults", new Object[]{new XC_MethodHook() {
            protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                param.setResult(new ArrayList());
            }
        }});
        XposedHelpers.findAndHookMethod("android.net.wifi.WifiManager", classLoader, "getWifiState", new Object[]{new XC_MethodHook() {
            protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                param.setResult(Integer.valueOf(1));
            }
        }});
        XposedHelpers.findAndHookMethod("android.net.wifi.WifiManager", classLoader, "isWifiEnabled", new Object[]{new XC_MethodHook() {
            protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                param.setResult(Boolean.valueOf(true));
            }
        }});
        XposedHelpers.findAndHookMethod("android.net.NetworkInfo", classLoader, "getTypeName", new Object[]{new XC_MethodHook() {
            protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                param.setResult("MOBILE");
            }
        }});
        XposedHelpers.findAndHookMethod("android.net.NetworkInfo", classLoader, "isConnectedOrConnecting", new Object[]{new XC_MethodHook() {
            protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                param.setResult(Boolean.valueOf(true));
            }
        }});
        XposedHelpers.findAndHookMethod("android.net.NetworkInfo", classLoader, "isConnected", new Object[]{new XC_MethodHook() {
            protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                param.setResult(Boolean.valueOf(true));
            }
        }});
        XposedHelpers.findAndHookMethod("android.net.NetworkInfo", classLoader, "isAvailable", new Object[]{new XC_MethodHook() {
            protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                param.setResult(Boolean.valueOf(true));
            }
        }});
        XposedHelpers.findAndHookMethod("android.telephony.CellInfo", classLoader, "isRegistered", new Object[]{new XC_MethodHook() {
            protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                param.setResult(Boolean.valueOf(true));
            }
        }});
        XposedHelpers.findAndHookMethod(LocationManager.class, "getLastLocation", new Object[]{new XC_MethodHook() {
            protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                Location l = new Location("gps");
                l.setLatitude(latitude);
                l.setLongitude(longtitude);
                l.setAccuracy(100.0f);
                l.setTime(System.currentTimeMillis());
                if (Build.VERSION.SDK_INT >= 17) {
                    l.setElapsedRealtimeNanos(SystemClock.elapsedRealtimeNanos());
                }
                param.setResult(l);
            }
        }});
        XposedHelpers.findAndHookMethod(LocationManager.class, "getLastKnownLocation", new Object[]{String.class, new XC_MethodHook() {
            protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                Location l = new Location("gps");
                l.setLatitude(latitude);
                l.setLongitude(longtitude);
                l.setAccuracy(100.0f);
                l.setTime(System.currentTimeMillis());
                if (Build.VERSION.SDK_INT >= 17) {
                    l.setElapsedRealtimeNanos(SystemClock.elapsedRealtimeNanos());
                }
                param.setResult(l);
            }
        }});
        XposedBridge.hookAllMethods(LocationManager.class, "getProviders", new XC_MethodHook() {
            protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                ArrayList<String> arrayList = new ArrayList();
                arrayList.add("gps");
                param.setResult(arrayList);
            }
        });
        XposedHelpers.findAndHookMethod(LocationManager.class, "getBestProvider", new Object[]{Criteria.class, Boolean.TYPE, new XC_MethodHook() {
            protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                param.setResult("gps");
            }
        }});
        XposedHelpers.findAndHookMethod(LocationManager.class, "addGpsStatusListener", new Object[]{Listener.class, new XC_MethodHook() {
            protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                if (param.args[0] != null) {
                    XposedHelpers.callMethod(param.args[0], "onGpsStatusChanged", new Object[]{Integer.valueOf(1)});
                    XposedHelpers.callMethod(param.args[0], "onGpsStatusChanged", new Object[]{Integer.valueOf(3)});
                }
            }
        }});
        XposedHelpers.findAndHookMethod(LocationManager.class, "addNmeaListener", new Object[]{NmeaListener.class, new XC_MethodHook() {
            protected void beforeHookedMethod(MethodHookParam param) throws Throwable {
                param.setResult(Boolean.valueOf(false));
            }
        }});
        XposedHelpers.findAndHookMethod("android.location.LocationManager", classLoader, "getGpsStatus", new Object[]{GpsStatus.class, new XC_MethodHook() {
            protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                GpsStatus gss = (GpsStatus) param.getResult();
                if (gss != null) {
                    Method m = null;
                    for (Method method : GpsStatus.class.getDeclaredMethods()) {
                        if (method.getName().equals("setStatus") && method.getParameterTypes().length > 1) {
                            m = method;
                            break;
                        }
                    }
                    if (m != null) {
                        m.setAccessible(true);
                        int i = 5;
                        int[] prns = new int[]{1, 2, 3, 4, 5};
                        i = 5;
                        float[] snrs = new float[]{0.0f, 0.0f, 0.0f, 0.0f, 0.0f};
                        i = 5;
                        float[] elevations = new float[]{0.0f, 0.0f, 0.0f, 0.0f, 0.0f};
                        i = 5;
                        float[] azimuths = new float[]{0.0f, 0.0f, 0.0f, 0.0f, 0.0f};
                        try {
                            Method setStatus = GpsStatus.class.getDeclaredMethod("setStatus", new Class[]{Integer.TYPE, int[].class, float[].class, float[].class, float[].class, Integer.TYPE, Integer.TYPE, Integer.TYPE});
                            XposedHelpers.callMethod(gss, "setStatus", new Object[]{Integer.valueOf(5), prns, snrs, elevations, azimuths, Integer.valueOf(31), Integer.valueOf(31), Integer.valueOf(31)});
                            param.args[0] = gss;
                            param.setResult(gss);
                            m.invoke(gss, new Object[]{Integer.valueOf(5), prns, snrs, elevations, azimuths, Integer.valueOf(31), Integer.valueOf(31), Integer.valueOf(31)});
                            param.setResult(gss);
                        } catch (IllegalAccessException e) {
                            LogUtils.log(TAG, e.getMessage());
                        } catch (IllegalArgumentException e2) {
                            LogUtils.log(TAG, e2.getMessage());
                        } catch (InvocationTargetException e3) {
                            LogUtils.log(TAG, e3.getMessage());
                        } catch (NoSuchMethodException ex) {
                            LogUtils.log(TAG, ex.getMessage());
                        }
                    }
                }
            }
        }});
        Method[] declaredMethods = LocationManager.class.getDeclaredMethods();
        int length = declaredMethods.length;
        while (i < length) {
            Method method = declaredMethods[i];
            if (method.getName().equals("requestLocationUpdates") && !Modifier.isAbstract(method.getModifiers()) && Modifier.isPublic(method.getModifiers())) {
                XposedBridge.hookMethod(method, new XC_MethodHook() {
                    protected void beforeHookedMethod(MethodHookParam param) throws Throwable {
                        if (param.args.length >= 4 && (param.args[3] instanceof LocationListener)) {
                            LocationListener ll = (LocationListener)param.args[3];
                            Method m = null;
                            for (Method method : LocationListener.class.getDeclaredMethods()) {
                                if (method.getName().equals("onLocationChanged") && !Modifier.isAbstract(method.getModifiers())) {
                                    m = method;
                                    break;
                                }
                            }
                            Location l = new Location("gps");
                            l.setLatitude(latitude);
                            l.setLongitude(longtitude);
                            l.setAccuracy(10.0f);
                            l.setTime(System.currentTimeMillis());
                            if (Build.VERSION.SDK_INT >= 17) {
                                l.setElapsedRealtimeNanos(SystemClock.elapsedRealtimeNanos());
                            }
                            try {
                                XposedHelpers.callMethod(ll, "onLocationChanged", new Object[]{l});
                            } catch (XposedHelpers.InvocationTargetError e) {
                                LogUtils.log(TAG, e.getMessage());
                            }
                            if (m != null) {
                                try {
                                    m.invoke(ll, new Object[]{l});
                                } catch (Exception e2) {
                                    LogUtils.log(TAG, e2.getMessage());
                                }
                            }
                        }
                    }
                });
            }
            if (method.getName().equals("requestSingleUpdate ") && !Modifier.isAbstract(method.getModifiers()) && Modifier.isPublic(method.getModifiers())) {
                XposedBridge.hookMethod(method, new XC_MethodHook() {
                    protected void beforeHookedMethod(MethodHookParam param) throws Throwable {
                        if (param.args.length >= 3 && (param.args[1] instanceof LocationListener)) {
                            LocationListener ll = (LocationListener)param.args[3];
                            Method m = null;
                            for (Method method : LocationListener.class.getDeclaredMethods()) {
                                if (method.getName().equals("onLocationChanged") && !Modifier.isAbstract(method.getModifiers())) {
                                    m = method;
                                    break;
                                }
                            }
                            if (m != null) {
                                try {
                                    Location l = new Location("gps");
                                    l.setLatitude(latitude);
                                    l.setLongitude(longtitude);
                                    l.setAccuracy(100.0f);
                                    l.setTime(System.currentTimeMillis());
                                    if (Build.VERSION.SDK_INT >= 17) {
                                        l.setElapsedRealtimeNanos(SystemClock.elapsedRealtimeNanos());
                                    }
                                    m.invoke(ll, new Object[]{l});
                                } catch (Exception e) {
                                    LogUtils.log(TAG, e.getMessage());
                                }
                            }
                        }
                    }
                });
            }
            i++;
        }
    }

}
