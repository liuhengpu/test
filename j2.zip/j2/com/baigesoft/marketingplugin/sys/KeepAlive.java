package com.baigesoft.marketingplugin.sys;

import android.app.ActivityManager;
import android.content.Context;
import android.util.Log;

import java.util.List;

import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

/**
 * Created by Dawei on 15/06/2017.
 */

public class KeepAlive implements Runnable {

    private static final String TAG = "KeepAlive";

    private XC_LoadPackage.LoadPackageParam packageParam;

    public KeepAlive(XC_LoadPackage.LoadPackageParam packageParam) {
        this.packageParam = packageParam;
    }

    @Override
    public void run() {
        Log.d(TAG, "开始KeepAlive");
        Class<?> activityThread = XposedHelpers.findClass("android.app.ActivityThread", packageParam.classLoader);
        if (activityThread == null) {
            Log.d(TAG, "获取activityThread失败");
        }
        Object currentActivityThread = XposedHelpers.callStaticMethod(activityThread, "currentActivityThread", new Object[0]);
        if (currentActivityThread == null) {
            Log.d(TAG, "获取currentActivityThread失败");
        }
        boolean running = false;
        Context systemContext = (Context) XposedHelpers.callMethod(currentActivityThread, "getSystemContext", new Object[0]);
        List<ActivityManager.RunningServiceInfo> serviceList = ((ActivityManager) systemContext.getSystemService(Context.ACTIVITY_SERVICE)).getRunningServices(100);
        if (serviceList.size() > 0) {
            for (ActivityManager.RunningServiceInfo serviceInfo : serviceList) {
                if (serviceInfo.service.getClassName().equals("com.baigesoft.marketing.services.CoreService")) {
                    running = true;
                    break;
                }
            }
        }

        Log.d(TAG, "是否在运行：" + running);
    }
}
