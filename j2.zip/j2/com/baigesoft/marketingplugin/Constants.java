package com.baigesoft.marketingplugin;

/**
 * Created by Dawei on 4/26/17.
 */

public class Constants {

    public static final boolean DEBUG = true;

    /**
     * 微信的包名
     */
    public static final String WECHAT_PACKAGE_NAME = "com.tencent.mm";

    /**
     * 配置文件路径
     */
    public static final String CONFIG_PATH = "/sdcard/baigesoft";

    /**
     * 微信版本
     */
    public volatile static String WECHAT_VERSION = "";

    /**
     * 是否支持当前的微信版本
     *
     * @return
     */
    public static boolean isSupport(String wechatVersion) {
        if (wechatVersion.equals("6.5.7") || wechatVersion.equals("6.5.23")
                || wechatVersion.equals("6.6.3") || wechatVersion.equals("6.6.5")
                || wechatVersion.equals("6.6.6")
                || wechatVersion.equals("6.6.7")
                || wechatVersion.equals("6.7.2")
                || wechatVersion.equals("6.7.3")
                || wechatVersion.equals("7.0.0")
                || wechatVersion.equals("7.0.3")) {
            return true;
        }
        return false;
    }
   public static String Preferences_NAME ="spconfig";
}
