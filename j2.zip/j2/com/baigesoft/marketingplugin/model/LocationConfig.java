package com.baigesoft.marketingplugin.model;

/**
 * Created by Dawei on 4/21/17.
 */

public class LocationConfig {

    private int lac = -1;
    private int cid = -1;
    private double lat = 0.0d;
    private double lng = 0.0d;

    public LocationConfig() {
    }

    public LocationConfig(int lac, int cid, double lat, double lng) {
        this.lac = lac;
        this.cid = cid;
        this.lat = lat;
        this.lng = lng;
    }

    public int getLac() {
        return lac;
    }

    public void setLac(int lac) {
        this.lac = lac;
    }

    public int getCid() {
        return cid;
    }

    public void setCid(int cid) {
        this.cid = cid;
    }

    public double getLat() {
        return lat;
    }

    public void setLat(double lat) {
        this.lat = lat;
    }

    public double getLng() {
        return lng;
    }

    public void setLng(double lng) {
        this.lng = lng;
    }
}
