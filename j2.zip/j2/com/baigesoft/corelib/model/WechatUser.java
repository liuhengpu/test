package com.baigesoft.corelib.model;

/**
 * Created by Dawei on 18/05/2017.
 */

public class WechatUser {
    public String area;
    public String areaPY;
    public String country;
    public String email;
    public String sign;
    public String mobile;
    public String nickname;
    public String provicenPY;
    public String province;
    public String qq;
    public int sex;
    public String talkerId;
    public String weixinId;

    public String username;
    public String avatar;

    @Override
    public String toString() {
        return "WechatUser{" +
                "area='" + area + '\'' +
                ", areaPY='" + areaPY + '\'' +
                ", country='" + country + '\'' +
                ", email='" + email + '\'' +
                ", sign='" + sign + '\'' +
                ", mobile='" + mobile + '\'' +
                ", nickname='" + nickname + '\'' +
                ", provicenPY='" + provicenPY + '\'' +
                ", province='" + province + '\'' +
                ", qq='" + qq + '\'' +
                ", sex=" + sex +
                ", talkerId='" + talkerId + '\'' +
                ", weixinId='" + weixinId + '\'' +
                ", username='" + username + '\'' +
                ", avatar='" + avatar + '\'' +
                '}';
    }
}
