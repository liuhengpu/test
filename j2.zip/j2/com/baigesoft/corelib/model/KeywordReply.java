package com.baigesoft.corelib.model;

public class KeywordReply {

    /**
     * 关键词
     */
    private String keyword;

    /**
     * 回复
     */
    private String reply;

    /**
     * 0为部分匹配；1为精确匹配
     */
    private Integer type;

    private Integer content_type;

    /**
     * 图片原始地址
     */
    private String url;

    public KeywordReply() {
    }

    public String getKeyword() {
        return keyword;
    }

    public void setKeyword(String keyword) {
        this.keyword = keyword;
    }

    public String getReply() {
        return reply;
    }

    public void setReply(String reply) {
        this.reply = reply;
    }

    public Integer getType() {
        return type;
    }

    public void setType(Integer type) {
        this.type = type;
    }

    public Integer getContent_type() {
        return content_type;
    }

    public void setContent_type(Integer content_type) {
        this.content_type = content_type;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }
}
