package com.baigesoft.corelib.model;

/**
 * Created by Dawei on 19/07/2017.
 */

public class WechatMessage {

    /**
     * 消息类型
     */
    private int type;

    /**
     * 当前用户的微信id
     */
    private String sourceWeixinId;

    /**
     * 当前用户的手机号码
     */
    private String sourceMobile;

    /**
     * 当前用户(我)的talker
     */
    private String sourceTalker;

    /**
     * 好友或群的talker
     */
    private String talker;

    /**
     * 群消息时，发消息的群成员talker
     */
    private String friend_talker;

    /**
     * 群消息时，发消息的群成员的头像
     */
    private String friend_chatroom_img;

    /**
     * 好友昵称
     */
    private String nick;

    /**
     * 好友头像
     */
    private String friendImg;

    /**
     * 消息创建时间
     */
    private Long createTime;

    /**
     * 消息内容
     */
    private String content;

    /**
     * 消息状态
     */
    private int status;

    /**
     * 是否是发送的消息
     */
    private boolean isSend;

    private Long msgId;

    private Long msgSvrId;


    public WechatMessage(int type) {
        this.type = type;
    }

    public int getType() {
        return type;
    }

    public void setType(int type) {
        this.type = type;
    }

    public String getSourceWeixinId() {
        return sourceWeixinId;
    }

    public void setSourceWeixinId(String sourceWeixinId) {
        this.sourceWeixinId = sourceWeixinId;
    }

    public String getSourceMobile() {
        return sourceMobile;
    }

    public void setSourceMobile(String sourceMobile) {
        this.sourceMobile = sourceMobile;
    }

    public String getTalker() {
        return talker;
    }

    public void setTalker(String talker) {
        this.talker = talker;
    }

    public String getFriend_talker() {
        return friend_talker;
    }

    public void setFriend_talker(String friend_talker) {
        this.friend_talker = friend_talker;
    }

    public String getFriend_chatroom_img() {
        return friend_chatroom_img;
    }

    public void setFriend_chatroom_img(String friend_chatroom_img) {
        this.friend_chatroom_img = friend_chatroom_img;
    }

    public String getNick() {
        return nick;
    }

    public void setNick(String nick) {
        this.nick = nick;
    }

    public String getFriendImg() {
        return friendImg;
    }

    public void setFriendImg(String friendImg) {
        this.friendImg = friendImg;
    }

    public Long getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Long createTime) {
        this.createTime = createTime;
    }

    public String getSourceTalker() {
        return sourceTalker;
    }

    public void setSourceTalker(String sourceTalker) {
        this.sourceTalker = sourceTalker;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public boolean isSend() {
        return isSend;
    }

    public void setSend(boolean send) {
        isSend = send;
    }

    public Long getMsgId() {
        return msgId;
    }

    public void setMsgId(Long msgId) {
        this.msgId = msgId;
    }

    public Long getMsgSvrId() {
        return msgSvrId;
    }

    public void setMsgSvrId(Long msgSvrId) {
        this.msgSvrId = msgSvrId;
    }
}
