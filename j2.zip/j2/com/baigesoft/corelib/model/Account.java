package com.baigesoft.corelib.model;

import com.baigesoft.corelib.Constants;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by Dawei on 26/02/2018.
 */

public class Account {

    /**
     * 账号id
     */
    private Integer account_id;

    /**
     * 账号用户名
     */
    private String username;

    /**
     * 账号密码
     */
    private String password;

    /**
     * 账号类型：1为微信；2为QQ；3为陌陌
     */
    private int type;

    /**
     * 支付密码
     */
    private String paypass;

    /**
     * 是否开启自动回复
     */
    private int auto_reply;

    /**
     * 是否启用群
     */
    private int enable_chatroom = 0;

    /**
     * 是否自动通过好友
     */
    private int auto_through = 1;

    /**
     * 新好友招呼是否延时1分钟发送
     */
    private int reply_delay = 0;

    /**
     * 只为部分用户启用自动回复
     */
    private Map<String, String> replyTalkers = new HashMap<>();

    /**
     * 好友通过时发送招呼信息
     */
    private JSONArray replys = new JSONArray();

    public Account(JSONObject jsonObject) {
        this.account_id = jsonObject.optInt("account_id", 0);
        this.username = jsonObject.optString("username", "");
        this.password = jsonObject.optString("password", "");
        this.type = jsonObject.optInt("type", 1);
        this.paypass = jsonObject.optString("paypass", "");
        this.auto_reply = jsonObject.optInt("auto_reply", 0);
        if (jsonObject.has("setting")) {
            JSONObject settingObject = jsonObject.optJSONObject("setting");
            if (settingObject == null) {
                return;
            }
            if (settingObject.has("replys")) {
                replys = settingObject.optJSONArray("replys");
            }
            if (settingObject.has("enable_chatroom")) {
                enable_chatroom = settingObject.optInt("enable_chatroom", 0);
            }
            if (settingObject.has("auto_through") && settingObject.optInt("auto_through", 1) == 0) {
                auto_through = settingObject.optInt("auto_through", 1);
            }
            if (settingObject.has("talker")) {
                JSONArray talkerArray = settingObject.optJSONArray("talker");
                for (int i = 0; i < talkerArray.length(); i++) {
                    replyTalkers.put(talkerArray.optString(i), "");
                }
            }
            this.reply_delay = settingObject.optInt("reply_delay", 0);
        }

        //是否自动通过好友
        Constants.HANDLE_CHAT_ROOM = (enable_chatroom == 1);

        //是否自动通过好友
        Constants.AUTO_THROUGH_FRIEND = (auto_through == 1);
    }

    public Integer getAccount_id() {
        return account_id;
    }

    public void setAccount_id(Integer account_id) {
        this.account_id = account_id;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public int getType() {
        return type;
    }

    public void setType(int type) {
        this.type = type;
    }

    public String getPaypass() {
        return paypass;
    }

    public void setPaypass(String paypass) {
        this.paypass = paypass;
    }

    public int getAuto_reply() {
        return auto_reply;
    }

    public void setAuto_reply(int auto_reply) {
        this.auto_reply = auto_reply;
    }

    public Map<String, String> getReplyTalkers() {
        return replyTalkers;
    }

    public void setReplyTalkers(Map<String, String> replyTalkers) {
        this.replyTalkers = replyTalkers;
    }

    public JSONArray getReplys() {
        return replys;
    }

    public void setReplys(JSONArray replys) {
        this.replys = replys;
    }

    public int getEnable_chatroom() {
        return enable_chatroom;
    }

    public void setEnable_chatroom(int enable_chatroom) {
        this.enable_chatroom = enable_chatroom;
    }

    public int getReply_delay() {
        return reply_delay;
    }

    public void setReply_delay(int reply_delay) {
        this.reply_delay = reply_delay;
    }
}
