package com.baigesoft.corelib.model;

/**
 * Created by Dawei on 22/05/2017.
 */

public class WechatContact {

    private String sourceTalker;

    private String sourceWeixinId;

    private String sourceMobile;

    /**
     * 用户名/微信id
     */
    private String talker;

    /**
     * 别名/微信号
     */
    private String alias;

    /**
     * 备注
     */
    private String conRemark;

    /**
     * 昵称
     */
    private String nickname;

    /**
     * 拼音缩写
     */
    private String pyInitial;

    /**
     * 全拼
     */
    private String quanPin;

    /**
     * 加密用户名
     */
    private String encryptUsername;

    /**
     * 微博昵称
     */
    private String weibo;

    /**
     * 标签
     */
    private String tags;


    /**
     * 性别
     */
    private Integer sex;

    /**
     * 省份
     */
    private String province;

    /**
     * 城市
     */
    private String city;

    /**
     * 英文地区名
     */
    private String area_en;

    /**
     * 好友来源
     // 24、29通过摇一摇添加；
     // 18通过附近的人添加
     // 1000018对方通过附近的人添加；
     // 25漂流瓶；
     // 48雷达；
     // 14通过群聊添加；
     // 1000014对方通过群聊添加；
     // 15通过搜索手机号添加；
     // 1000015对方通过搜索手机号添加；
     // 10通过手机通讯录添加；
     // 1000010对方通过手机通讯录添加；
     // 9、45未知方式
     */
    private Integer source;

    /**
     * 描述
     */
    private String description;

    /**
     * 手机号码
     */
    private String mobile;

    /**
     * 签名
     */
    private String sign;

    /**
     * 好友头像
     */
    private String friend_img;

    /**
     * 是否是群
     */
    private Integer chatroom;

    /**
     * 好友类型
     */
    private Integer type;

    public WechatContact() {
    }

    public String getSourceTalker() {
        return sourceTalker;
    }

    public void setSourceTalker(String sourceTalker) {
        this.sourceTalker = sourceTalker;
    }

    public String getSourceWeixinId() {
        return sourceWeixinId;
    }

    public void setSourceWeixinId(String sourceWeixinId) {
        this.sourceWeixinId = sourceWeixinId;
    }

    public String getSourceMobile() {
        return sourceMobile;
    }

    public void setSourceMobile(String sourceMobile) {
        this.sourceMobile = sourceMobile;
    }

    public String getTalker() {
        return talker;
    }

    public void setTalker(String talker) {
        this.talker = talker;
    }

    public String getAlias() {
        return alias;
    }

    public void setAlias(String alias) {
        this.alias = alias;
    }

    public String getConRemark() {
        return conRemark;
    }

    public void setConRemark(String conRemark) {
        this.conRemark = conRemark;
    }

    public String getNickname() {
        return nickname;
    }

    public void setNickname(String nickname) {
        this.nickname = nickname;
    }

    public String getPyInitial() {
        return pyInitial;
    }

    public void setPyInitial(String pyInitial) {
        this.pyInitial = pyInitial;
    }

    public String getQuanPin() {
        return quanPin;
    }

    public void setQuanPin(String quanPin) {
        this.quanPin = quanPin;
    }

    public String getEncryptUsername() {
        return encryptUsername;
    }

    public void setEncryptUsername(String encryptUsername) {
        this.encryptUsername = encryptUsername;
    }

    public String getWeibo() {
        return weibo;
    }

    public void setWeibo(String weibo) {
        this.weibo = weibo;
    }

    public String getTags() {
        return tags;
    }

    public void setTags(String tags) {
        this.tags = tags;
    }

    public Integer getSex() {
        return sex;
    }

    public void setSex(Integer sex) {
        this.sex = sex;
    }

    public String getProvince() {
        return province;
    }

    public void setProvince(String province) {
        this.province = province;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getArea_en() {
        return area_en;
    }

    public void setArea_en(String area_en) {
        this.area_en = area_en;
    }

    public Integer getSource() {
        return source;
    }

    public void setSource(Integer source) {
        this.source = source;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getMobile() {
        return mobile;
    }

    public void setMobile(String mobile) {
        this.mobile = mobile;
    }

    public String getSign() {
        return sign;
    }

    public void setSign(String sign) {
        this.sign = sign;
    }

    public String getFriend_img() {
        return friend_img;
    }

    public void setFriend_img(String friend_img) {
        this.friend_img = friend_img;
    }

    public Integer getChatroom() {
        return chatroom;
    }

    public void setChatroom(Integer chatroom) {
        this.chatroom = chatroom;
    }

    public Integer getType() {
        return type;
    }

    public void setType(Integer type) {
        this.type = type;
    }
}
