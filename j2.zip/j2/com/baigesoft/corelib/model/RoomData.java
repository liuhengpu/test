package com.baigesoft.corelib.model;

/**
 * Created by Dawei on 17/01/2018.
 */

public class RoomData {

    private String username;

    private String chatNick;

    public RoomData() {
    }

    public RoomData(String username, String chatNick) {
        this.username = username;
        this.chatNick = chatNick;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getChatNick() {
        return chatNick;
    }

    public void setChatNick(String chatNick) {
        this.chatNick = chatNick;
    }
}
