package com.baigesoft.corelib.model;

/**
 * Created by Dawei on 19/07/2017.
 */

public class WechatMessageType {

    /**
     * 文本消息
     */
    public static final int TEXT = 1;

    /**
     * 图片消息
     */
    public static final int IMAGE = 3;

    /**
     * 语音消息
     */
    public static final int VOICE = 34;

    /**
     * QQ邮箱
     */
    public static final int QQ_MAIL = 35;

    /**
     * 名片消息
     */
    public static final int CARD = 42;

    /**
     * 视频消息
     */
    public static final int VIDEO = 43;

    /**
     * 表情消息
     */
    public static final int EMOJI = 47;

    /**
     * 位置消息
     */
    public static final int LOCATION = 48;

    /**
     * 链接消息
     */
    public static final int URL = 49;

    /**
     * 自定义的小程序类型
     * 因为小程序的消息类型和链接都是49，所以自定义一下
     */
    public static final int URL_SMALL_APP = 4900001;

    /**
     * 语音电话消息
     */
    public static final int VOICE_CALL = 50;

    /**
     * 链接视频
     */
    public static final int URL_VIDEO = 62;

    /**
     * 系统消息
     */
    public static final int SYSTEM = 10000;

    /**
     * 自定义表情消息
     */
    public static final int EMOJI_CUSTOM = 1048625;

    /**
     * APP消息
     */
    public static final int APP_MSG = 16777265;

    /**
     * 转账消息
     */
    public static final int TRANSFER = 419430449;

    /**
     * 红包消息
     */
    public static final int RED_ENVELOPES = 436207665;

    /**
     * 红包退回
     */
    public static final int RED_ENVELOPES_BACK = 318767153;

    /**
     * 地址分享
     */
    public static final int LOCATION_SHARE = -1879048186;

    /**
     * 新年红包消息
     */
    public static final int RED_ENVELOPES_NEW_YEAR = 469762097;

    /**
     * 已删除消息
     */
    public static final int DELETE_MSG = 285212721;

    /**
     * xx邀请xx进群消息
     */
    public static final int INVITE_INTO_CHATROOM = 570425393;

}
