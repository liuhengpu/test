package com.baigesoft.corelib.model;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

/**
 * Created by Dawei on 08/01/2018.
 */

public class ChatRoom {

    /**
     * 群用户名
     */
    private String talker;

    /**
     * 群名称
     */
    private String nickName;

    /**
     * 头像
     */
    private String friend_img;

    /**
     * 群公告
     */
    private String notice;

    /**
     * 成员数量
     */
    private int memberCount;

    /**
     * 群主Talker
     */
    private String owner;

    /**
     * 群主昵称
     */
    private String ownerNick;

    /**
     * 群成员talker列表
     */
    private String[] memberTalkers;

    /**
     * 群成员群昵称
     */
    private Map<String, String> chatNameMap = new HashMap<>();

    /**
     * 群成员昵称
     */
    private Map<String, String> nickNameMap = new HashMap<>();

    public ChatRoom() {
    }

    public String getTalker() {
        return talker;
    }

    public void setTalker(String talker) {
        this.talker = talker;
    }

    public String getNickName() {
        return nickName;
    }

    public void setNickName(String nickName) {
        this.nickName = nickName;
    }

    public int getMemberCount() {
        return memberCount;
    }

    public void setMemberCount(int memberCount) {
        this.memberCount = memberCount;
    }

    public String getOwner() {
        return owner;
    }

    public void setOwner(String owner) {
        this.owner = owner;
    }

    public String getOwnerNick() {
        return ownerNick;
    }

    public void setOwnerNick(String ownerNick) {
        this.ownerNick = ownerNick;
    }

    public String[] getMemberTalkers() {
        return memberTalkers;
    }

    public void setMemberTalkers(String[] memberTalkers) {
        this.memberTalkers = memberTalkers;
    }

    public String getFriend_img() {
        return friend_img;
    }

    public void setFriend_img(String friend_img) {
        this.friend_img = friend_img;
    }

    public String getNotice() {
        return notice;
    }

    public void setNotice(String notice) {
        this.notice = notice;
    }

    public Map<String, String> getChatNameMap() {
        return chatNameMap;
    }

    public void setChatNameMap(Map<String, String> chatNameMap) {
        this.chatNameMap = chatNameMap;
    }

    public Map<String, String> getNickNameMap() {
        return nickNameMap;
    }

    public void setNickNameMap(Map<String, String> nickNameMap) {
        this.nickNameMap = nickNameMap;
    }

    @Override
    public String toString() {
        return "ChatRoom{" +
                "talker='" + talker + '\'' +
                ", nickName='" + nickName + '\'' +
                ", friend_img='" + friend_img + '\'' +
                ", notice='" + notice + '\'' +
                ", memberCount=" + memberCount +
                ", owner='" + owner + '\'' +
                ", ownerNick='" + ownerNick + '\'' +
                ", memberTalkers=" + Arrays.toString(memberTalkers) +
                ", chatNameMap=" + chatNameMap +
                ", nickNameMap=" + nickNameMap +
                '}';
    }
}
