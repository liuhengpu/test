package com.baigesoft.corelib;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.text.TextUtils;

import com.baigesoft.corelib.actions.AddFriendAction;
import com.baigesoft.corelib.actions.BaseAction;
import com.baigesoft.corelib.actions.ChatroomAutoCreateAction;
import com.baigesoft.corelib.actions.ChatroomChangeNameAction;
import com.baigesoft.corelib.actions.ChatroomChangeNickNameAction;
import com.baigesoft.corelib.actions.ChatroomChangeNoticeAction;
import com.baigesoft.corelib.actions.ChatroomCreateAction;
import com.baigesoft.corelib.actions.ChatroomDeleteMemberAction;
import com.baigesoft.corelib.actions.ChatroomPullFriendAction;
import com.baigesoft.corelib.actions.ChatroomQuitAction;
import com.baigesoft.corelib.actions.ChatroomSaveToContactAction;
import com.baigesoft.corelib.actions.ChatroomSendMsgAction;
import com.baigesoft.corelib.actions.ChatroomSyncAction;
import com.baigesoft.corelib.actions.ContactBatchSendAction;
import com.baigesoft.corelib.actions.DeleteFriendAction;
import com.baigesoft.corelib.actions.LabelFriendAction;
import com.baigesoft.corelib.actions.ReloadSettingAction;
import com.baigesoft.corelib.actions.SendImageAction;
import com.baigesoft.corelib.actions.SendMessageAction;
import com.baigesoft.corelib.actions.SendSmallAppAction;
import com.baigesoft.corelib.actions.SendUrlAction;
import com.baigesoft.corelib.actions.SendVideoAction;
import com.baigesoft.corelib.actions.SendVoiceAction;
import com.baigesoft.corelib.actions.ShakeAction;
import com.baigesoft.corelib.actions.SyncUserAction;
import com.baigesoft.corelib.actions.TestAction;
import com.baigesoft.corelib.utils.LogUtils;

import de.robv.android.xposed.callbacks.XC_LoadPackage;

/**
 * Created by Dawei on 18/05/2017.
 */

public class CommandReceiver extends BroadcastReceiver {

    private static final String TAG = "Plugin_CommandReceiver";

    public static final String ACTION_PLUGIN = "COM_BAIGESOFT_PLUGIN_ACTION";

    private XC_LoadPackage.LoadPackageParam packageParam;

    public CommandReceiver(XC_LoadPackage.LoadPackageParam packageParam) {
        this.packageParam = packageParam;
    }

    @Override
    public void onReceive(Context context, Intent intent) {
        String action = intent.getAction();
        if (TextUtils.isEmpty(action)) {
            return;
        }
        if (!action.equals(ACTION_PLUGIN)) {
            return;
        }

        if (!packageParam.packageName.equals("com.tencent.mm")) {
            return;
        }

        int type = intent.getIntExtra(CommandActions.TYPE, 0);
        if (type <= 0) {
            return;
        }

        LogUtils.log(TAG, "命令「" + type + "」");

        BaseAction executeAction = null;
        switch (type) {
            case CommandActions.SEND_MESSAGE:
                executeAction = new SendMessageAction(intent, packageParam);
                break;
            case CommandActions.SEND_IMAGE:
                executeAction = new SendImageAction(intent, packageParam);
                break;
            case CommandActions.SEND_VOICE:
                executeAction = new SendVoiceAction(intent, packageParam);
                break;
            case CommandActions.SEND_VIDEO:
                executeAction = new SendVideoAction(intent, packageParam);
                break;
            case CommandActions.SEND_URL:
                executeAction = new SendUrlAction(intent, packageParam);
                break;
            case CommandActions.LABEL_FRIEND:
                executeAction = new LabelFriendAction(intent, packageParam);
                break;
            case CommandActions.SYNC_USER:
                executeAction = new SyncUserAction(intent, packageParam);
                break;
            case CommandActions.SHAKE:
                executeAction = new ShakeAction(intent, packageParam);
                break;
            case CommandActions.ADD_FRIEND:
                executeAction = new AddFriendAction(intent, packageParam);
                break;
            case CommandActions.RELOAD_SETTINGS:
                executeAction = new ReloadSettingAction(intent, packageParam);
                break;
            case CommandActions.CHATROOM_SYNC:
                executeAction = new ChatroomSyncAction(intent, packageParam);
                break;
            case CommandActions.CHATROOM_AUTO_CREATE:
                executeAction = new ChatroomAutoCreateAction(intent, packageParam);
                break;
            case CommandActions.CHATROOM_CREATE:
                executeAction = new ChatroomCreateAction(intent, packageParam);
                break;
            case CommandActions.CHATROOM_PULL_FRIEND:
                executeAction = new ChatroomPullFriendAction(intent, packageParam);
                break;
            case CommandActions.CHATROOM_DELETE_MEMBER:
                executeAction = new ChatroomDeleteMemberAction(intent, packageParam);
                break;
            case CommandActions.CHATROOM_CHANGE_NAME:
                executeAction = new ChatroomChangeNameAction(intent, packageParam);
                break;
            case CommandActions.CHATROOM_CHANGE_NOTICE:
                executeAction = new ChatroomChangeNoticeAction(intent, packageParam);
                break;
            case CommandActions.CHATROOM_SAVE_TO_CONTACT:
                executeAction = new ChatroomSaveToContactAction(intent, packageParam);
                break;
            case CommandActions.CHATROOM_CHANGE_NICK_NAME:
                executeAction = new ChatroomChangeNickNameAction(intent, packageParam);
                break;
            case CommandActions.CHATOOM_SEND_MSG:
                executeAction = new ChatroomSendMsgAction(intent, packageParam);
                break;
            case CommandActions.DELETE_FRIEND:
                executeAction = new DeleteFriendAction(intent, packageParam);
                break;
            case CommandActions.CHATROOM_QUIT:
                executeAction = new ChatroomQuitAction(intent, packageParam);
                break;
            case CommandActions.SEND_SMALLAPP:
                executeAction = new SendSmallAppAction(intent, packageParam);
                break;
            case CommandActions.CONTACT_BATCH_SEND_MSG:
                executeAction = new ContactBatchSendAction(intent, packageParam);
                break;
            case CommandActions.TEST:
                executeAction = new TestAction(intent, packageParam);
                break;
        }

        if (executeAction != null) {
            executeAction.execute();
        }

    }


}
