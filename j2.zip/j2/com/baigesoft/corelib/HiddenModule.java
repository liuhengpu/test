package com.baigesoft.corelib;

import android.app.ActivityManager;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.text.TextUtils;

import java.util.ArrayList;
import java.util.List;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

/**
 * Created by Dawei on 22/05/2017.
 */

public class HiddenModule implements IXposedHookLoadPackage {

    private static final String TAG = "HiddenModule";

    @Override
    public void handleLoadPackage(XC_LoadPackage.LoadPackageParam loadPackageParam) throws Throwable {
        String packageName = loadPackageParam.packageName;
        if(TextUtils.isEmpty(packageName)){
            return;
        }
        if(!packageName.contains("tencent") && !packageName.contains("safe") && !packageName.contains("secure") && !packageName.contains("security")){
            return;
        }


        Class<?> applicationPackageManager_clazz = XposedHelpers.findClass("android.app.ApplicationPackageManager", loadPackageParam.classLoader);

        //隐藏安装
        XposedHelpers.findAndHookMethod(applicationPackageManager_clazz, "getInstalledApplications", new Object[]{Integer.TYPE, new XC_MethodHook() {
            protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                List<ApplicationInfo> list = (List) param.getResult();
                List<ApplicationInfo> resultapplicationList = new ArrayList();
                if (list == null) {
                    param.setResult(resultapplicationList);
                    return;
                }
                for (ApplicationInfo applicationInfo : list) {
                    String packageName = applicationInfo.packageName;
                    if (HiddenModule.isTarget(packageName)) {
//                        LogUtils.log(TAG, "[InstalledApplications]隐藏包名: " + packageName);
                    } else {
                        resultapplicationList.add(applicationInfo);
                    }
                }
                param.setResult(resultapplicationList);
            }
        }});
        XposedHelpers.findAndHookMethod(applicationPackageManager_clazz, "getInstalledPackages", new Object[]{Integer.TYPE, new XC_MethodHook() {
            protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                List<PackageInfo> list = (List) param.getResult();
                List<PackageInfo> resultpackageInfoList = new ArrayList();
                if (list == null) {
                    param.setResult(resultpackageInfoList);
                    return;
                }
                for (PackageInfo packageInfo : list) {
                    String packageName = packageInfo.packageName;
                    if (HiddenModule.isTarget(packageName)) {
//                        LogUtils.log(TAG, "[InstalledPackages]隐藏包名: " + packageName);
                    } else {
                        resultpackageInfoList.add(packageInfo);
                    }
                }
                param.setResult(resultpackageInfoList);
            }
        }});
        XposedHelpers.findAndHookMethod(applicationPackageManager_clazz, "getPackageInfo", new Object[]{String.class, Integer.TYPE, new XC_MethodHook() {
            protected void beforeHookedMethod(MethodHookParam param) throws Throwable {
                String packageName = (String)param.args[0];
                if (HiddenModule.isTarget(packageName)) {
                    param.args[0] = "com.tencent.mm";
//                    LogUtils.log(TAG, "[PackageInfo]冒充名包: " + packageName + " as " + "com.tencent.mm");
                }
            }
        }});
        XposedHelpers.findAndHookMethod(applicationPackageManager_clazz, "getApplicationInfo", new Object[]{String.class, Integer.TYPE, new XC_MethodHook() {
            protected void beforeHookedMethod(MethodHookParam param) throws Throwable {
                String packageName = (String)param.args[0];
                if (HiddenModule.isTarget(packageName)) {
                    param.args[0] = "com.tencent.mm";
//                    LogUtils.log(TAG, "[ApplicationInfo]冒充名包: " + packageName + " as " + "com.tencent.mm");
                }
            }
        }});

        //隐藏服务
        Class<?> activityManager_clazz = XposedHelpers.findClass("android.app.ActivityManager", loadPackageParam.classLoader);
        XposedHelpers.findAndHookMethod(activityManager_clazz, "getRunningServices", new Object[]{Integer.TYPE, new XC_MethodHook() {
            protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                List<ActivityManager.RunningServiceInfo> list = (List) param.getResult();
                List<ActivityManager.RunningServiceInfo> resultList = new ArrayList();
                if (list == null) {
                    param.setResult(resultList);
                    return;
                }
                for (ActivityManager.RunningServiceInfo runningServiceInfo : list) {
                    String serviceName = runningServiceInfo.process;
                    if (HiddenModule.isTarget(serviceName)) {
//                        LogUtils.log(TAG, "隐藏服务: " + serviceName);
                    } else {
                        resultList.add(runningServiceInfo);
                    }
                }
                param.setResult(resultList);
            }
        }});

        //隐藏任务
        XposedHelpers.findAndHookMethod(activityManager_clazz, "getRunningTasks", new Object[]{Integer.TYPE, new XC_MethodHook() {
            protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                List<ActivityManager.RunningTaskInfo> list = (List) param.getResult();
                List<ActivityManager.RunningTaskInfo> resultList = new ArrayList();
                if (list == null) {
                    param.setResult(resultList);
                    return;
                }
                for (ActivityManager.RunningTaskInfo runningTaskInfo : list) {
                    String taskName = runningTaskInfo.baseActivity.flattenToString();
                    if (HiddenModule.isTarget(taskName)) {
//                        LogUtils.log(TAG, "隐藏任务: " + taskName);
                    } else {
                        resultList.add(runningTaskInfo);
                    }
                }
                param.setResult(resultList);
            }
        }});

        //隐藏进程
        XposedHelpers.findAndHookMethod(activityManager_clazz, "getRunningAppProcesses", new Object[]{new XC_MethodHook() {
            protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                List<ActivityManager.RunningAppProcessInfo> list = (List) param.getResult();
                List<ActivityManager.RunningAppProcessInfo> resultList = new ArrayList();
                if (list == null) {
                    param.setResult(resultList);
                    return;
                }
                for (ActivityManager.RunningAppProcessInfo runningAppProcessInfo : list) {
                    String processName = runningAppProcessInfo.processName;
                    if (HiddenModule.isTarget(processName)) {
//                        LogUtils.log(TAG, "隐藏进程: " + processName);
                    } else {
                        resultList.add(runningAppProcessInfo);
                    }
                }
                param.setResult(resultList);
            }
        }});

    }

    private static boolean isTarget(String name) {
        return name.contains("baigesoft")
                || name.contains("marketingplugin")
                || name.contains("mobilemarketing")
                || name.contains("MarketingPlugin")
                || name.contains("MobileMarketing")
                || name.contains("de.robv.android.xposed.installer")
                || name.contains("veryyoung")
                || name.contains("xposed");
    }
}
