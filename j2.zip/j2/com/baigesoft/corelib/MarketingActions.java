package com.baigesoft.corelib;

/**
 * Created by Dawei on 13/01/2018.
 */

public class MarketingActions {

    /**
     * 上传消息
     */
    public static final int UPLOAD_MESSAGE = 1;

    /**
     * 任务日志
     */
    public static final int TASK_LOG = 2;

    /**
     * 任务结果
     */
    public static final int TASK_RESULT = 3;

}
