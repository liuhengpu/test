package com.baigesoft.corelib;

import com.baigesoft.corelib.model.Account;
import com.baigesoft.corelib.model.KeywordReply;

import org.json.JSONObject;

import java.util.HashMap;

/**
 * Created by Dawei on 4/26/17.
 */

public class Constants {

    public static final boolean DEBUG = true;

    //是否是调试模式
    public static final boolean DEBUG_MODE = true;


//    public static final String SERVER_URL = "http://qunkong.dulianhui.com";

    public static String SERVER_URL ="http://192.168.21.152:8080";

    public static final String OSS_URL = "http://ysyunkong.oss-cn-beijing.aliyuncs.com";

    /**
     * 默认存储目录
     */
    public static final String PUBLIC_DIRECTORY = "baigesoft";

    /**
     * MarketingAPP指令
     */
    public static final String BROADCAST_MARKETING_ACTION = "COM_BAIGESOFT_MARKETING_ACTION";

    /**
     * 关键词回复
     */
    public static final HashMap<String, KeywordReply> KEYWORD_REPLY = new HashMap<>();

    /**
     * 失效的图灵key
     */
    public static final HashMap<String, String> TULING_FILTER = new HashMap<>();

    /**
     * 微信账号配置
     */
    public static Account ACCOUNT = null;

    /**
     * 设置
     */
    public static JSONObject SETTING = new JSONObject();

    /**
     * 随机聊天
     */
    public static JSONObject RANDOM_TALK = new JSONObject();

    /**
     * 设备号码
     */
    public static String SN = "";

    /**
     * 是否摇一摇
     */
    public static boolean isShake = false;

    /**
     * 是否处理群消息，默认关闭，通过读取accounts文件开启
     */
    public static boolean HANDLE_CHAT_ROOM = false;

    /**
     * 是否处理图片消息
     */
    public static boolean HANDLE_IMAGE_MSG = true;

    /**
     * 是否处理语音消息
     */
    public static boolean HANDLE_VOICE_MSG = true;

    /**
     * 是否处理视频消息
     */
    public static boolean HANDLE_VIDEO_MSG = true;

    /**
     * 处理的最大视频大小，超过此大小则忽略，默认3M
     */
    public static Integer MAX_VIDEO_SIZE = 1024 * 1024 * 3;

    /**
     * 是否自动通过好友
     */
    public static boolean AUTO_THROUGH_FRIEND = true;

}
