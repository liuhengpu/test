package com.baigesoft.corelib.db;


import com.baigesoft.corelib.config.WechatConfig;

import de.robv.android.xposed.XposedHelpers;

/**
 * Created by Dawei on 08/01/2018.
 */

public class SystemManager {

    private ClassLoader classLoader;

    public SystemManager(ClassLoader classLoader) {
        this.classLoader = classLoader;
    }

    public String getUserDir() {
        Object obj = XposedHelpers.callStaticMethod(XposedHelpers.findClass(WechatConfig.CLASS_KERNEL_PATH, classLoader), WechatConfig.METHDO_KERNEL_GET_CACHE_PATH_OBJECT);
        if (obj == null) {
            return null;
        }
        Object path = XposedHelpers.getObjectField(obj, WechatConfig.FIELD_GET_CACHE_PATH);
        if (path == null) {
            return null;
        }
        return path.toString();
    }
}
