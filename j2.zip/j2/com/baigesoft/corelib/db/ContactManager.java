package com.baigesoft.corelib.db;

import android.database.Cursor;
import android.text.TextUtils;

import com.baigesoft.corelib.model.WechatContact;
import com.baigesoft.corelib.utils.LogUtils;
import com.baigesoft.corelib.utils.WechatByteBufferUtil;
import com.baigesoft.corelib.utils.WechatUtils;
import com.baigesoft.corelib.wechat.WechatDb;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by Dawei on 08/01/2018.
 */

public class ContactManager {

    private static final String TAG = "Plugin_ContactManager";

    private ClassLoader classLoader;

    private WechatDb db;

    public ContactManager(ClassLoader classLoader) {
        this.classLoader = classLoader;
        db = new WechatDb(classLoader);
    }

    /**
     * 获取好友头像
     *
     * @param talker
     * @return
     */
    public String getImg(String talker) {
        String img = null;
        Cursor cursor = null;
        try {
            cursor = db.rawQuery("SELECT * FROM img_flag where username = ?", new String[]{talker});
            if (cursor == null || !cursor.moveToNext()) {
                return img;
            }
            img = cursor.getString(cursor.getColumnIndex("reserved2"));
        } finally {
            if (cursor != null) {
                cursor.close();
            }
        }
        return img;
    }

    /**
     * 获取联系人标签列表
     *
     * @return
     */
    private HashMap<String, String> getAllLabels() {
        HashMap<String, String> labelMap = new HashMap<>();
        Cursor cursor = null;
        try {
            cursor = db.rawQuery("SELECT * FROM ContactLabel", null);
            if (cursor == null) {
                return labelMap;
            }
            while (cursor.moveToNext()) {
                int labelID = cursor.getInt(cursor.getColumnIndex("labelID"));
                String labelName = cursor.getString(cursor.getColumnIndex("labelName"));
                labelMap.put(String.valueOf(labelID), labelName);
            }
        } catch (Exception ex) {

        } finally {
            if (cursor != null) {
                cursor.close();
            }
        }
        return labelMap;
    }

    /**
     * 获取联系人信息
     * @param username
     * @return
     */
    public WechatContact getContact(String username){
        List<WechatContact> contactList = getContacts(username);
        if(contactList != null && contactList.size() > 0){
            return contactList.get(0);
        }
        return null;
    }

    /**
     * 获取所有好友的Talker
     * @return
     */
    public List<String> getAllTalkers(){
        Cursor cursor = null;
        List<String> list = new ArrayList();
        try {
            cursor = db.rawQuery("SELECT username FROM rcontact where type & 1!=0 and type & 32=0 and type & 8=0 and verifyFlag & 8=0 and (username not like '%@%')", new String[]{});
            while (cursor.moveToNext()) {
                String talker = cursor.getString(cursor.getColumnIndex("username"));
                if(WechatUtils.skipTalker(talker)){
                    continue;
                }
                list.add(cursor.getString(cursor.getColumnIndex("username")));
            }
        } catch (Exception ex) {
        } finally {
            if (cursor != null) {
                cursor.close();
            }
        }
        return list;
    }

    /**
     * 获取联系人信息列表
     * @param usernames
     * @return
     */
    public List<WechatContact> getContacts(String... usernames){
        Cursor cursor = null;
        List<WechatContact> list = new ArrayList();
        //获取所有标签
        Map<String, String> labelMap = getAllLabels();
        try {
            for (String username : usernames) {
                cursor = db.rawQuery("SELECT * FROM rcontact where username=? AND type in (1,3)", new String[]{username});
                if (cursor != null && cursor.moveToNext()) {
                    WechatContact contact = toContact(cursor, labelMap);
                    list.add(contact);
                }
            }
        } catch (Exception ex) {
            LogUtils.log(TAG, "查询出错：" + ex.getMessage());
        } finally {
            if (cursor != null) {
                cursor.close();
            }
        }
        return list;
    }

    /**
     * 获取一个联系人信息，不判断类型
     * @param username
     * @return
     */
    public WechatContact getContactWithoutType(String username){
        Cursor cursor = null;
        WechatContact contact = null;
        //获取所有标签
        Map<String, String> labelMap = getAllLabels();
        try {
            cursor = db.rawQuery("SELECT * FROM rcontact where username=?", new String[]{username});
            if (cursor != null && cursor.moveToNext()) {
                contact = toContact(cursor, labelMap);
            }
        } catch (Exception ex) {
            LogUtils.log(TAG, "查询出错：" + ex.getMessage());
        } finally {
            if (cursor != null) {
                cursor.close();
            }
        }
        return contact;
    }

    /**
     * 好友昵称
     *
     * @param username
     * @return
     */
    public String getNickName(String username) {
        Cursor cursor = null;
        String nickname = null;
        try {
            cursor = db.rawQuery("SELECT nickname FROM rcontact where username = ?", new String[]{username});
            if (cursor == null || !cursor.moveToNext()) {
                return null;
            }
            nickname = cursor.getString(cursor.getColumnIndex("nickname"));
        } finally {
            if (cursor != null) {
                cursor.close();
            }
        }
        return nickname;
    }

    /**
     * 将数据转换为WechatContact对象
     *
     * @param cursor
     * @param labelMap
     * @return
     */
    private WechatContact toContact(Cursor cursor, Map<String, String> labelMap) {
        WechatContact wechatContact = new WechatContact();
        wechatContact.setTalker(cursor.getString(cursor.getColumnIndex("username")));
        wechatContact.setAlias(cursor.getString(cursor.getColumnIndex("alias")));
        wechatContact.setConRemark(cursor.getString(cursor.getColumnIndex("conRemark")));
        wechatContact.setNickname(cursor.getString(cursor.getColumnIndex("nickname")));
        wechatContact.setPyInitial(cursor.getString(cursor.getColumnIndex("pyInitial")));
        wechatContact.setQuanPin(cursor.getString(cursor.getColumnIndex("quanPin")));
        wechatContact.setEncryptUsername(cursor.getString(cursor.getColumnIndex("encryptUsername")));
        wechatContact.setWeibo(cursor.getString(cursor.getColumnIndex("weiboNickname")));
        wechatContact.setChatroom(cursor.getInt(cursor.getColumnIndex("chatroomFlag")));
        wechatContact.setType(cursor.getInt(cursor.getColumnIndex("type")));

        //标签
        String labelIds = cursor.getString(cursor.getColumnIndex("contactLabelIds"));
        if (!TextUtils.isEmpty(labelIds) && labelMap != null) {
            String[] labelIdArray = TextUtils.split(labelIds, ",");
            if (labelIdArray != null && labelIdArray.length > 0) {
                List<String> labelList = new ArrayList<>();
                for (int i = 0; i < labelIdArray.length; i++) {
                    if (labelMap.containsKey(String.valueOf(labelIdArray[i]))) {
                        labelList.add(labelMap.get(labelIdArray[i]));
                    }
                }
                wechatContact.setTags(TextUtils.join(",", labelList));
            }
        }

        //其它信息
        byte[] lvbuff = cursor.getBlob(cursor.getColumnIndex("lvbuff"));
        fillContact(wechatContact, lvbuff);

        //头像信息
        String friend_img = getImg(wechatContact.getTalker());
        wechatContact.setFriend_img(friend_img);
        return wechatContact;
    }

    public static void fillContact(WechatContact wechatContact, byte[] lvbuff){
        if(lvbuff == null || lvbuff.length == 0){
            return;
        }
        WechatByteBufferUtil wechatByteBufferUtilVar = new WechatByteBufferUtil();
        int be = wechatByteBufferUtilVar.be(lvbuff);
        if(be != 0){
            return;
        }
        try {
            int bAw = wechatByteBufferUtilVar.getInt();

            //1男2女0未知
            wechatContact.setSex(wechatByteBufferUtilVar.getInt());

            wechatByteBufferUtilVar.getString();
            wechatByteBufferUtilVar.getLong();
            int uin = wechatByteBufferUtilVar.getInt();

            wechatByteBufferUtilVar.getString();
            wechatByteBufferUtilVar.getString();
            wechatByteBufferUtilVar.getInt();
            wechatByteBufferUtilVar.getInt();
            wechatByteBufferUtilVar.getString();
            wechatByteBufferUtilVar.getString();
            wechatByteBufferUtilVar.getInt();
            wechatByteBufferUtilVar.getInt();

            wechatContact.setSign(wechatByteBufferUtilVar.getString());
            wechatContact.setProvince(wechatByteBufferUtilVar.getString());
            wechatContact.setCity(wechatByteBufferUtilVar.getString());

            wechatByteBufferUtilVar.getString();
            wechatByteBufferUtilVar.getInt();

            //来源：
            // 24、29通过摇一摇添加；
            // 18通过附近的人添加
            // 1000018对方通过附近的人添加；
            // 25漂流瓶；
            // 48雷达；
            // 14通过群聊添加；
            // 1000014对方通过群聊添加；
            // 15通过搜索手机号添加；
            // 1000015对方通过搜索手机号添加；
            // 10通过手机通讯录添加；
            // 1000010对方通过手机通讯录添加；
            // 9、45未知方式
            wechatContact.setSource(wechatByteBufferUtilVar.getInt());
            wechatByteBufferUtilVar.getString();

            int field_verifyFlag = wechatByteBufferUtilVar.getInt();

            wechatByteBufferUtilVar.getString();

            if (!wechatByteBufferUtilVar.bmL()) {
                wechatContact.setArea_en(wechatByteBufferUtilVar.getString());
            }

            int bAP = 0;
            if (!wechatByteBufferUtilVar.bmL()) {
                bAP = wechatByteBufferUtilVar.getInt();
            }

            int bAQ = 0;
            if (!wechatByteBufferUtilVar.bmL()) {
                bAQ = wechatByteBufferUtilVar.getInt();
            }

            //描述
            if (!wechatByteBufferUtilVar.bmL()) {
                wechatContact.setDescription(wechatByteBufferUtilVar.getString());
            }

            String bAS = "";
            if (!wechatByteBufferUtilVar.bmL()) {
                bAS = wechatByteBufferUtilVar.getString();
            }

            String bAT = "";
            if (!wechatByteBufferUtilVar.bmL()) {
                bAT = wechatByteBufferUtilVar.getString();
            }

            String bAU = "";
            if (!wechatByteBufferUtilVar.bmL()) {
                bAU = wechatByteBufferUtilVar.getString();
            }

            String bAV = "";
            if (!wechatByteBufferUtilVar.bmL()) {
                bAV = wechatByteBufferUtilVar.getString();
            }

            String bAW = "";
            if (!wechatByteBufferUtilVar.bmL()) {
                bAW = wechatByteBufferUtilVar.getString();
            }

            if (!wechatByteBufferUtilVar.bmL()) {
                wechatContact.setMobile(wechatByteBufferUtilVar.getString());
            }
        } catch (Exception ex) {
        }
    }
}
