package com.baigesoft.corelib.db;

import android.text.TextUtils;

import com.baigesoft.corelib.utils.FileUtils;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Talker数据管理
 */
public class TalkerManager {

    /**
     * 获取之前保存的talker
     * @param suffix
     * @return
     */
    public Map<String, String> getAll(String suffix) {
        Map<String, String> talkerMap = new HashMap<>();

        File talkerFile = new File(SettingManager.DATA_DIR + "saved_talkers_" + suffix);
        if (!talkerFile.exists()) {
            return talkerMap;
        }

        String content = FileUtils.readFile(talkerFile);
        if (TextUtils.isEmpty(content)) {
            return talkerMap;
        }

        JSONObject jsonObject = null;
        try {
            jsonObject = new JSONObject(content);
        } catch (JSONException ex) {
        }
        if (jsonObject == null) {
            return talkerMap;
        }

        JSONArray talkerArray = jsonObject.optJSONArray("talkers");
        if (talkerArray == null || talkerArray.length() == 0) {
            return talkerMap;
        }

        for (int i = 0; i < talkerArray.length(); i++) {
            talkerMap.put(talkerArray.optString(i), "1");
        }
        return talkerMap;
    }

    /**
     * 追加talker到文件中
     * @param suffix
     * @return
     */
    public void append(List<String> talkerList, String suffix) {
        File talkerFile = new File(SettingManager.DATA_DIR + "saved_talkers_" + suffix);
        if (!talkerFile.exists()) {
            try {
                talkerFile.createNewFile();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        JSONObject jsonObject = null;
        String content = FileUtils.readFile(talkerFile);
        if (!TextUtils.isEmpty(content)) {
            try {
                jsonObject = new JSONObject(content);
            } catch (JSONException ex) {
            }
        }
        if (jsonObject == null) {
            jsonObject = new JSONObject();
        }

        JSONArray talkerArray = jsonObject.optJSONArray("talkers");
        if (talkerArray == null) {
            talkerArray = new JSONArray();
        }

        for (int i = 0; i < talkerList.size(); i++) {
            talkerArray.put(talkerList.get(i));
        }
        try {
            jsonObject.put("talkers", talkerArray);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        FileUtils.writeFile(talkerFile.getAbsolutePath(), jsonObject.toString());
    }

    /**
     * 清空保存的talker
     * @param suffix
     */
    public void clear(String suffix){
        File talkerFile = new File(SettingManager.DATA_DIR + "saved_talkers_" + suffix);
        if (!talkerFile.exists()) {
            return;
        }
        FileUtils.deleteFile(talkerFile.getAbsolutePath());
    }
}
