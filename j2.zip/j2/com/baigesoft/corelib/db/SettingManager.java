package com.baigesoft.corelib.db;

import android.text.TextUtils;

import com.baigesoft.corelib.Constants;
import com.baigesoft.corelib.model.Account;
import com.baigesoft.corelib.model.KeywordReply;
import com.baigesoft.corelib.utils.FileUtils;
import com.baigesoft.corelib.utils.LogUtils;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by Dawei on 15/01/2018.
 */

public class SettingManager {

    private static final String TAG = "Plugin_SettingManager";

    public static final String DATA_DIR = "/sdcard/baigesoft/data/";

    private File accountDirFile = null;

    private File keywordReplyFile = null;

    private File settingFile = null;

    private File randomTalkFile = null;

    private File createChatroomFile = null;

    private File tulingFilterFile = null;

    public SettingManager() {
        accountDirFile = new File(DATA_DIR + "accounts");
        if (!accountDirFile.exists()) {
            accountDirFile.mkdirs();
        }

        keywordReplyFile = new File(DATA_DIR + "keyword_reply");
        settingFile = new File(DATA_DIR + "setting");
        randomTalkFile = new File(DATA_DIR + "random_talk");
        createChatroomFile = new File(DATA_DIR + "create_chatroom");
        tulingFilterFile = new File(DATA_DIR + "tuling_filter");
    }

    /**
     * 获取账号
     *
     * @return
     */
    public void initAccount() {
        File[] files = accountDirFile.listFiles();
        if (files == null || files.length == 0) {
            return;
        }
        for (File file : files) {
            String content = FileUtils.readFile(file);
            if (TextUtils.isEmpty(content)) {
                continue;
            }
            JSONObject jsonObject = null;
            try {
                jsonObject = new JSONObject(content);
            } catch (Exception ex) {
            }
            if (jsonObject == null) {
                continue;
            }
            Constants.ACCOUNT = new Account(jsonObject);
            break;
        }
        LogUtils.log(TAG, "启用群消息：" + Constants.HANDLE_CHAT_ROOM);
    }

    /**
     * 初始化图灵过滤key
     */
    public void initTulingFilter() {
        Constants.TULING_FILTER.clear();
        if (!tulingFilterFile.exists()) {
            return;
        }
        String content = FileUtils.readFile(tulingFilterFile);
        if (TextUtils.isEmpty(content)) {
            return;
        }
        JSONArray jsonArray = null;
        try {
            jsonArray = new JSONArray(content);
        } catch (JSONException ex) {
        }
        if (jsonArray == null) {
            return;
        }
        for (int i = 0; i < jsonArray.length(); i++) {
            Constants.TULING_FILTER.put(jsonArray.optString(i), "");
        }
    }

    /**
     * 保存图灵过滤key
     */
    public void saveTulingFilter() {
        if (!tulingFilterFile.exists()) {
            try {
                tulingFilterFile.createNewFile();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        JSONArray jsonArray = new JSONArray();
        for (String key : Constants.TULING_FILTER.keySet()) {
            jsonArray.put(key);
        }
        FileUtils.writeFile(tulingFilterFile.getAbsolutePath(), jsonArray.toString());
    }

    /**
     * 初始化设置
     */
    public void initSetting() {
        if (!settingFile.exists()) {
            return;
        }
        String content = FileUtils.readFile(settingFile);
        if (TextUtils.isEmpty(content)) {
            return;
        }
        JSONObject jsonObject = null;
        try {
            jsonObject = new JSONObject(content);
        } catch (JSONException ex) {
        }
        if (jsonObject == null) {
            return;
        }
        Constants.SETTING = jsonObject;
    }

    /**
     * 初始化关键词回复
     */
    public void initKeywordReply() {
        Constants.KEYWORD_REPLY.clear();
        if (!keywordReplyFile.exists()) {
            return;
        }
        String content = FileUtils.readFile(keywordReplyFile);
        if (TextUtils.isEmpty(content)) {
            return;
        }
        JSONArray jsonArray = null;
        try {
            jsonArray = new JSONArray(content);
        } catch (JSONException ex) {
        }
        if (jsonArray == null) {
            return;
        }
        for (int i = 0; i < jsonArray.length(); i++) {
            JSONObject jo = jsonArray.optJSONObject(i);
            if (!jo.has("keyword") || !jo.has("reply")) {
                continue;
            }
            String key = jo.optString("keyword", "");
            String reply = jo.optString("reply", "");
            Integer content_type = jo.optInt("content_type", 1);
            String image = jo.optString("image", "");
            if (TextUtils.isEmpty(key)) {
                continue;
            }
            if (content_type == 1 && TextUtils.isEmpty(reply)) {
                continue;
            }
            KeywordReply keywordReply = new KeywordReply();
            keywordReply.setKeyword(key);
            keywordReply.setType(jo.optInt("type", 0));
            keywordReply.setContent_type(content_type);

            if (content_type == 1) {
                keywordReply.setReply(reply);
            } else if (content_type == 2) {
                if (!TextUtils.isEmpty(image)) {
                    keywordReply.setReply(image);
                } else {
                    keywordReply.setReply(reply);
                }
                keywordReply.setUrl(jo.optString("url", ""));
            }

            Constants.KEYWORD_REPLY.put(key, keywordReply);
        }
    }

    /**
     * 初始化随机聊天配置
     */
    public void initRandomTalk() {
        if (!randomTalkFile.exists()) {
            return;
        }
        String content = FileUtils.readFile(randomTalkFile);
        if (TextUtils.isEmpty(content)) {
            return;
        }
        JSONObject jsonObject = null;
        try {
            jsonObject = new JSONObject(content);
        } catch (JSONException ex) {
        }
        if (jsonObject == null) {
            return;
        }
        Constants.RANDOM_TALK = jsonObject;
    }

    /**
     * 保存随机聊天配置
     */
    public void saveRandomTalk() {
        LogUtils.log(TAG, "[随机聊天]保存配置文件: " + Constants.RANDOM_TALK);
        if (Constants.RANDOM_TALK == null) {
            return;
        }
        String content = Constants.RANDOM_TALK.toString();
        FileUtils.writeFile(randomTalkFile.getAbsolutePath(), content);
    }

    /**
     * 删除随机聊天配置
     */
    public void removeRandomTalk() {
        FileUtils.deleteFile(randomTalkFile.getAbsolutePath());
    }

    /**
     * 获取自动建群的Talker
     */
    public Map<String, String> getCreateChatroomTalkers() {
        Map<String, String> talkerMap = new HashMap<>();
        if (!createChatroomFile.exists()) {
            try {
                createChatroomFile.createNewFile();
            } catch (IOException e) {
                e.printStackTrace();
            }
            return talkerMap;
        }
        String content = FileUtils.readFile(createChatroomFile);
        if (TextUtils.isEmpty(content)) {
            return talkerMap;
        }
        JSONObject jsonObject = null;
        try {
            jsonObject = new JSONObject(content);
        } catch (JSONException ex) {
        }
        if (jsonObject == null) {
            return talkerMap;
        }
        JSONArray talkerArray = jsonObject.optJSONArray("talkers");
        if (talkerArray == null || talkerArray.length() == 0) {
            return talkerMap;
        }
        for (int i = 0; i < talkerArray.length(); i++) {
            talkerMap.put(talkerArray.optString(i), "1");
        }
        return talkerMap;
    }

    /**
     * 保存已经拉入群的Talkers
     */
    public void saveCreateChatroomTalkers(List<String> talkerList) {
        Map<String, String> talkerMap = new HashMap<>();
        if (!createChatroomFile.exists()) {
            try {
                createChatroomFile.createNewFile();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        JSONObject jsonObject = null;
        String content = FileUtils.readFile(createChatroomFile);
        if (!TextUtils.isEmpty(content)) {
            try {
                jsonObject = new JSONObject(content);
            } catch (JSONException ex) {
            }
        }
        if (jsonObject == null) {
            jsonObject = new JSONObject();
        }

        JSONArray talkerArray = jsonObject.optJSONArray("talkers");
        if (talkerArray == null) {
            talkerArray = new JSONArray();
        }

        for (int i = 0; i < talkerList.size(); i++) {
            talkerArray.put(talkerList.get(i));
        }
        try {
            jsonObject.put("talkers", talkerArray);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        FileUtils.writeFile(createChatroomFile.getAbsolutePath(), jsonObject.toString());
    }



}
