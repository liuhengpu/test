package com.baigesoft.corelib.db;

import android.database.Cursor;
import android.text.TextUtils;
import android.util.Log;

import com.baigesoft.corelib.config.WechatConfig;
import com.baigesoft.corelib.model.WechatUser;
import com.baigesoft.corelib.utils.ClassUtils;
import com.baigesoft.corelib.utils.LogUtils;
import com.baigesoft.corelib.utils.StringUtils;
import com.baigesoft.corelib.wechat.WechatDb;

import de.robv.android.xposed.XposedHelpers;

/**
 * Created by Dawei on 08/01/2018.
 */

public class UserManager {

    private static final String TAG = "UserManager";

    private ClassLoader classLoader;

    private WechatDb db;

    public UserManager(ClassLoader classLoader) {
        LogUtils.log(TAG, "UserManager_classLoader: " + classLoader);
        this.classLoader = classLoader;
        db = new WechatDb(classLoader);
        LogUtils.log(TAG, "UserManager_db:" + db);
    }

    /**
     * 获取用户信息
     *
     * @return
     */
    public WechatUser getUserInfo() {
        Cursor cursor = db.rawQuery("SELECT * FROM userinfo");
        if (cursor == null) {
            return null;
        }
        WechatUser userInfo = new WechatUser();
        try {
            while (cursor.moveToNext()) {
                try {
                    String value = cursor.getString(cursor.getColumnIndex("value"));
                    int id = cursor.getInt(cursor.getColumnIndex("id"));
                    int type = cursor.getInt(cursor.getColumnIndex("type"));
                    if (id == 2) {
                        userInfo.talkerId = value;
                    }
                    if (id == 4) {
                        userInfo.nickname = value;
                    }
                    if (id == 5) {
                        userInfo.email = value;
                    }
                    if (id == 6) {
                        userInfo.mobile = value;
                    }
                    if (id == 42) {
                        userInfo.weixinId = value;
                    }
                    if (id == 12290) {
                        userInfo.sex = Integer.valueOf(value).intValue();
                    }
                    if (id == 29 && value != null) {
                        if (value.contains("uin=0&")) {
                            userInfo.qq = "";
                        } else {
                            userInfo.qq = StringUtils.subString(value, "uin=", "&key");
                        }
                    }
                    if (id == 12291) {
                        userInfo.sign = value;
                    }
                    if (id == 12293) {
                        userInfo.province = value;
                    }
                    if (id == 12292) {
                        userInfo.area = value;
                    }
                    if (id == 12324) {
                        userInfo.country = value;
                    }
                    if (id == 12325) {
                        userInfo.provicenPY = value;
                    }
                    if (id == 12326) {
                        userInfo.areaPY = value;
                    }
                    if (id == 274436) {
                    }
                } catch (Exception ex) {
                    LogUtils.log(TAG, ex.getMessage());
                }
            }
        } catch (Exception ex) {
            LogUtils.log(TAG, ex.getMessage());
        } finally {
            if (cursor != null) {
                cursor.close();
            }
        }

        String avatar = getUserImgByTalker(userInfo.talkerId);
        if (TextUtils.isEmpty(avatar)) {
            avatar = getUserImg();
        }
        //换成小图
        if (!TextUtils.isEmpty(avatar) && avatar.endsWith("/0")) {
            avatar = avatar.substring(0, avatar.lastIndexOf("/0")) + "/96";
        }
        userInfo.avatar = avatar;

        return userInfo;
    }

    /**
     * 从联系人表中取头像
     *
     * @param talker
     * @return
     */
    public String getUserImgByTalker(String talker) {
        String img = null;
        Cursor cursor = null;
        try {
            cursor = db.rawQuery("SELECT * FROM img_flag where username = ?", new String[]{talker});
            if (cursor == null || !cursor.moveToNext()) {
                return img;
            }
            img = cursor.getString(cursor.getColumnIndex("reserved2"));
        }catch(Exception ex){

        } finally {
            if (cursor != null) {
                cursor.close();
            }
        }
        return img;
    }

    /**
     * 获取当前登录用户头像
     *
     * @return
     */
    public String getUserImg() {
        String userImg = null;
        Cursor cursor = null;
        try {
            cursor = db.rawQuery("SELECT * FROM userinfo2 where sid = ?", new String[]{"USERINFO_SELFINFO_SMALLIMGURL_STRING"});
            if (cursor == null || !cursor.moveToNext()) {
                return userImg;
            }
            userImg = cursor.getString(cursor.getColumnIndex("value"));
        }catch(Exception ex){

        } finally {
            if (cursor != null) {
                cursor.close();
            }
        }
        return userImg;
    }

    /**
     * 获取当前登录用户的微信号
     *
     * @return
     */
    public String getWeixinNumber() {
        Class<?> model_h = ClassUtils.getClass(classLoader, WechatConfig.CLASS_ABOUNT);
        if (model_h != null) {
            return (String) XposedHelpers.callStaticMethod(model_h, WechatConfig.METHOD_ABOUT_GET_WEIXIN_NUMBER, new Object[0]);
        }
        return null;
    }

    /**
     * 获取当前登录用户的Talker
     * @return
     */
    public String getTalkerId() {
        Class<?> model_h = ClassUtils.getClass(classLoader, WechatConfig.CLASS_ABOUNT);
        if (model_h == null) {
            return null;
        }
        String talker_id = (String) XposedHelpers.callStaticMethod(model_h, WechatConfig.METHOD_ABOUT_GET_TALKER, new Object[0]);
        Log.d("Api", "talker_id:" + talker_id);
        return talker_id;
    }

    /**
     * 获取当前登录用户的昵称
     * @return
     */
    public String getNickName() {
        Class<?> model_h = ClassUtils.getClass(classLoader, WechatConfig.CLASS_ABOUNT);
        if (model_h != null) {
            return (String) XposedHelpers.callStaticMethod(model_h, WechatConfig.METHOD_ABOUT_GET_NICK_NAME, new Object[0]);
        }
        return null;
    }

    /**
     * 获取当前登录用户信息
     * @return
     */
    public WechatUser getCurrentUser() {
        WechatUser currentUser = new UserManager(classLoader).getUserInfo();
        if (currentUser == null) {
            return null;
        }
        String username = currentUser.mobile;
        if (TextUtils.isEmpty(username)) {
            username = currentUser.weixinId;
        }
        if (TextUtils.isEmpty(username)) {
            username = currentUser.email;
        }
        if (TextUtils.isEmpty(username)) {
            username = currentUser.qq;
        }
        currentUser.username = username;
        return currentUser;
    }
}
