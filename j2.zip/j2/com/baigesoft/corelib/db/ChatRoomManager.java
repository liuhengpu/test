package com.baigesoft.corelib.db;

import android.database.Cursor;
import android.text.TextUtils;

import com.baigesoft.corelib.model.ChatRoom;
import com.baigesoft.corelib.model.RoomData;
import com.baigesoft.corelib.model.WechatContact;
import com.baigesoft.corelib.roomdata.RoomDataParser;
import com.baigesoft.corelib.utils.LogUtils;
import com.baigesoft.corelib.wechat.WechatDb;

import java.util.ArrayList;
import java.util.List;

public class ChatRoomManager {

    private static final String TAG = "Plugin_ChatroomManager";

    private ClassLoader classLoader;

    private WechatDb db;

    private ContactManager contactManager;

    public ChatRoomManager(ClassLoader classLoader) {
        this.classLoader = classLoader;
        this.db = new WechatDb(classLoader);
        contactManager = new ContactManager(classLoader);
    }

    /**
     * 获取所有群信息
     *
     * @return
     */
    public List<ChatRoom> getAllChatRooms() {
        Cursor cursor = db.rawQuery("select * from rcontact  where type & 1!=0 and type & 32=0 and type & 8=0 and verifyFlag & 8=0 and username like '%@chatroom'");
        if (cursor == null) {
            return new ArrayList<>();
        }
        List<ChatRoom> chatRoomList = new ArrayList();
        try {
            while (cursor.moveToNext()) {
                String talker = cursor.getString(cursor.getColumnIndex("username"));
                String nickname = cursor.getString(cursor.getColumnIndex("nickname"));

                ChatRoom chatRoom = new ChatRoom();
                chatRoom.setTalker(talker);
                chatRoom.setNickName(nickname);
                chatRoomList.add(chatRoom);
            }
        } catch (Exception ex) {
        } finally {
            if (cursor != null) {
                cursor.close();
            }
        }
        return getChatRooms(chatRoomList);
    }

    /**
     * 获取所有群的简单信息
     *
     * @return
     */
    public List<ChatRoom> getSimpleChatRooms() {
        Cursor cursor = db.rawQuery("select * from rcontact  where type & 1!=0 and type & 32=0 and type & 8=0 and verifyFlag & 8=0 and username like '%@chatroom'");
        if (cursor == null) {
            return new ArrayList<>();
        }
        List<ChatRoom> chatRoomList = new ArrayList();
        try {
            while (cursor.moveToNext()) {
                String talker = cursor.getString(cursor.getColumnIndex("username"));
                String nickname = cursor.getString(cursor.getColumnIndex("nickname"));

                ChatRoom chatRoom = new ChatRoom();
                chatRoom.setTalker(talker);
                chatRoom.setNickName(nickname);

                chatRoomList.add(chatRoom);
            }
        } catch (Exception ex) {
        } finally {
            if (cursor != null) {
                cursor.close();
            }
        }
        return chatRoomList;
    }

    /**
     * 根据id获取群信息
     *
     * @param talker
     * @return
     */
    public ChatRoom getChatRoom(String talker) {
        ChatRoom chatRoom = new ChatRoom();
        chatRoom.setTalker(talker);
        List<ChatRoom> chatRoomList = new ArrayList<>();
        chatRoomList.add(chatRoom);

        List<ChatRoom> roomList = getChatRooms(chatRoomList);
        if (roomList == null || roomList.size() == 0) {
            return null;
        }
        return roomList.get(0);
    }

    /**
     * 根据id列表获取群信息
     *
     * @param chatRoomList
     * @return
     */
    public List<ChatRoom> getChatRooms(List<ChatRoom> chatRoomList) {
        Cursor cursor = null;
        List<ChatRoom> list = new ArrayList();
        try {
            for (ChatRoom chatRoom : chatRoomList) {
                cursor = db.rawQuery("SELECT * FROM chatroom where chatroomname=?", new String[]{chatRoom.getTalker()});
                if (cursor != null && cursor.moveToNext()) {
                    list.add(toChatRoom(cursor, chatRoom));
                }
            }
        } catch (Exception ex) {
            LogUtils.log(TAG, "获取群信息出错：" + ex.getMessage());
            ex.printStackTrace();
        } finally {
            if (cursor != null) {
                cursor.close();
            }
        }
        return list;
    }

    private ChatRoom toChatRoom(Cursor cursor, ChatRoom chatRoom) {
        chatRoom.setTalker(cursor.getString(cursor.getColumnIndex("chatroomname")));
        chatRoom.setOwner(cursor.getString(cursor.getColumnIndex("roomowner")));
        chatRoom.setNotice(cursor.getString(cursor.getColumnIndex("chatroomnotice")));

        String memberlist = cursor.getString(cursor.getColumnIndex("memberlist"));
        String displayname = cursor.getString(cursor.getColumnIndex("displayname"));

        LogUtils.log(TAG, "memberlist: " + memberlist);
        LogUtils.log(TAG, "displayname: " + displayname);

        String[] displayNames = new String[0];
        if (!TextUtils.isEmpty(displayname)) {
            displayNames = TextUtils.split(displayname, "、");
        }

        String[] memberTalkers = new String[0];
        if (!TextUtils.isEmpty(memberlist)) {
            memberTalkers = TextUtils.split(memberlist, ";");
        }

        chatRoom.setMemberTalkers(memberTalkers);
        chatRoom.setMemberCount(memberTalkers.length);

        byte[] bytes = cursor.getBlob(cursor.getColumnIndex("roomdata"));
        if (bytes != null) {
            List<RoomData> roomDataList = new RoomDataParser(bytes).parse();
            for (RoomData roomData : roomDataList) {
                if (!TextUtils.isEmpty(roomData.getUsername()) && !TextUtils.isEmpty(roomData.getChatNick())) {
                    chatRoom.getChatNameMap().put(roomData.getUsername(), roomData.getChatNick());
                }
            }
        }

        if (memberTalkers.length == displayNames.length) {
            for (int i = 0; i < memberTalkers.length; i++) {
                chatRoom.getNickNameMap().put(memberTalkers[i], displayNames[i]);
            }
        }

        if (TextUtils.isEmpty(chatRoom.getNickName())) {
            chatRoom.setNickName(contactManager.getNickName(chatRoom.getTalker()));
        }

        //未命令群
        if (TextUtils.isEmpty(chatRoom.getNickName())) {
            String nickName = TextUtils.join("、", displayNames);
            if (nickName.length() > 25) {
                nickName = nickName.substring(0, 25);
            }
            chatRoom.setNickName(nickName);
        }

        if (chatRoom.getChatNameMap().containsKey(chatRoom.getOwner())) {
            chatRoom.setOwnerNick(chatRoom.getChatNameMap().get(chatRoom.getOwner()));
        } else {
            WechatContact owner = contactManager.getContact(chatRoom.getOwner());
            if (owner != null) {
                chatRoom.setOwnerNick(owner.getNickname());
            } else {
                if (chatRoom.getNickNameMap().containsKey(chatRoom.getOwner())) {
                    chatRoom.setOwnerNick(chatRoom.getNickNameMap().get(chatRoom.getOwner()));
                }
            }
        }

        //头像
        chatRoom.setFriend_img(contactManager.getImg(chatRoom.getTalker()));

        return chatRoom;
    }
}