package com.baigesoft.corelib.actions;

import android.content.Intent;
import android.text.TextUtils;

import com.baigesoft.corelib.utils.LogUtils;
import com.baigesoft.corelib.utils.ThreadUtils;
import com.baigesoft.corelib.wechat.SendSmallApp;

import java.util.concurrent.TimeUnit;

import de.robv.android.xposed.callbacks.XC_LoadPackage;

public class SendSmallAppAction extends BaseAction {

    public SendSmallAppAction(Intent intent, XC_LoadPackage.LoadPackageParam packageParam) {
        super(intent, packageParam);
        TAG = "Plugin_SendSmallApp";
    }

    @Override
    public void execute() {
        LogUtils.log(TAG, "收到发送小程序命令");
        String talker = intent.getStringExtra("talker");
        if(TextUtils.isEmpty(talker)){
            LogUtils.log(TAG, "Talker为空");
            return;
        }

        String title = intent.getStringExtra("title");
        if(TextUtils.isEmpty(title)){
            LogUtils.log(TAG, "title为空");
            return;
        }

        String img = intent.getStringExtra("img");
        if(TextUtils.isEmpty(img)){
            LogUtils.log(TAG, "img为空");
            return;
        }

        String gh = intent.getStringExtra("gh");
        if(TextUtils.isEmpty(gh)){
            LogUtils.log(TAG, "gh为空");
            return;
        }

        String appId = intent.getStringExtra("appid");
        if(TextUtils.isEmpty(appId)){
            LogUtils.log(TAG, "appid为空");
            return;
        }

        String name = intent.getStringExtra("name");
        if(TextUtils.isEmpty(name)){
            LogUtils.log(TAG, "name为空");
            return;
        }

        String url = intent.getStringExtra("url");
        if(TextUtils.isEmpty(url)){
            LogUtils.log(TAG, "url为空");
            return;
        }

        ThreadUtils.runOnWorkerThreadDelayed(2, TimeUnit.SECONDS, new SendSmallApp(packageParam.classLoader, talker, title, img, gh, appId, name, url));
        LogUtils.log(TAG, "发送发送小程序完成");
    }
}
