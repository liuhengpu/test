package com.baigesoft.corelib.actions;

import android.content.Intent;

import com.baigesoft.corelib.utils.LogUtils;
import com.baigesoft.corelib.wechat.SendVideo;

import de.robv.android.xposed.callbacks.XC_LoadPackage;

/**
 * 发送视频消息
 */
public class SendVideoAction extends BaseAction{

    public SendVideoAction(Intent intent, XC_LoadPackage.LoadPackageParam packageParam) {
        super(intent, packageParam);
        TAG = "Plugin_SendVideo";
    }

    @Override
    public void execute() {
        LogUtils.log(TAG, "收到发送视频命令");
        String talker = intent.getStringExtra("talker");
        String video = intent.getStringExtra("video");
        new SendVideo(packageParam, talker, video).send();
        LogUtils.log(TAG, "发送视频完成");
    }
}
