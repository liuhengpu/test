package com.baigesoft.corelib.actions;

import android.content.Intent;
import android.text.TextUtils;

import com.baigesoft.corelib.utils.LogUtils;
import com.baigesoft.corelib.wechat.ChatRoomHook;

import de.robv.android.xposed.callbacks.XC_LoadPackage;

/**
 * 修改群名称
 */
public class ChatroomChangeNameAction extends BaseAction {

    public ChatroomChangeNameAction(Intent intent, XC_LoadPackage.LoadPackageParam packageParam) {
        super(intent, packageParam);
        TAG = "Plugin_RoomChangeName";
    }

    @Override
    public void execute() {
        String chatroomTalker = intent.getStringExtra("chatroom_talker");
        String name = intent.getStringExtra("name");

        LogUtils.log(TAG, "收到修改群名称命令：" + chatroomTalker + " : " + name);
        if (TextUtils.isEmpty(chatroomTalker)) {
            taskResult(false, "群Talker为空");
            LogUtils.log(TAG, "群Talker为空");
            return;
        }
        if (TextUtils.isEmpty(name)) {
            taskResult(false, "群名称为空");
            LogUtils.log(TAG, "群名称为空");
            return;
        }

        ChatRoomHook.changeName(packageParam.classLoader, chatroomTalker, name);
        taskResult(true, "执行成功");
    }
}
