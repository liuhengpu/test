package com.baigesoft.corelib.actions;

import android.content.Intent;

import com.baigesoft.corelib.utils.LogUtils;
import com.baigesoft.corelib.wechat.SendVoice;

import de.robv.android.xposed.callbacks.XC_LoadPackage;

/**
 * 发送语音消息
 */
public class SendVoiceAction extends BaseAction {

    public SendVoiceAction(Intent intent, XC_LoadPackage.LoadPackageParam packageParam) {
        super(intent, packageParam);
        TAG = "Plugin_SendVoice";
    }

    @Override
    public void execute() {
        LogUtils.log(TAG, "收到发送语音命令");
        String talker = intent.getStringExtra("talker");
        String voice = intent.getStringExtra("voice");
        new SendVoice(packageParam, talker, voice).send();
        LogUtils.log(TAG, "发送语音完成");
    }
}
