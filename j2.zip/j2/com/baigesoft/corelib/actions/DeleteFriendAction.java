package com.baigesoft.corelib.actions;

import android.content.Intent;
import android.text.TextUtils;

import com.baigesoft.corelib.utils.LogUtils;
import com.baigesoft.corelib.wechat.FriendsInfo;

import de.robv.android.xposed.callbacks.XC_LoadPackage;

/**
 * 删好友
 */
public class DeleteFriendAction extends BaseAction {

    public DeleteFriendAction(Intent intent, XC_LoadPackage.LoadPackageParam packageParam) {
        super(intent, packageParam);
        TAG = "Plugin_DeleteFriend";
    }

    @Override
    public void execute() {
        LogUtils.log(TAG, "开始删除好友");
        String talker = intent.getStringExtra("talker");

        if (TextUtils.isEmpty(talker)) {
            LogUtils.log(TAG, "好友Talker不能为空！");
            taskLog("", "Talker为空，添加失败");
            return;
        }

        FriendsInfo.delete(packageParam.classLoader, talker);

        taskLog(talker, "删除成功");
        LogUtils.log(TAG, "删除好友结束");
    }
}
