package com.baigesoft.corelib.actions;

import android.content.Intent;
import android.text.TextUtils;

import com.baigesoft.corelib.utils.LogUtils;
import com.baigesoft.corelib.utils.ThreadUtils;
import com.baigesoft.corelib.wechat.AddFriend;

import java.util.concurrent.TimeUnit;

import de.robv.android.xposed.callbacks.XC_LoadPackage;

/**
 * 加好友
 */
public class AddFriendAction extends BaseAction {

    public AddFriendAction(Intent intent, XC_LoadPackage.LoadPackageParam packageParam) {
        super(intent, packageParam);
        TAG = "Plugin_AddFriend";
    }

    @Override
    public void execute() {
        LogUtils.log(TAG, "开始添加好友");
        String talker = intent.getStringExtra("talker");
        int source = intent.getIntExtra("source", 3);
        String hi = intent.getStringExtra("hi");

        if(TextUtils.isEmpty(talker)){
            LogUtils.log(TAG, "好友Talker不能为空！");
            taskLog("", "Talker为空，添加失败");
            return;
        }

        if(TextUtils.isEmpty(hi)){
            LogUtils.log(TAG, "招呼内容不能为空！");
            taskLog(talker, "招呼为空，添加失败");
            return;
        }

        ThreadUtils.runOnWorkerThreadDelayed(1, TimeUnit.SECONDS, new AddFriend(packageParam, talker, source, hi));
        taskLog(talker, "添加成功");
        LogUtils.log(TAG, "添加好友结束");
    }
}
