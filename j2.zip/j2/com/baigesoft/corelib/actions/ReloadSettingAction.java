package com.baigesoft.corelib.actions;

import android.content.Intent;

import com.baigesoft.corelib.Constants;
import com.baigesoft.corelib.db.SettingManager;
import com.baigesoft.corelib.utils.LogUtils;

import de.robv.android.xposed.callbacks.XC_LoadPackage;

/**
 * 重新载入配置
 */
public class ReloadSettingAction extends BaseAction {

    public ReloadSettingAction(Intent intent, XC_LoadPackage.LoadPackageParam packageParam) {
        super(intent, packageParam);
        TAG = "Plugin_ReloadSetting";
    }

    @Override
    public void execute() {
        LogUtils.log(TAG, "收到重新载入配置命令");
        SettingManager settingManager = new SettingManager();
        settingManager.initAccount();
        if (Constants.ACCOUNT == null) {
            LogUtils.log(TAG, "未找到可用微信账号");
        } else {
            LogUtils.log(TAG, "载入账号：" + Constants.ACCOUNT.getUsername());
        }

        settingManager.initKeywordReply();
        LogUtils.log(TAG, "载入" + Constants.KEYWORD_REPLY.size() + "条关键词回复");

        settingManager.initSetting();
        settingManager.initRandomTalk();
        settingManager.initTulingFilter();

        LogUtils.log(TAG, "重新载入配置完成");
    }
}
