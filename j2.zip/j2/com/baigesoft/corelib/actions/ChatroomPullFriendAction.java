package com.baigesoft.corelib.actions;

import android.content.Intent;
import android.text.TextUtils;

import com.baigesoft.corelib.utils.LogUtils;
import com.baigesoft.corelib.wechat.ChatRoomHook;

import java.util.ArrayList;
import java.util.List;

import de.robv.android.xposed.callbacks.XC_LoadPackage;

/**
 * 拉人进群
 */
public class ChatroomPullFriendAction extends BaseAction {

    public ChatroomPullFriendAction(Intent intent, XC_LoadPackage.LoadPackageParam packageParam) {
        super(intent, packageParam);
        TAG = "Plugin_RoomPullMember";
    }

    @Override
    public void execute() {
        String chatroomTalker = intent.getStringExtra("chatroom_talker");
        String talkers = intent.getStringExtra("talkers");

        LogUtils.log(TAG, "收到拉人进群命令：" + chatroomTalker + " : " + talkers);
        if (TextUtils.isEmpty(chatroomTalker)) {
            taskResult(false, "群Talker为空");
            LogUtils.log(TAG, "群Talker为空");
            return;
        }
        if (TextUtils.isEmpty(talkers)) {
            taskResult(false, "成员Talkers为空");
            LogUtils.log(TAG, "成员Talkers为空");
            return;
        }
        String[] talkerArray = TextUtils.split(talkers, ",");
        List<String> talkerList = new ArrayList<>();
        for (String t : talkerArray) {
            talkerList.add(t);
        }

        ChatRoomHook.pullFriend(packageParam.classLoader, chatroomTalker, talkerList);
        taskResult(true, "执行成功");
    }
}
