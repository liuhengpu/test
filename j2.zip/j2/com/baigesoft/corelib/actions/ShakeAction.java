package com.baigesoft.corelib.actions;

import android.content.Intent;

import com.baigesoft.corelib.Constants;
import com.baigesoft.corelib.utils.LogUtils;

import de.robv.android.xposed.callbacks.XC_LoadPackage;

/**
 * 摇一摇
 */
public class ShakeAction extends BaseAction {

    public ShakeAction(Intent intent, XC_LoadPackage.LoadPackageParam packageParam) {
        super(intent, packageParam);
        TAG = "Plugin_Shake";
    }

    @Override
    public void execute() {
        LogUtils.log(TAG, "收到摇一摇命令");
        Constants.isShake = true;
        LogUtils.log(TAG, "摇一摇完成");
    }
}
