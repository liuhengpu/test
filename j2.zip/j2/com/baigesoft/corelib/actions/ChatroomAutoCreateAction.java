package com.baigesoft.corelib.actions;

import android.content.Intent;
import android.os.CountDownTimer;
import android.text.TextUtils;

import com.baigesoft.corelib.db.ContactManager;
import com.baigesoft.corelib.db.SettingManager;
import com.baigesoft.corelib.model.ChatRoom;
import com.baigesoft.corelib.utils.LogUtils;
import com.baigesoft.corelib.wechat.ChatRoomHook;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

import de.robv.android.xposed.callbacks.XC_LoadPackage;

/**
 * 自动建群
 */
public class ChatroomAutoCreateAction extends BaseAction {

    public ChatroomAutoCreateAction(Intent intent, XC_LoadPackage.LoadPackageParam packageParam) {
        super(intent, packageParam);
        TAG = "Plugin_RoomAutoCreate";
    }

    @Override
    public void execute() {
        String names = intent.getStringExtra("names");
        int count = intent.getIntExtra("count", 35);    //每群数量
        int chatroom_count = intent.getIntExtra("chatroom_count", 1);   //建群数量
        int create_type = intent.getIntExtra("create_type", 0); //建群方式:0为断点续建；1为从头建群

        LogUtils.log(TAG, "收到自动建群命令");

        if (TextUtils.isEmpty(names)) {
            taskResult(false, "未设置群名称");
            LogUtils.log(TAG, "未设置群名称");
            return;
        }

        String[] nameArray = names.split("\\|");
        if (nameArray == null || nameArray.length != chatroom_count) {
            taskResult(false, "设置的群名称与群数量不匹配");
            LogUtils.log(TAG, "设置的群名称与群数量不匹配");
            return;
        }

        //取所有好友信息
        List<String> allTalkers = new ContactManager(packageParam.classLoader).getAllTalkers();
        LogUtils.log(TAG, "获取好友数量：" + allTalkers.size());
        //获取已拉入群的好友信息
        Map<String, String> talkerMap = new SettingManager().getCreateChatroomTalkers();

        List<ChatRoom> chatRoomList = new ArrayList<>();
        List<String> talkerList = new ArrayList<>();
        for (String talker : allTalkers) {
            if (create_type == 0 && talkerMap.containsKey(talker)) {
                continue;
            }
            talkerList.add(talker);
            if (talkerList.size() >= count) {
                List<String> tempList = new ArrayList<>();
                for (String str : talkerList) {
                    tempList.add(str);
                }
                ChatRoom chatRoom = new ChatRoom();
                chatRoom.setNickName(nameArray[chatRoomList.size()]);
                chatRoom.setMemberTalkers(talkerList.toArray(new String[]{}));
                chatRoomList.add(chatRoom);

                talkerList.clear();
                if (chatRoomList.size() >= chatroom_count) {
                    break;
                }
            }
        }

        final int timerInterval = 8000;
        new CreateCountDownTimer(timerInterval * (chatRoomList.size() + 1), timerInterval, chatRoomList).start();
    }

    class CreateCountDownTimer extends CountDownTimer {

        private List<ChatRoom> chatRoomList;
        private int index = 0;

        public CreateCountDownTimer(long millisInFuture, long countDownInterval, List<ChatRoom> chatRoomList) {
            super(millisInFuture, countDownInterval);
            this.chatRoomList = chatRoomList;
        }

        @Override
        public void onTick(long millisUntilFinished) {
            if(index >= chatRoomList.size()){
                return;
            }
            ChatRoom chatRoom = chatRoomList.get(index);

            ChatRoomHook.create(packageParam.classLoader, chatRoom.getNickName(), Arrays.asList(chatRoom.getMemberTalkers()));
            new SettingManager().saveCreateChatroomTalkers(Arrays.asList(chatRoom.getMemberTalkers()));

            LogUtils.log(TAG, "建群「" + chatRoom.getNickName() + "」成功");
            taskLog(chatRoom.getNickName(), "建群成功");

            index++;
            LogUtils.log(TAG, "建群「" + chatRoom.getNickName() + "」" + TextUtils.join(",", chatRoom.getMemberTalkers()));
        }

        @Override
        public void onFinish() {
            LogUtils.log(TAG, "自动建群完成，数量: " + chatRoomList.size());
            taskResult(true, "执行成功");
        }
    }
}
