package com.baigesoft.corelib.actions;

import android.content.Intent;

import com.baigesoft.corelib.utils.MessageUtils;

import de.robv.android.xposed.callbacks.XC_LoadPackage;

/**
 * 同步微信群信息
 */
public class ChatroomSyncAction extends BaseAction {

    public ChatroomSyncAction(Intent intent, XC_LoadPackage.LoadPackageParam packageParam) {
        super(intent, packageParam);
        TAG = "Plugin_RoomSync";
    }

    @Override
    public void execute() {
        taskLog("", "开始同步微信群信息");
        int push_id = intent.getIntExtra("push_id", 0);
        MessageUtils.syncChatroom(packageParam.classLoader, push_id, false);
    }
}
