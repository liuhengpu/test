package com.baigesoft.corelib.actions;

import android.content.Intent;
import android.text.TextUtils;

import com.baigesoft.corelib.utils.LogUtils;
import com.baigesoft.corelib.wechat.ChatRoomHook;

import java.util.Arrays;

import de.robv.android.xposed.callbacks.XC_LoadPackage;

/**
 * 给指定的人建群
 */
public class ChatroomCreateAction extends BaseAction {

    public ChatroomCreateAction(Intent intent, XC_LoadPackage.LoadPackageParam packageParam) {
        super(intent, packageParam);
        TAG = "Plugin_RoomCreate";
    }

    @Override
    public void execute() {
        String name = intent.getStringExtra("name");    //群名称
        String talkers = intent.getStringExtra("talkers");  //群成员Talker，多个用逗号分隔

        LogUtils.log(TAG, "收到建群命令");

        if (TextUtils.isEmpty(name)) {
            taskResult(false, "未设置群名称");
            LogUtils.log(TAG, "未设置群名称");
            return;
        }
        if (TextUtils.isEmpty(talkers)) {
            taskResult(false, "未设置群成员");
            LogUtils.log(TAG, "未设置群成员");
            return;
        }

        String[] talkerArray = talkers.split(",");
        if (talkerArray == null || talkerArray.length == 0) {
            taskResult(false, "未设置群成员");
            LogUtils.log(TAG, "未设置群成员");
            return;
        }

        ChatRoomHook.create(packageParam.classLoader, name, Arrays.asList(talkerArray));
        LogUtils.log(TAG, "建群「" + name + "」成功");
        taskLog(name, "建群成功");
        taskResult(true, "执行成功");
    }

}
