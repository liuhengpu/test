package com.baigesoft.corelib.actions;

import android.content.Intent;
import android.text.TextUtils;

import com.baigesoft.corelib.utils.LogUtils;
import com.baigesoft.corelib.wechat.ChatRoomHook;

import de.robv.android.xposed.callbacks.XC_LoadPackage;

/**
 * 修改群公告
 */
public class ChatroomChangeNoticeAction extends BaseAction {

    public ChatroomChangeNoticeAction(Intent intent, XC_LoadPackage.LoadPackageParam packageParam) {
        super(intent, packageParam);
        TAG = "Plugin_RoomChangeNotice";
    }

    @Override
    public void execute() {
        String chatroomTalker = intent.getStringExtra("chatroom_talker");
        String notice = intent.getStringExtra("notice");

        LogUtils.log(TAG, "收到修改群公告命令：" + chatroomTalker + " : " + notice);
        if (TextUtils.isEmpty(chatroomTalker)) {
            taskResult(false, "群Talker为空");
            LogUtils.log(TAG, "群Talker为空");
            return;
        }

        ChatRoomHook.changeNotice(packageParam.classLoader, chatroomTalker, notice);
        taskResult(true, "执行成功");
    }
}
