package com.baigesoft.corelib.actions;

import android.content.Intent;
import android.text.TextUtils;

import com.baigesoft.corelib.utils.LogUtils;
import com.baigesoft.corelib.wechat.ChatRoomHook;

import de.robv.android.xposed.callbacks.XC_LoadPackage;

/**
 * 保存群到通讯录
 */
public class ChatroomSaveToContactAction extends BaseAction {

    public ChatroomSaveToContactAction(Intent intent, XC_LoadPackage.LoadPackageParam packageParam) {
        super(intent, packageParam);
        TAG = "Plugin_RoomSaveContact";
    }

    @Override
    public void execute() {
        String chatroom_talker = intent.getStringExtra("chatroom_talker");
        LogUtils.log(TAG, "收到保存群到通讯录命令：" + chatroom_talker);
        if (TextUtils.isEmpty(chatroom_talker)) {
            taskResult(false, "群Talker为空");
            LogUtils.log(TAG, "群Talker为空");
            return;
        }
        ChatRoomHook.saveToContact(packageParam.classLoader, chatroom_talker);
        taskResult(true, "执行成功");
    }
}
