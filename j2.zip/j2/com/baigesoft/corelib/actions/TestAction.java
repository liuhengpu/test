package com.baigesoft.corelib.actions;

import android.content.Intent;

import com.baigesoft.corelib.utils.LogUtils;

import de.robv.android.xposed.callbacks.XC_LoadPackage;

public class TestAction extends BaseAction {

    public TestAction(Intent intent, XC_LoadPackage.LoadPackageParam packageParam) {
        super(intent, packageParam);
        TAG = "Plugin_TestAction";
    }

    @Override
    public void execute() {
        LogUtils.log(TAG, "收到测试命令");

//        String talker = intent.getStringExtra("talker");
//        if(TextUtils.isEmpty(talker)){
//            LogUtils.log(TAG, "Talker不能为空");
//            return;
//        }
//
//        String cmd = intent.getStringExtra("cmd");
//        if(TextUtils.isEmpty(cmd)){
//            LogUtils.log(TAG, "cmd不能为空");
//            return;
//        }





//        List<ChatRoom> chatRoomList = new ArrayList();
//        ChatRoom chatRoom = new ChatRoom();
//        chatRoom.setTalker("10713221505@chatroom");
//        chatRoom.setNickName("测试群");
//        chatRoomList.add(chatRoom);
//
//        chatRoomList = new ChatRoomManager(packageParam.classLoader).getChatRooms(chatRoomList);
//        if(chatRoomList == null || chatRoomList.isEmpty()){
//            LogUtils.log(TAG, "没有获取到群列表！");
//            return;
//        }
//
//        chatRoom = chatRoomList.get(0);
//
//        ContactManager contactManager = new ContactManager(packageParam.classLoader);
//        for (String talker : chatRoom.getMemberTalkers()) {
//            WechatContact contact = contactManager.getContactWithoutType(talker);
//            if (contact == null) {
//                LogUtils.log(TAG, "没有联系人：" + talker);
//                contact = new WechatContact();
//                contact.setTalker(talker);
//                contact.setAlias("");
//                contact.setNickname(chatRoom.getNickNameMap().get(talker));
//                if(contact.getNickname() == null){
//                    contact.setNickname("");
//                }
//                contact.setEncryptUsername("");
//                contact.setSex(0);
//                contact.setProvince("");
//                contact.setCity("");
//                contact.setArea_en("");
//                contact.setMobile("");
//                contact.setSign("");
//                contact.setFriend_img("");
//            }
//            JSONObject contactObject = new JSONObject();
//            try {
//                contactObject.put("talker", contact.getTalker());
//                contactObject.put("alias", contact.getAlias());
//                contactObject.put("nickname", contact.getNickname());
//                contactObject.put("encryptUsername", contact.getEncryptUsername());
//                contactObject.put("sex", contact.getSex());
//                contactObject.put("province", contact.getProvince());
//                contactObject.put("city", contact.getCity());
//                contactObject.put("area_en", contact.getArea_en());
//                contactObject.put("mobile", contact.getMobile());
//                contactObject.put("sign", contact.getSign());
//                contactObject.put("friend_img", contact.getFriend_img());
//
//                String chatNick = chatRoom.getChatNameMap().get(contact.getTalker());
//                if (TextUtils.isEmpty(chatNick)) {
//                    contactObject.put("chat_nick", "");
//                } else {
//                    contactObject.put("chat_nick", chatNick);
//                }
//            } catch (JSONException ex) {
//            }
//            LogUtils.log(TAG, "群成员：" + contactObject.toString());
//        }

        LogUtils.log(TAG, "测试完成");
    }


}
