package com.baigesoft.corelib.actions;

import android.content.Intent;
import android.os.CountDownTimer;
import android.text.TextUtils;

import com.baigesoft.corelib.db.ChatRoomManager;
import com.baigesoft.corelib.model.ChatRoom;
import com.baigesoft.corelib.utils.LogUtils;
import com.baigesoft.corelib.utils.ThreadUtils;
import com.baigesoft.corelib.wechat.SendImage;
import com.baigesoft.corelib.wechat.SendMessage;
import com.baigesoft.corelib.wechat.SendSmallApp;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import de.robv.android.xposed.callbacks.XC_LoadPackage;

/**
 * 向微信群发送消息
 */
public class ChatroomSendMsgAction extends BaseAction {

    public ChatroomSendMsgAction(Intent intent, XC_LoadPackage.LoadPackageParam packageParam) {
        super(intent, packageParam);
        TAG = "Plugin_RoomSendMsg";
    }

    @Override
    public void execute() {
        int msg_type = intent.getIntExtra("msg_type", 0);
        String keyword = intent.getStringExtra("keyword");
        String content = intent.getStringExtra("content");
        LogUtils.log(TAG, "收到微信群发消息命令");
        taskLog("", "收到微信群发消息命令");

        if (msg_type < 1 || msg_type > 3) {
            taskResult(false, "消息类型错误");
            LogUtils.log(TAG, "消息类型错误！");
            return;
        }
        if (TextUtils.isEmpty(keyword)) {
            taskResult(false, "群名称关键词错误");
            LogUtils.log(TAG, "群名称关键词错误！");
            return;
        }

        String[] keywords = TextUtils.split(keyword, "\\|");

        List<ChatRoom> sendChatroomList = new ArrayList<>();
        List<ChatRoom> chatRoomList = new ChatRoomManager(packageParam.classLoader).getSimpleChatRooms();
        for (ChatRoom chatRoom : chatRoomList) {
            if (TextUtils.isEmpty(chatRoom.getNickName())) {
                continue;
            }
            boolean have = false;
            for (String k : keywords) {
                if (chatRoom.getNickName().contains(k)) {
                    have = true;
                    break;
                }
            }
            if (have) {
                sendChatroomList.add(chatRoom);
            }
        }
        if (sendChatroomList.size() == 0) {
            taskResult(true, "未找到匹配的群");
            return;
        }

        new SendMsgCountDownTimer((sendChatroomList.size() + 1) * 5000, 5000, sendChatroomList, content, msg_type).start();
    }

    /**
     * 向微信群发送消息
     */
    class SendMsgCountDownTimer extends CountDownTimer {

        private List<ChatRoom> chatRoomList;
        private String msg;
        private int msg_type;
        private int index = 0;

        public SendMsgCountDownTimer(long millisInFuture, long countDownInterval, List<ChatRoom> chatRoomList, String msg, int msg_type) {
            super(millisInFuture, countDownInterval);
            this.chatRoomList = chatRoomList;
            this.msg = msg;
            this.msg_type = msg_type;
        }

        @Override
        public void onTick(long millisUntilFinished) {
            if (index >= chatRoomList.size()) {
                return;
            }
            ChatRoom chatRoom = chatRoomList.get(index);
            if (msg_type == 1) {
                ThreadUtils.runOnWorkerThreadDelayed(1, TimeUnit.SECONDS, new SendMessage(packageParam, chatRoom.getTalker(), msg));
            } else if (msg_type == 2) {
                ThreadUtils.runOnWorkerThreadDelayed(2, TimeUnit.SECONDS, new SendImage(packageParam, chatRoom.getTalker(), msg));
            } else if (msg_type == 3) {
                JSONObject jsonObject = null;
                try {
                    jsonObject = new JSONObject(msg);
                } catch (JSONException ex) {
                    LogUtils.log(TAG, "解析json失败");
                }
                if (jsonObject != null) {
                    String title = jsonObject.optString("title", "");
                    String name = jsonObject.optString("name", "");
                    String img = jsonObject.optString("img", "");
                    String path = jsonObject.optString("page", "");
                    String appid = jsonObject.optString("appid", "");
                    String gh = jsonObject.optString("gh", "");
                    ThreadUtils.runOnWorkerThreadDelayed(2, TimeUnit.SECONDS, new SendSmallApp(packageParam.classLoader, chatRoom.getTalker(),
                            title, img, gh, appid, name, path));
                }

            }
            LogUtils.log(TAG, "发送到「" + chatRoom.getNickName() + "」成功");
            taskLog(chatRoom.getNickName(), "发送成功");
            index++;
        }

        @Override
        public void onFinish() {
            taskResult(true, "成功发送到" + chatRoomList.size() + "个群");
        }
    }
}
