package com.baigesoft.corelib.actions;

import android.content.Intent;

import com.baigesoft.corelib.utils.LogUtils;
import com.baigesoft.corelib.utils.ThreadUtils;
import com.baigesoft.corelib.wechat.SendImage;

import java.util.concurrent.TimeUnit;

import de.robv.android.xposed.callbacks.XC_LoadPackage;

/**
 * 发送图片消息
 */
public class SendImageAction extends BaseAction {

    public SendImageAction(Intent intent, XC_LoadPackage.LoadPackageParam packageParam) {
        super(intent, packageParam);
        TAG = "Plugin_SendImage";
    }

    @Override
    public void execute() {
        LogUtils.log(TAG, "收到发送图片命令");
        String talker = intent.getStringExtra("talker");
        String img = intent.getStringExtra("img");
        ThreadUtils.runOnWorkerThreadDelayed(2, TimeUnit.SECONDS, new SendImage(packageParam, talker, img));
        LogUtils.log(TAG, "发送图片完成");
    }
}
