package com.baigesoft.corelib.actions;

import android.content.Intent;
import android.text.TextUtils;

import com.baigesoft.corelib.db.UserManager;
import com.baigesoft.corelib.utils.LogUtils;
import com.baigesoft.corelib.wechat.ChatRoomHook;

import de.robv.android.xposed.callbacks.XC_LoadPackage;

/**
 * 修改群昵称
 */
public class ChatroomChangeNickNameAction extends BaseAction {

    public ChatroomChangeNickNameAction(Intent intent, XC_LoadPackage.LoadPackageParam packageParam) {
        super(intent, packageParam);
        TAG = "Plugin_RoomChangeNick";
    }

    @Override
    public void execute() {
        String chatroomTalker = intent.getStringExtra("chatroom_talker");
        String nickname = intent.getStringExtra("nickname");
        String talker = new UserManager(packageParam.classLoader).getTalkerId();

        LogUtils.log(TAG, "收到修改群昵称命令：" + chatroomTalker + " : " + nickname);
        if (TextUtils.isEmpty(chatroomTalker)) {
            taskResult(false, "群Talker为空");
            LogUtils.log(TAG, "群Talker为空");
            return;
        }
        if (TextUtils.isEmpty(nickname)) {
            taskResult(false, "群昵称为空");
            LogUtils.log(TAG, "群昵称为空");
            return;
        }

        ChatRoomHook.changeNickname(packageParam.classLoader, talker, chatroomTalker, nickname);
        taskResult(true, "执行成功");
    }
}
