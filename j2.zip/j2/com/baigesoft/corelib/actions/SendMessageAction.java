package com.baigesoft.corelib.actions;

import android.content.Intent;

import com.baigesoft.corelib.utils.LogUtils;
import com.baigesoft.corelib.utils.ThreadUtils;
import com.baigesoft.corelib.wechat.SendMessage;

import java.util.concurrent.TimeUnit;

import de.robv.android.xposed.callbacks.XC_LoadPackage;

/**
 * 发送文本消息
 */
public class SendMessageAction extends BaseAction {

    public SendMessageAction(Intent intent, XC_LoadPackage.LoadPackageParam packageParam) {
        super(intent, packageParam);
        TAG = "Plugin_SendMsg";
    }

    @Override
    public void execute() {
        LogUtils.log(TAG, "收到发送消息命令");
        String talker = intent.getStringExtra("talker");
        String msg = intent.getStringExtra("msg");
        ThreadUtils.runOnWorkerThreadDelayed(1, TimeUnit.SECONDS, new SendMessage(packageParam, talker, msg));
        LogUtils.log(TAG, "发送消息完成");
    }
}
