package com.baigesoft.corelib.actions;

import android.content.Intent;

import com.baigesoft.corelib.db.UserManager;
import com.baigesoft.corelib.model.WechatUser;
import com.baigesoft.corelib.utils.LogUtils;
import com.baigesoft.corelib.utils.MessageUtils;

import de.robv.android.xposed.callbacks.XC_LoadPackage;

/**
 * 同步微信用户信息
 */
public class SyncUserAction extends BaseAction {

    public SyncUserAction(Intent intent, XC_LoadPackage.LoadPackageParam packageParam) {
        super(intent, packageParam);
        TAG = "Plugin_SyncUser";
    }

    @Override
    public void execute() {
        LogUtils.log(TAG, "收到同步微信命令");
        taskLog("", "收到同步微信命令");
        int push_id = intent.getIntExtra("push_id", 0);
        LogUtils.log(TAG, "开始同步微信信息，push_id=" + push_id);
        WechatUser wechatUser = new UserManager(packageParam.classLoader).getUserInfo();
        LogUtils.log(TAG, "获取微信信息完成，开始上传");
        LogUtils.log(TAG, wechatUser.toString());
        MessageUtils.syncUserInfo(wechatUser, push_id);
    }
}
