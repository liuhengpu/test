package com.baigesoft.corelib.actions;

import android.content.Intent;
import android.text.TextUtils;

import com.baigesoft.corelib.utils.LogUtils;
import com.baigesoft.corelib.utils.ThreadUtils;
import com.baigesoft.corelib.wechat.FriendLabel;

import java.util.ArrayList;
import java.util.List;

import de.robv.android.xposed.callbacks.XC_LoadPackage;

/**
 * 给好友打标签
 */
public class LabelFriendAction extends BaseAction {

    public LabelFriendAction(Intent intent, XC_LoadPackage.LoadPackageParam packageParam) {
        super(intent, packageParam);
        TAG = "Plugin_LabelFriend";
    }

    @Override
    public void execute() {
        LogUtils.log(TAG, "收到给好友打标签命令");

        String label = intent.getStringExtra("label");
        String[] temp = label.split(",");
        if (temp == null) {
            LogUtils.log(TAG, "标签参数为空");
            return;
        }
        final List<String> labelList = new ArrayList<>();
        for (String str : temp) {
            labelList.add(str);
        }

        final String talker = intent.getStringExtra("talker");
        if (TextUtils.isEmpty(talker)) {
            LogUtils.log(TAG, "talker参数为空");
            return;
        }

        ThreadUtils.runOnWorkerThread(new Runnable() {
            @Override
            public void run() {
                FriendLabel.labelFriend(packageParam.classLoader, talker, labelList);
            }
        });

        LogUtils.log(TAG, "打标签结束");
    }
}
