package com.baigesoft.corelib.actions;

import android.content.Intent;
import android.text.TextUtils;

import com.baigesoft.corelib.utils.LogUtils;
import com.baigesoft.corelib.wechat.ChatRoomHook;

import de.robv.android.xposed.callbacks.XC_LoadPackage;

/**
 * 从群中踢人
 */
public class ChatroomDeleteMemberAction extends BaseAction {

    public ChatroomDeleteMemberAction(Intent intent, XC_LoadPackage.LoadPackageParam packageParam) {
        super(intent, packageParam);
        TAG = "Plugin_RoomDelMember";
    }

    @Override
    public void execute() {
        String chatroomTalker = intent.getStringExtra("chatroom_talker");
        String talker = intent.getStringExtra("talker");

        LogUtils.log(TAG, "收到踢人命令：" + chatroomTalker + " : " + talker);
        if (TextUtils.isEmpty(chatroomTalker)) {
            taskResult(false, "群Talker为空");
            LogUtils.log(TAG, "群Talker为空");
            return;
        }
        if (TextUtils.isEmpty(talker)) {
            taskResult(false, "成员Talker为空");
            LogUtils.log(TAG, "成员Talker为空");
            return;
        }

        ChatRoomHook.deleteMember(packageParam.classLoader, chatroomTalker, talker);
        taskResult(true, "执行成功");
    }
}
