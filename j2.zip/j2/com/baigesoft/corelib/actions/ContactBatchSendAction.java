package com.baigesoft.corelib.actions;

import android.content.Intent;
import android.os.CountDownTimer;

import com.baigesoft.corelib.db.ContactManager;
import com.baigesoft.corelib.db.TalkerManager;
import com.baigesoft.corelib.utils.LogUtils;
import com.baigesoft.corelib.utils.ThreadUtils;
import com.baigesoft.corelib.utils.WechatUtils;
import com.baigesoft.corelib.wechat.SendImage;
import com.baigesoft.corelib.wechat.SendMessage;
import com.baigesoft.corelib.wechat.SendSmallApp;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import de.robv.android.xposed.callbacks.XC_LoadPackage;

public class ContactBatchSendAction extends BaseAction {

    public ContactBatchSendAction(Intent intent, XC_LoadPackage.LoadPackageParam packageParam) {
        super(intent, packageParam);
        TAG = "Plugin_ContactSend";
    }

    @Override
    public void execute() {

        //消息类型
        int msg_type = intent.getIntExtra("msg_type", 0);

        //发送内容
        String content = intent.getStringExtra("content");

        //发送数量
        int count = intent.getIntExtra("count", 0);

        //延时时间：单位:秒
        int interval = intent.getIntExtra("interval", 5);

        //如果所有好友都发过一次了，是否从头发送：0为不发送；1为从头发送
        int resend = intent.getIntExtra("resend", 0);

        LogUtils.log(TAG, "收到群发消息命令");
        taskLog("", "收到群发消息命令");

        if (msg_type < 1 || msg_type > 3) {
            taskResult(false, "消息类型错误");
            LogUtils.log(TAG, "消息类型错误！");
            return;
        }

        //取所有好友信息
        List<String> allTalkers = new ContactManager(packageParam.classLoader).getAllTalkers();
        LogUtils.log(TAG, "获取好友数量：" + allTalkers.size());
        //获取已经发送的好友信息
        String suffix = "" + msg_type;
        List<String> talkerList = getTalkerList(allTalkers, count, suffix);

        //所有好友都发过一次了，处理从头发送的逻辑
        if (resend == 1 && talkerList.size() == 0) {
            new TalkerManager().clear(suffix);
            talkerList = getTalkerList(allTalkers, count, suffix);
        }

        if (talkerList.isEmpty()) {
            LogUtils.log(TAG, "群发消息完成，没有符合条件的好友");
            taskResult(true, "执行成功");
            return;
        }

        final int timerInterval = interval * 1000;
        new SendCountDownTimer(timerInterval * (talkerList.size() + 1), timerInterval, talkerList, content, msg_type).start();
    }

    /**
     * 获取此次发送的好友列表
     *
     * @param allTalkers
     * @param count
     * @param suffix
     * @return
     */
    private List<String> getTalkerList(List<String> allTalkers, int count, String suffix) {
        TalkerManager talkerManager = new TalkerManager();
        Map<String, String> sendedTalkerMap = talkerManager.getAll(suffix);
        List<String> talkerList = new ArrayList<>();
        for (String talker : allTalkers) {
            if (sendedTalkerMap.containsKey(talker) || WechatUtils.skipTalker(talker)) {
                continue;
            }
            talkerList.add(talker);
            if (talkerList.size() >= count) {
                break;
            }
        }
        talkerManager.append(talkerList, suffix);
        return talkerList;
    }

    class SendCountDownTimer extends CountDownTimer {

        private List<String> talkerList;
        private int index = 0;
        private String msg;
        private int msg_type;

        public SendCountDownTimer(long millisInFuture, long countDownInterval, List<String> talkerList, String msg, int msg_type) {
            super(millisInFuture, countDownInterval);
            this.talkerList = talkerList;
            this.msg = msg;
            this.msg_type = msg_type;
        }

        @Override
        public void onTick(long millisUntilFinished) {
            if (index >= talkerList.size()) {
                return;
            }

            String talker = talkerList.get(index);
            if (msg_type == 1) {
                ThreadUtils.runOnWorkerThreadDelayed(1, TimeUnit.SECONDS, new SendMessage(packageParam, talker, msg));
            } else if (msg_type == 2) {
                ThreadUtils.runOnWorkerThreadDelayed(2, TimeUnit.SECONDS, new SendImage(packageParam, talker, msg));
            } else if (msg_type == 3) {
                JSONObject jsonObject = null;
                try {
                    jsonObject = new JSONObject(msg);
                } catch (JSONException ex) {
                    LogUtils.log(TAG, "解析json失败");
                }
                if (jsonObject != null) {
                    String title = jsonObject.optString("title", "");
                    String name = jsonObject.optString("name", "");
                    String img = jsonObject.optString("img", "");
                    String path = jsonObject.optString("page", "");
                    String appid = jsonObject.optString("appid", "");
                    String gh = jsonObject.optString("gh", "");
                    ThreadUtils.runOnWorkerThreadDelayed(2, TimeUnit.SECONDS, new SendSmallApp(packageParam.classLoader, talker,
                            title, img, gh, appid, name, path));
                }

            }
            LogUtils.log(TAG, "发送到「" + talker + "」成功");
            taskLog(talker, "发送成功");
            index++;
        }

        @Override
        public void onFinish() {
            LogUtils.log(TAG, "群发消息完成，数量: " + talkerList.size());
            taskResult(true, "执行成功");
        }
    }
}
