package com.baigesoft.corelib.actions;

import android.content.Intent;

import com.baigesoft.corelib.utils.MessageUtils;

import org.json.JSONException;
import org.json.JSONObject;

import de.robv.android.xposed.callbacks.XC_LoadPackage;

public abstract class BaseAction {

    protected static String TAG = "Plugin_BaseAction";

    protected Intent intent;

    protected XC_LoadPackage.LoadPackageParam packageParam;

    public BaseAction(Intent intent, XC_LoadPackage.LoadPackageParam packageParam) {
        this.intent = intent;
        this.packageParam = packageParam;
    }

    /**
     * 添加日志
     * @param target
     * @param msg
     */
    protected void taskLog(String target, String msg){
        int push_id = intent.getIntExtra("push_id", 0);
        if(push_id <= 0){
            return;
        }
        MessageUtils.taskLog(push_id, target, msg);
    }

    /**
     * 反馈任务结果
     * @param success
     * @param msg
     */
    protected void taskResult(boolean success, String msg){
        JSONObject jsonObject = new JSONObject();
        try {
            jsonObject.put("msg", msg);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        taskResult(success, jsonObject);
    }

    /**
     * 反馈任务结果
     * @param success
     * @param jsonObject
     */
    protected void taskResult(boolean success, JSONObject jsonObject){
        int push_id = intent.getIntExtra("push_id", 0);
        if(push_id <= 0 || jsonObject == null){
            return;
        }
        MessageUtils.taskResult(push_id, success, jsonObject.toString());
    }

    public abstract void execute();
}
