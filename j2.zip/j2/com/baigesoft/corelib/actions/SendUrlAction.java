package com.baigesoft.corelib.actions;

import android.content.Intent;

import com.baigesoft.corelib.db.UserManager;
import com.baigesoft.corelib.model.WechatUser;
import com.baigesoft.corelib.utils.LogUtils;
import com.baigesoft.corelib.utils.ThreadUtils;
import com.baigesoft.corelib.wechat.SendUrl;

import java.util.concurrent.TimeUnit;

import de.robv.android.xposed.callbacks.XC_LoadPackage;

/**
 * 发送链接消息
 */
public class SendUrlAction extends BaseAction {

    public SendUrlAction(Intent intent, XC_LoadPackage.LoadPackageParam packageParam) {
        super(intent, packageParam);
        TAG = "Plugin_SendUrl";
    }

    @Override
    public void execute() {
        LogUtils.log(TAG, "收到发送链接命令");
        String talker = intent.getStringExtra("talker");
        String url = intent.getStringExtra("url");
        String thumbnail = intent.getStringExtra("thumb");
        String title = intent.getStringExtra("title");
        String description = intent.getStringExtra("desc");
        WechatUser wechatUser = new UserManager(packageParam.classLoader).getUserInfo();
        ThreadUtils.runOnWorkerThreadDelayed(1, TimeUnit.SECONDS, new SendUrl(packageParam, wechatUser.talkerId, talker, url, thumbnail, title, description));
        LogUtils.log(TAG, "发送链接完成");
    }
}
