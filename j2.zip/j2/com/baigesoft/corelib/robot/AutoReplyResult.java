package com.baigesoft.corelib.robot;

public class AutoReplyResult {

    private int message_type;

    private String reply;

    /**
     * 图片原始地址
     */
    private String url;

    public AutoReplyResult() {
    }

    public AutoReplyResult(int message_type, String reply) {
        this.message_type = message_type;
        this.reply = reply;
    }

    public int getMessage_type() {
        return message_type;
    }

    public void setMessage_type(int message_type) {
        this.message_type = message_type;
    }

    public String getReply() {
        return reply;
    }

    public void setReply(String reply) {
        this.reply = reply;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }
}
