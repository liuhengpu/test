package com.baigesoft.corelib.robot;

import android.text.TextUtils;

import com.baigesoft.corelib.Constants;
import com.baigesoft.corelib.db.SettingManager;
import com.baigesoft.corelib.utils.EmojUtils;
import com.baigesoft.corelib.utils.HttpUtils;
import com.baigesoft.corelib.utils.JsonResponseHandler;
import com.baigesoft.corelib.utils.LogUtils;
import com.baigesoft.corelib.utils.StringUtils;

import org.json.JSONArray;
import org.json.JSONObject;

/**
 * Created by Dawei on 01/08/2017.
 */

public class TuLing {

    private static final String TAG = "Plugin_TuLing";

    private static final String URL = "http://www.tuling123.com/openapi/api";

    private String userid;

    private TuLing() {
    }

    public TuLing(String userid) {
        this.userid = userid;
    }

    /**
     * 和图灵机器人对话
     *
     * @param msg
     * @return
     */
    public String talk(String msg) {
        String result = "";
        for (int i = 0; i < 5; i++) {
            result = sendMsg(msg);
            if ("error_key".equals(result)) {
                return "";
            }
            if (!TextUtils.isEmpty(result)) {
                return result;
            }
        }
        return result;
    }

    /**
     * 向机器人发送信息
     *
     * @param msg
     * @return
     */
    private String sendMsg(String msg) {
        final String key = getTuLingKey();
        if (TextUtils.isEmpty(key)) {
            LogUtils.log(TAG, "没有可用的图灵key");
            return "error_key";
        }
        String param = "{\n\"key\": \"" + key + "\",\"info\":  \"" + msg + "\",\"userid\": \"" + userid + "\"}";

        final String[] text = new String[1];
        try {
            HttpUtils.postJson(URL, param, new JsonResponseHandler() {
                @Override
                public void success(JSONObject jsonObject) {
                    if (jsonObject == null) {
                        LogUtils.log(TAG, "图灵未返回内容");
                        return;
                    }
                    LogUtils.log(TAG, "图灵：" + jsonObject.toString());
                    int code = jsonObject.optInt("code", 0);
                    if (code == 40001 || code == 40004 || code == 40002 || code == 40007) {
                        Constants.TULING_FILTER.put(key, "");
                        new SettingManager().saveTulingFilter();
                        return;
                    }

                    String txt = jsonObject.optString("text", "");
                    if (TextUtils.isEmpty(txt)) {
                        return;
                    }

                    text[0] = formatContent(jsonObject);
                }

                @Override
                public void failure(String responseString) {
                    LogUtils.log(TAG, "请求图灵出错：" + responseString);
                }
            });
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return text[0];
    }

    private String formatContent(JSONObject jsonObject) {
        if (jsonObject == null) {
            return "";
        }

        String text = jsonObject.optString("text", "");
        if (TextUtils.isEmpty(jsonObject.optString("text"))) {
            return "";
        }

        if (text.contains("{face:")) {
            String face = StringUtils.subString(text, "{face:", "}");
            if (!(face == null || face.trim().isEmpty())) {
                String emoj = "";
                if (isNaN(face)) {
                    try {
                        emoj = EmojUtils.getEmoj(Integer.valueOf(face).intValue());
                    } catch (Exception e) {
                        emoj = "";
                    }
                }
                text = text.replace("{face:" + face + "}", emoj);
            }
        }
        text = text.replace("{br}", "");
        text = text.replace("网友", "");
        if (text.contains("机器人")) {
            text = text.replace("机器人", "我").replace("不如问我", "");
        }
        if (text.equals("我是机器人")) {
            text = "/::,@"; //闲
        }
        if (text.contains("您的机器人已被禁用")) {
            text = "/::Z"; //睡
        }
        if (text.contains("抱歉") && text.contains("找到相关的信息")) {
            text = "/::)";  //微笑
        }
        if (text.contains("当天请求次数已")) {
            text = "/::)";  //微笑
        }
        if (text.contains("不明白你说的")) {
            text = "";
        }
        if (!text.contains("http")) {
            if (!text.contains("www.")) {
                if (!text.contains("网址")) {
                    if (text.contains("去看")) {
                        text = "";
                    }
                    if (text.contains("相关信息")) {
                        text = "";
                    }
                    if (text.contains("发的什么呀你")) {
                        text = "";
                    }
                    if (text.contains("无法理解您的话")) {
                        text = "";
                    }
                    if (text.contains("这样的信息是干嘛的")) {
                        text = "";
                    }
                    if (text.contains("梅州行网站")) {
                        text = "";
                    }
                    if (text.contains("不明白你说啥")) {
                        text = "";
                    }
                    if (text.contains("更新") && text.contains("维护")) {
                        text = "";
                    }
                }
            }
        }
        return text;
    }

    private static boolean isNaN(String str) {
        for (char c : str.toCharArray()) {
            if (!Character.isDigit(c)) {
                return false;
            }
        }
        return true;
    }

    private static String getTuLingKey() {
        String tulingKey = "";
        if (Constants.SETTING != null && Constants.SETTING.has("tuling_keys")) {
            JSONArray jsonArray = Constants.SETTING.optJSONArray("tuling_keys");
            for (int i = 0; i < jsonArray.length(); i++) {
                String key = jsonArray.optString(i);
                if (!Constants.TULING_FILTER.containsKey(key)) {
                    tulingKey = key;
                    break;
                }
            }
        }
        if (!TextUtils.isEmpty(tulingKey)) {
            return tulingKey;
        }
        return "";
    }

}
