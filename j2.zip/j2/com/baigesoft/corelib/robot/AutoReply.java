package com.baigesoft.corelib.robot;

import android.os.Environment;
import android.text.TextUtils;

import com.baigesoft.corelib.Constants;
import com.baigesoft.corelib.WechatHook;
import com.baigesoft.corelib.db.SettingManager;
import com.baigesoft.corelib.model.KeywordReply;
import com.baigesoft.corelib.model.WechatMessageType;
import com.baigesoft.corelib.utils.FileUtils;
import com.baigesoft.corelib.utils.HttpUtils;
import com.baigesoft.corelib.utils.LogUtils;
import com.baigesoft.corelib.utils.RandomUtils;

import org.json.JSONException;

import java.io.File;
import java.util.Random;

/**
 * Created by Dawei on 15/01/2018.
 */

public class AutoReply {

    private static final String TAG = "Plugin_AutoReply";

    private static Random random = new Random();

    private static final String[] END_MESSAGE = new String[]{"/::-O", "那就先这样 下次再聊", "等会聊 有点事先处理下", "没什么可聊了 下线了 拜拜", "有事 闪人", "/::X", "上个厕所先886", "心情不好 不聊了", "我要去忙了 跟你聊天真的觉得时间过得好快", "/:bye", "洗洗睡吧~ 明天还得搬砖~ ", "/:break", "哦 呵呵",};

    /**
     * 获取自动回复内容
     *
     * @param content
     * @param talker
     * @return
     */
    public static AutoReplyResult reply(String content, String talker) {
        if (Constants.ACCOUNT == null) {
            return null;
        }

        if (talker.endsWith("@chatroom")) {
            LogUtils.log(TAG, "群不进行自动回复");
            return null;
        }

        //关键词回复
        if (Constants.KEYWORD_REPLY != null && Constants.KEYWORD_REPLY.size() > 0) {
            for (String key : Constants.KEYWORD_REPLY.keySet()) {
                if (content.contains(key)) {
                    KeywordReply keywordReply = Constants.KEYWORD_REPLY.get(key);
                    if (keywordReply.getType() == 0) {
                        if (keywordReply.getContent_type() == 1) {
                            return new AutoReplyResult(WechatMessageType.TEXT, keywordReply.getReply());
                        } else if (keywordReply.getContent_type() == 2) {
                            AutoReplyResult autoReplyResult = new AutoReplyResult(WechatMessageType.IMAGE, keywordReply.getReply());
                            autoReplyResult.setUrl(keywordReply.getUrl());
                            return autoReplyResult;
                        }
                    }
                    if (keywordReply.getType() == 1 && content.equals(key)) {
                        if (keywordReply.getContent_type() == 1) {
                            return new AutoReplyResult(WechatMessageType.TEXT, keywordReply.getReply());
                        } else if (keywordReply.getContent_type() == 2) {
                            AutoReplyResult autoReplyResult = new AutoReplyResult(WechatMessageType.IMAGE, keywordReply.getReply());
                            autoReplyResult.setUrl(keywordReply.getUrl());
                            return autoReplyResult;
                        }
                    }
                }
            }
        }

        if (Constants.ACCOUNT.getAuto_reply() == 0) {
            return null;
        }

        //只为部分用户启用自动聊天
        if (Constants.ACCOUNT.getAuto_reply() == 2) {
            if (!Constants.ACCOUNT.getReplyTalkers().containsKey(talker)) {
                return null;
            }
        }

        //图灵机器人回复
        String msg = new TuLing("user_" + WechatHook.getSn()).talk(content);
        if (TextUtils.isEmpty(msg)) {
            return null;
        }
        return new AutoReplyResult(WechatMessageType.TEXT, msg);
    }

    /**
     * 获取随机聊天内容
     *
     * @param content
     * @param talker
     * @return
     */
    public static AutoReplyResult randomTalk(String content, String talker) {
        if (talker.endsWith("@chatroom")) {
            LogUtils.log(TAG, "群不进行自动回复");
            return null;
        }

        if (Constants.RANDOM_TALK == null || !Constants.RANDOM_TALK.has("talker")) {
            return null;
        }

        //超过一小时了
        long lastTime = Constants.RANDOM_TALK.optLong("last_time", 0L);
        if (System.currentTimeMillis() / 1000 - lastTime > 3600) {
            Constants.RANDOM_TALK = null;
            new SettingManager().removeRandomTalk();
            LogUtils.log(TAG, "[随机聊天]超过一小时，删除配置");
            return null;
        }

        if (!talker.equals(Constants.RANDOM_TALK.optString("talker"))) {
            LogUtils.log(TAG, "[随机聊天]不是聊天目标");
            return null;
        }

        //图灵机器人回复
        String msg = new TuLing("user_" + WechatHook.getSn()).talk(content);

        //没有找到回复消息则发送结束语
        if (TextUtils.isEmpty(msg)) {
            LogUtils.log(TAG, "[随机聊天]图灵未返回内容，结束聊天");
            msg = END_MESSAGE[random.nextInt(END_MESSAGE.length)];
            Constants.RANDOM_TALK = null;
            new SettingManager().removeRandomTalk();
            return new AutoReplyResult(WechatMessageType.TEXT, msg);
        }

        //判断次数
        int count = Constants.RANDOM_TALK.optInt("count", 0);
        if (count > 1) {
            try {
                Constants.RANDOM_TALK.put("count", --count);
                Constants.RANDOM_TALK.put("last_time", System.currentTimeMillis() / 1000);
            } catch (JSONException ex) {
            }
            new SettingManager().saveRandomTalk();
        } else {
            msg = END_MESSAGE[random.nextInt(END_MESSAGE.length)];
            Constants.RANDOM_TALK = null;
            new SettingManager().removeRandomTalk();
        }
        if (TextUtils.isEmpty(msg)) {
            return null;
        }

        return new AutoReplyResult(WechatMessageType.TEXT, msg);
    }

    /**
     * 获取随机语音聊天内容
     *
     * @param talker
     * @return
     */
    public static String randomTalkVoice(String talker) {
        if (talker.endsWith("@chatroom")) {
            LogUtils.log(TAG, "群不进行自动回复");
            return null;
        }

        if (Constants.RANDOM_TALK == null || !Constants.RANDOM_TALK.has("talker")) {
            return null;
        }

        //超过一小时了
        long lastTime = Constants.RANDOM_TALK.optLong("last_time", 0L);
        if (System.currentTimeMillis() / 1000 - lastTime > 3600) {
            Constants.RANDOM_TALK = null;
            new SettingManager().removeRandomTalk();
            LogUtils.log(TAG, "[随机聊天]超过一小时，删除配置");
            return null;
        }

        if (!talker.equals(Constants.RANDOM_TALK.optString("talker"))) {
            LogUtils.log(TAG, "[随机聊天]不是聊天目标");
            return null;
        }

        String voice = downloadTts();
        //没有找到回复消息则结束聊天
        if (TextUtils.isEmpty(voice)) {
            LogUtils.log(TAG, "[随机聊天]下载语音失败，结束聊天");
            Constants.RANDOM_TALK = null;
            new SettingManager().removeRandomTalk();
            return null;
        }


        //判断次数
        int count = Constants.RANDOM_TALK.optInt("count", 0);
        if (count > 1) {
            try {
                Constants.RANDOM_TALK.put("count", --count);
                Constants.RANDOM_TALK.put("last_time", System.currentTimeMillis() / 1000);
            } catch (JSONException ex) {
            }
            new SettingManager().saveRandomTalk();
        } else {
            Constants.RANDOM_TALK = null;
            new SettingManager().removeRandomTalk();
        }
        return voice;
    }

    /**
     * 获取自动回复内容
     *
     * @param talker
     * @return
     */
    public static String replyVoice(String talker) {
        if (Constants.ACCOUNT == null) {
            return null;
        }

        if (talker.endsWith("@chatroom")) {
            LogUtils.log(TAG, "群不进行自动回复");
            return null;
        }

        if (Constants.ACCOUNT.getAuto_reply() != 2) {
            return null;
        }

        //只为部分用户启用自动聊天
        if (!Constants.ACCOUNT.getReplyTalkers().containsKey(talker)) {
            return null;
        }
        return downloadTts();
    }

    /**
     * 下载语音消息
     *
     * @return
     */
    private static String downloadTts() {
        int fileIndex = RandomUtils.randomInt(0, 10000);
        String url = Constants.OSS_URL + "/tts/" + fileIndex + ".amr";

        byte[] bytes = HttpUtils.download(url);
        //没有找到回复消息则结束聊天
        if (bytes == null) {
            return null;
        }

        String path = "";
        try {
            String fileName = "voice/" + fileIndex + ".amr";
            File externalStoragePublicDirectory = Environment.getExternalStoragePublicDirectory(Constants.PUBLIC_DIRECTORY);
            if (!externalStoragePublicDirectory.exists()) {
                externalStoragePublicDirectory.mkdir();
            }
            File attachmentDirectory = new File(externalStoragePublicDirectory, "voice");
            if (!attachmentDirectory.exists()) {
                attachmentDirectory.mkdir();
            }
            File file = new File(externalStoragePublicDirectory, fileName);
            FileUtils.writeFile(file, bytes);
            path = file.getAbsolutePath();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return path;
    }

}
