package com.baigesoft.corelib.wechat;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.text.TextUtils;

import com.baigesoft.corelib.config.WechatConfig;
import com.baigesoft.corelib.utils.LogUtils;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.net.URL;
import java.net.URLConnection;

import de.robv.android.xposed.XposedHelpers;

public class SendSmallApp implements Runnable {

    private static final String TAG = "Plugin_SendSmallApp";

    private ClassLoader classLoader;

    //目标接收者
    private String talker;

    //转发标题
    private String title;

    //小程序图片路径
    private String imagePath;

    //公众号id，如gh_da37e769a664
    private String gh;

    //小程序appid，如wxdc2909b7b61bb6ae
    private String appId;

    //小程序名称
    private String name;

    //小程序页面
    private String url;

    public SendSmallApp(ClassLoader classLoader, String talker, String title, String imagePath, String gh, String appId, String name, String url) {
        this.classLoader = classLoader;
        this.talker = talker;
        this.title = title;
        this.imagePath = imagePath;
        this.gh = gh;
        this.appId = appId;
        this.name = name;
        this.url = url;
    }

    @Override
    public void run() {
        if(TextUtils.isEmpty(talker)){
            LogUtils.log(TAG, "Talker为空");
            return;
        }
        if(TextUtils.isEmpty(title)){
            LogUtils.log(TAG, "title为空");
            return;
        }
        if(TextUtils.isEmpty(imagePath)){
            LogUtils.log(TAG, "img为空");
            return;
        }
        if(TextUtils.isEmpty(gh)){
            LogUtils.log(TAG, "gh为空");
            return;
        }
        if(TextUtils.isEmpty(appId)){
            LogUtils.log(TAG, "appid为空");
            return;
        }
        if(TextUtils.isEmpty(name)){
            LogUtils.log(TAG, "name为空");
            return;
        }
        if(TextUtils.isEmpty(url)){
            LogUtils.log(TAG, "url为空");
            return;
        }

        send();
    }

    public void send() {
        gh = gh + "@app";

        Class classModelU = XposedHelpers.findClass(WechatConfig.APP_BRAND_CLASS_SESSION, this.classLoader);
        String sessionId = (String) XposedHelpers.callStaticMethod(classModelU, WechatConfig.APP_BRAND_METNOD_CREATE_SESSION, new Object[]{"wxapp_" + appId});

        Object modelU = XposedHelpers.callStaticMethod(classModelU, WechatConfig.APP_BRAND_METHOD_GET_OBJECT);

        String formatedAppId = "wxapp_" + appId;
        XposedHelpers.callMethod(XposedHelpers.callMethod(modelU, WechatConfig.APP_BRAND_METHOD_GET_B, sessionId, Boolean.valueOf(true)), WechatConfig.APP_BRAND_METHOD_B_PRE_PUBLISH, "prePublishId", formatedAppId);

        Object smallAppObject = null;
        try {
            smallAppObject = XposedHelpers.findClass(WechatConfig.APP_BRAND_CLASS_MODEL, this.classLoader).newInstance();
        } catch (InstantiationException e) {
            e.printStackTrace();
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        }
        XposedHelpers.setObjectField(smallAppObject, WechatConfig.APP_BRAND_MODEL_FIELD_TITLE, title);
        LogUtils.log(TAG, "title : " + title);
        XposedHelpers.setObjectField(smallAppObject, WechatConfig.APP_BRAND_MODEL_FIELD_XCXNAME, name);
        LogUtils.log(TAG, "name :" + name);
        XposedHelpers.setIntField(smallAppObject, "type", 33);
        XposedHelpers.setIntField(smallAppObject, WechatConfig.APP_BRAND_MODEL_FIELD_10, 10);
        XposedHelpers.setIntField(smallAppObject, WechatConfig.APP_BRAND_MODEL_FIELD_TYPE, 2);
        XposedHelpers.setObjectField(smallAppObject, WechatConfig.APP_BRAND_MODEL_FIELD_USERNAME, gh);
        XposedHelpers.setObjectField(smallAppObject, WechatConfig.APP_BRAND_MODEL_FIELD_IMG_PATH, imagePath);
        XposedHelpers.setObjectField(smallAppObject, WechatConfig.APP_BRAND_MODEL_FIELD_GH, gh);
        XposedHelpers.setObjectField(smallAppObject, WechatConfig.APP_BRAND_MODEL_FIELD_URL, url);
        XposedHelpers.setObjectField(smallAppObject, WechatConfig.APP_BRAND_MODEL_FIELD_GH, gh);
        XposedHelpers.setObjectField(smallAppObject, WechatConfig.APP_BRAND_MODEL_FIELD_APPID, appId);

        XposedHelpers.setObjectField(smallAppObject, WechatConfig.APP_BRAND_MODEL_FIELD_WXAPP_APPID, "wxapp_" + appId);
        String urlParameter = (String) XposedHelpers.callStaticMethod(XposedHelpers.findClass(WechatConfig.APP_BRAND_CLASS_QX, this.classLoader), WechatConfig.APP_BRAND_METHOD_QX, appId);

        LogUtils.log(TAG, "urlParam" + urlParameter);
        XposedHelpers.setObjectField(smallAppObject, WechatConfig.APP_BRAND_MODEL_FIELD_URLNAME, name);

        Class kernelClass = XposedHelpers.findClass(WechatConfig.APP_BRAND_KERNEL_CLASS, this.classLoader);
        Object smallAppSender = XposedHelpers.callStaticMethod(kernelClass, WechatConfig.APP_BRAND_KERNEL_METHOD_CREATE_OBJECT, XposedHelpers.findClass(WechatConfig.APP_BRAND_CLASS_COMPAT, this.classLoader));

        byte[] bytes = null;
        if (imagePath.startsWith("http")) {
            bytes = downloadBitmap(imagePath);
        } else {
            bytes = readBitmap(imagePath);
        }

        XposedHelpers.callMethod(smallAppSender, WechatConfig.APP_BRAND_METHOD_SEND,
                new Class[]{
                        smallAppObject.getClass(), String.class, String.class, String.class, byte[].class
                },
                new Object[]{
                        smallAppObject, appId, title, talker, bytes
                });

    }

    public static byte[] downloadBitmap(String url) {
        try {
            URL localURL = new URL(url);
            URLConnection conn = localURL.openConnection();
            conn.connect();
            Bitmap bitmap = BitmapFactory.decodeStream(conn.getInputStream());
            OutputStream outputStream = new ByteArrayOutputStream();
            bitmap.compress(Bitmap.CompressFormat.JPEG, 20, outputStream);
            return ((ByteArrayOutputStream) outputStream).toByteArray();
        } catch (IOException ex) {
            ex.printStackTrace();
        }
        return null;
    }

    public byte[] readBitmap(String imagePath) {
        File file = new File(imagePath);
        if (!file.exists()) {
            return null;
        }
        try {
            FileInputStream inputStream = new FileInputStream(file);
            byte[] bytes = new byte[inputStream.available()];
            inputStream.read(bytes);
            inputStream.close();
            return bytes;
        } catch (IOException ex) {
            ex.printStackTrace();
        }
        return null;
    }

}
