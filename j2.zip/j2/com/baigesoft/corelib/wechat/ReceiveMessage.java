package com.baigesoft.corelib.wechat;

import android.content.ContentValues;
import android.content.Context;
import android.content.res.XmlResourceParser;
import android.database.Cursor;
import android.text.TextUtils;
import android.util.Xml;

import com.baigesoft.corelib.Constants;
import com.baigesoft.corelib.config.WechatConfig;
import com.baigesoft.corelib.db.ContactManager;
import com.baigesoft.corelib.db.SystemManager;
import com.baigesoft.corelib.db.UserManager;
import com.baigesoft.corelib.model.WechatContact;
import com.baigesoft.corelib.model.WechatMessage;
import com.baigesoft.corelib.model.WechatMessageType;
import com.baigesoft.corelib.model.WechatUser;
import com.baigesoft.corelib.utils.LogUtils;
import com.baigesoft.corelib.utils.MessageUtils;
import com.baigesoft.corelib.utils.WechatUtils;

import org.xmlpull.v1.XmlPullParser;

import java.io.File;
import java.io.StringReader;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

/**
 * Hook微信接收消息方法
 * Created by Dawei on 17/05/2017.
 */

public class ReceiveMessage extends XC_MethodHook {

    private static final String TAG = "Plugin_ReceiveMessage";

    private Context context;

    private XC_LoadPackage.LoadPackageParam loadPackageParam;

    public ReceiveMessage(Context context, XC_LoadPackage.LoadPackageParam loadPackageParam) {
        this.context = context;
        this.loadPackageParam = loadPackageParam;
    }

    @Override
    protected void afterHookedMethod(MethodHookParam param) throws Throwable {
        Long result = (Long) param.getResult();
        if (result == null || result.longValue() == -1 || result.longValue() == -2) {
            return;
        }

        String tableName = param.args[0].toString();
        LogUtils.log(TAG, "table: " + tableName);

        ContentValues values = (ContentValues) param.args[2];
        if (values == null) {
            LogUtils.log(TAG, "value为空，表名：" + tableName);
            return;
        }

        if(Constants.DEBUG_MODE) {
            LogUtils.log(TAG, "表名：" + tableName);
            Set<Map.Entry<String, Object>> s = values.valueSet();
            Iterator itr = s.iterator();
            while (itr.hasNext()) {
                Map.Entry me = (Map.Entry) itr.next();
                String key = me.getKey().toString();
                Object value = me.getValue();

                LogUtils.log(TAG, key + "=" + (value == null ? null : value.toString()));
            }
            LogUtils.log(TAG, "-----------------");
        }

        //处理好友请求
        if ("fmessage_msginfo".equals(tableName)) {
            String msgContent = values.getAsString("msgContent");
            Integer type = values.getAsInteger("type");
            Integer isSend = values.getAsInteger("isSend");
            String talker = values.getAsString("talker");
            LogUtils.log(TAG, "好友请求:" + msgContent);
            if (type == null || type != 1) {
                LogUtils.log(TAG, "好友请求[type]：" + type);
                return;
            }
            if (isSend == null || isSend != 0) {
                LogUtils.log(TAG, "好友请求[isSend]：" + isSend);
                return;
            }

            String ticket = "";
            String scene = "";
            String fromNickName = "";
            XmlPullParser xmlPullParser = Xml.newPullParser();
            xmlPullParser.setInput(new StringReader(msgContent));
            while (xmlPullParser.getEventType() != XmlResourceParser.END_DOCUMENT) {
                int num = xmlPullParser.getAttributeCount();
                for (int i = 0; i < num; i++) {
                    String name = xmlPullParser.getAttributeName(i);
                    String value = xmlPullParser.getAttributeValue(i);
                    if ("ticket".equals(name)) {
                        ticket = value;
                    } else if ("scene".equals(name)) {
                        scene = value;
                    } else if ("fromnickname".equals(name)) {
                        fromNickName = value;
                    }
                }
                xmlPullParser.next();// 获取解析下一个事件
            }
            if (TextUtils.isEmpty(ticket) || TextUtils.isEmpty(scene)) {
                LogUtils.log(TAG, "好友请求：获取不到ticket:" + ticket + ":" + scene);
                return;
            }

            int sceneNumber = 0;
            try {
                sceneNumber = Integer.parseInt(scene);
            } catch (Exception ex) {
            }

            LogUtils.log(TAG, "talker:" + talker + ",ticket:" + ticket + ",fromnickname:" + fromNickName + ",scene:" + scene);
            FriendsInfo.through(loadPackageParam.classLoader, talker, ticket, sceneNumber, fromNickName);
            return;
        }

        //自动保存群到通讯录
        if ("rcontact".equals(tableName)) {
            String username = values.getAsString("username");
            if (TextUtils.isEmpty(username) || !username.endsWith("@chatroom")) {
                return;
            }
            ChatRoomHook.saveToContact(loadPackageParam.classLoader, username);
            LogUtils.log(TAG, "保存到通讯录成功：" + username);
            return;
        }

        //处理消息
        String talker = values.getAsString("talker");
        Integer messageType = values.getAsInteger("type");

        //处理消息
        if (talker != null && messageType != null) {
            WechatUser currentUser = new UserManager(loadPackageParam.classLoader).getCurrentUser();
            if (currentUser == null) {
                LogUtils.log(TAG, "获取当前用户失败");
                return;
            }
            switch (messageType.intValue()) {
                case WechatMessageType.TEXT:
                    if (tableName.equals("message")) {
                        SendMessage.processMessage(loadPackageParam, values, currentUser);
                    }
                    break;
                case WechatMessageType.IMAGE:
                    if (tableName.equals("message")) {
                        SendImage.processMessage(loadPackageParam, values, currentUser);
                    }
                    break;
                case WechatMessageType.VOICE:
                    SendVoice.processMessage(loadPackageParam, values, currentUser);
                    break;
                case WechatMessageType.VIDEO:
                    SendVideo.processMessage(loadPackageParam, values, currentUser);
                    break;
                case WechatMessageType.URL:
                    SendUrl.processMessage(loadPackageParam, values, currentUser);
                    break;
                case WechatMessageType.URL_VIDEO:
                    SendVideo.uploadVideo(loadPackageParam, values, currentUser);
                    break;
                case WechatMessageType.SYSTEM:
                    SendSystem.processMessage(loadPackageParam, values, currentUser);
                    break;
                case WechatMessageType.INVITE_INTO_CHATROOM:
                    ChatroomInviteMessage.processMessage(loadPackageParam, values, currentUser);
                    break;
                case WechatMessageType.EMOJI:
//                    LogUtils.log(TAG, "表情：" + values.getAsString("content"));
                    break;

            }
            return;
        }

        //会话插入
        if("rconversation".equals(tableName)){
            if(values.get("username") == null || values.get("unReadCount") == null){
                return;
            }
            String username = values.getAsString("username");
            if (WechatUtils.skipTalker(username)) {
                return;
            }
            int unReadCount = values.getAsInteger("unReadCount");
            if(unReadCount <= 0){
                return;
            }
            markAsRead(loadPackageParam.classLoader, username);
            return;
        }


        //处理事件
        if ("MediaDuplication".equals(tableName)) {
            String path = values.getAsString("path");
            if (TextUtils.isEmpty(path)) {
                return;
            }
            File file = new File(path);
            if (!file.exists()) {
                return;
            }
            int index = path.lastIndexOf("/");
            if (index == -1) {
                return;
            }
            String key = path.substring(index + 1);
            if (key.indexOf(".") > -1) {
                key = key.substring(0, key.indexOf("."));
            }

            LogUtils.log(TAG, "下载：" + path + " : " + key);

            //更新图片消息中的小图为大图
            WechatMessage wechatMessage = MessageUtils.IMAGE_CACHE.get(key);
            if (wechatMessage != null) {
                MessageUtils.IMAGE_CACHE.remove(key);
                wechatMessage.setContent(path);
                MessageUtils.uploadMessage(wechatMessage);
                return;
            }

            //上传视频消息
            wechatMessage = MessageUtils.VIDEO_CACHE.get(key);
            if (wechatMessage != null) {
                Long size = values.getAsLong("size");
                wechatMessage.setContent(path);
                if (size == null || size <= Constants.MAX_VIDEO_SIZE) {
                    MessageUtils.uploadMessage(wechatMessage);
                } else {
                    wechatMessage.setType(WechatMessageType.SYSTEM);
                    wechatMessage.setContent("视频大于3M，请您在手机中查看");
                    MessageUtils.uploadMessage(wechatMessage);
                }
                MessageUtils.VIDEO_CACHE.remove(key);
                return;
            }
        }
    }

    public static void hook(final XC_LoadPackage.LoadPackageParam packageParam, Context context) {
        Class dbClass = XposedHelpers.findClass(WechatConfig.CLASS_RECEIVE_MESSAGE, packageParam.classLoader);

        XposedHelpers.findAndHookMethod(dbClass, "a", new Object[]{String.class, String.class, ContentValues.class, Boolean.TYPE, new ReceiveMessage(context, packageParam)});

        XposedHelpers.findAndHookMethod(dbClass, "replace", new Object[]{String.class, String.class, ContentValues.class, new XC_MethodHook() {
                    protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                        String table = (String) param.args[0];
//                        LogUtils.log(TAG, "表替换：" + table);
                        final ContentValues contentValues = (ContentValues) param.args[2];
                        if (TextUtils.isEmpty(table) || contentValues == null) {
                            return;
                        }

                        if(Constants.DEBUG_MODE) {
                            LogUtils.log(TAG, "表名[替换]：" + table);
                            Set<Map.Entry<String, Object>> s = contentValues.valueSet();
                            Iterator itr = s.iterator();
                            while (itr.hasNext()) {
                                Map.Entry me = (Map.Entry) itr.next();
                                String key = me.getKey().toString();
                                Object value = me.getValue();

                                LogUtils.log(TAG, key + "=" + (value == null ? null : value.toString()));
                            }
                            LogUtils.log(TAG, "-----------------");
                        }


                        //更新群信息
                        if(Constants.HANDLE_CHAT_ROOM && "chatroom".equals(table)){
                            String talker = contentValues.getAsString("chatroomname");
                            if(TextUtils.isEmpty(talker) || !talker.endsWith("@chatroom")){
                                return;
                            }
                            MessageUtils.syncChatroom(packageParam.classLoader, 0, talker, false);
                            LogUtils.log(TAG, "更新群信息：" + talker);
                        }
                    }
                }
            }
        );

        //表更新
        XposedHelpers.findAndHookMethod(dbClass, "update", new Object[]{String.class, ContentValues.class, String.class, String[].class, new XC_MethodHook() {
            protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                String table = (String) param.args[0];
//                LogUtils.log(TAG, "表更新：" + table);
                final ContentValues contentValues = (ContentValues) param.args[1];
                if (TextUtils.isEmpty(table) || contentValues == null) {
                    return;
                }

                if(Constants.DEBUG_MODE) {
                    LogUtils.log(TAG, "表名[更新]：" + table);
                    Set<Map.Entry<String, Object>> s = contentValues.valueSet();
                    Iterator itr = s.iterator();
                    while (itr.hasNext()) {
                        Map.Entry me = (Map.Entry) itr.next();
                        String key = me.getKey().toString();
                        Object value = me.getValue();

                        LogUtils.log(TAG, key + "=" + (String) (value == null ? null : value.toString()));
                    }
                    LogUtils.log(TAG, "-----------------");
                }

                //更新好友信息
                if ("rcontact".equals(table)) {
                    final String username = contentValues.getAsString("username");
                    if (WechatUtils.skipTalker(username)) {
                        return;
                    }

                    LogUtils.log(TAG, "更新好友：" + username);

                    final WechatUser wechatUser = new UserManager(packageParam.classLoader).getUserInfo();

                    new Thread(new Runnable() {
                        @Override
                        public void run() {
                            WechatContact contact = new ContactManager(packageParam.classLoader).getContact(username);
                            if (contact != null) {
                                if (contact.getType() == null) {
                                    return;
                                }
                                if (contact.getType().intValue() != 1 && contact.getType().intValue() != 3) {
                                    return;
                                }
                                contact.setSourceWeixinId(wechatUser.weixinId);
                                contact.setSourceMobile(wechatUser.mobile);
                                contact.setSourceTalker(wechatUser.talkerId);
                                MessageUtils.updateFriend(contact, true);
                            }
                        }
                    }).start();
                }

                //会话更新
                if("rconversation".equals(table)){
                    if(contentValues.get("username") == null || contentValues.get("unReadCount") == null){
                        return;
                    }
                    String username = contentValues.getAsString("username");
                    if (WechatUtils.skipTalker(username)) {
                        return;
                    }
                    int unReadCount = contentValues.getAsInteger("unReadCount");
                    if(unReadCount <= 0){
                        return;
                    }
                    markAsRead(packageParam.classLoader, username);
                    return;
                }


                if ("ImgInfo2".equals(table)) {
                    final String bigImgPath = contentValues.getAsString("bigImgPath");
                    if (TextUtils.isEmpty(bigImgPath)) {
                        return;
                    }
                    if (bigImgPath.startsWith("SERVERID://") || bigImgPath.endsWith(".temp")) {
                        return;
                    }
                    LogUtils.log(TAG, "收到大图：" + bigImgPath);

                    new Thread(new Runnable() {
                        @Override
                        public void run() {
                            String userDir = new SystemManager(packageParam.classLoader).getUserDir();
                            String fname = bigImgPath.substring(0, bigImgPath.indexOf("."));
                            String basePath = userDir + "image2/" + fname.substring(0, 2) + "/" + fname.substring(2, 4);
                            File bigimg = new File(basePath, bigImgPath);

                            WechatMessage wechatMessage = MessageUtils.IMAGE_CACHE.get(fname);
                            if (wechatMessage != null) {
                                MessageUtils.IMAGE_CACHE.remove(fname);
                                wechatMessage.setContent(bigimg.getAbsolutePath());
                                MessageUtils.uploadMessage(wechatMessage);
                            }
                        }
                    }).start();
                }
            }
        }});

    }

    private static void markAsRead(ClassLoader classLoader, String talker){
        CommonHook.coreInit(classLoader);
        Class classModelC = XposedHelpers.findClass(WechatConfig.CHAT_ROOM_CLASS_MODEL_C, classLoader);
        Object objectFh = XposedHelpers.callStaticMethod(classModelC, WechatConfig.MSG_READ_METHOD_Fh);

        boolean z = false;

        Cursor Fn = (Cursor)XposedHelpers.callMethod(objectFh, WechatConfig.MSG_READ_METHOD_Fn, new Object[]{talker});
        Fn.moveToFirst();
        while (!Fn.isAfterLast()) {

            Class classCg = XposedHelpers.findClass(WechatConfig.MSG_READ_CLASS_AU, classLoader);
            Object auVar = XposedHelpers.newInstance(classCg);
            XposedHelpers.callMethod(auVar, WechatConfig.MSG_READ_METHOD_AU_B, new Object[]{Fn});
            int type = (int)XposedHelpers.callMethod(auVar, "getType");

            if (type != 34) {
                XposedHelpers.callMethod(auVar, WechatConfig.MSG_READ_METHOD_AU_eR, new Object[]{4});
            }
            Fn.moveToNext();
            z = true;
        }
        Fn.close();
        if(!z){
            return;
        }
        CommonHook.coreInit(classLoader);
        Object objectFk = XposedHelpers.callStaticMethod(classModelC, WechatConfig.MSG_READ_METHOD_Fk);
        XposedHelpers.callMethod(objectFk, WechatConfig.MSG_READ_METHOD_Fk_XH, new Object[]{talker});

        CommonHook.coreInit(classLoader);
        XposedHelpers.callMethod(objectFh, WechatConfig.MSG_READ_METHOD_Fl, new Object[]{talker});


    }


}
