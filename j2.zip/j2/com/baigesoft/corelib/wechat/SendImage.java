package com.baigesoft.corelib.wechat;

import android.content.ContentValues;
import android.text.TextUtils;

import com.baigesoft.corelib.Constants;
import com.baigesoft.corelib.config.WechatConfig;
import com.baigesoft.corelib.db.ContactManager;
import com.baigesoft.corelib.db.SystemManager;
import com.baigesoft.corelib.model.WechatMessage;
import com.baigesoft.corelib.model.WechatMessageType;
import com.baigesoft.corelib.model.WechatUser;
import com.baigesoft.corelib.utils.ClassUtils;
import com.baigesoft.corelib.utils.LogUtils;
import com.baigesoft.corelib.utils.MessageUtils;

import java.io.File;

import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

/**
 * Created by Dawei on 19/05/2017.
 */

public class SendImage implements Runnable {

    private static final String TAG = "Plugin_SendImage";

    private static final String[] imageTypes = new String[]{".jpg", ".bmp", ".png", ".gif"};

    private XC_LoadPackage.LoadPackageParam packageParam;

    //接收者
    private String talker;

    //图片路径
    private String path;

    public SendImage(XC_LoadPackage.LoadPackageParam packageParam, String talker, String path) {
        this.packageParam = packageParam;
        this.talker = talker;
        this.path = path;
    }

    @Override
    public void run() {
        send();
    }

    /**
     * 发送消息
     */
    public void send() {
        File file = new File(path);
        if (!file.exists()) {
            return;
        }

        //获取source
        String source = (String) XposedHelpers.callStaticMethod(ClassUtils.getClass(packageParam.classLoader, WechatConfig.CLASS_SOURCE_MODEL), WechatConfig.METHOD_SOURCE_MODEL_GET, new Object[0]);
        if (TextUtils.isEmpty(source)) {
            LogUtils.log(TAG, "找不到source");
            return;
        }

        Class modelClass = ClassUtils.getClass(packageParam.classLoader, WechatConfig.CLASS_SEND_MODEL);
        Class modelMultiClass = ClassUtils.getClass(packageParam.classLoader, WechatConfig.CLASS_SEND_IMAGE_MODEL_MULTI);
        if (modelClass == null || modelMultiClass == null) {
            return;
        }

        for (int i = 0; i < 2; i++) {
            //构造消息对象
            Object messageObject = XposedHelpers.newInstance(modelMultiClass, new Object[]{Integer.valueOf(4), source, talker, file.getAbsolutePath(), Integer.valueOf(0), null, Integer.valueOf(0), null, "", Boolean.valueOf(true), Integer.valueOf(2130970303)});
            if (messageObject == null) {
                LogUtils.log(TAG, "构造图片消息对象失败！");
                return;
            }

            //获取消息发送者
            Object messageSender = XposedHelpers.callStaticMethod(modelClass, WechatConfig.METHOD_SEND_MODEL_GET_MESSAGE_SENDER, new Object[0]);
            if (messageSender == null) {
                LogUtils.log(TAG, "获取图片消息发送者失败！");
                return;
            }

            Boolean sendResult = (Boolean) XposedHelpers.callMethod(messageSender, WechatConfig.METHOD_SENDER_SEND, messageObject);
            if (sendResult != null) {
                LogUtils.log(TAG, "发送图片成功");
                return;
            }
            LogUtils.log(TAG, "发送图片消息失败");
        }
    }

    /**
     * 处理图片消息
     *
     * @param packageParam
     * @param contentValues
     * @param currentUser
     */
    public static void processMessage(final XC_LoadPackage.LoadPackageParam packageParam, ContentValues contentValues, WechatUser currentUser) {
        if (!Constants.HANDLE_IMAGE_MSG) {
            return;
        }
        String talker = contentValues.getAsString("talker");
        if (TextUtils.isEmpty(talker)) {
            LogUtils.log(TAG, "talkerid 为空");
            return;
        }
        //跳过群消息
        if (!Constants.HANDLE_CHAT_ROOM && talker.endsWith("@chatroom")) {
            return;
        }

        String userDir = new SystemManager(packageParam.classLoader).getUserDir();
        if (TextUtils.isEmpty(userDir)) {
            LogUtils.log(TAG, "获取用户目录失败");
            return;
        }

        //是否发送：0为接收的消息；1为发送的消息
        Integer isSend = contentValues.getAsInteger("isSend");
        if (isSend == null || isSend.intValue() == 1) {
            return;
        }

        ContactManager contactManager = new ContactManager(packageParam.classLoader);
        String nickName = contactManager.getNickName(talker);
        String friendImg = contactManager.getImg(talker);

        WechatMessage wechatMessage = new WechatMessage(WechatMessageType.IMAGE);
        wechatMessage.setSourceWeixinId(currentUser.weixinId);
        wechatMessage.setSourceMobile(currentUser.mobile);
        wechatMessage.setSourceTalker(currentUser.talkerId);
        wechatMessage.setTalker(talker);
        wechatMessage.setNick(nickName);
        wechatMessage.setFriendImg(friendImg);
        wechatMessage.setCreateTime(contentValues.getAsLong("createTime"));
        wechatMessage.setStatus(contentValues.getAsInteger("status"));
        wechatMessage.setSend((isSend.intValue() == 1) ? true : false);
        wechatMessage.setMsgId(contentValues.getAsLong("msgId"));
        wechatMessage.setMsgSvrId(contentValues.getAsLong("msgSvrId"));

        //内容
        String content = contentValues.getAsString("content");
        //群聊
        if (wechatMessage.getTalker().endsWith("@chatroom")) {
            if (!TextUtils.isEmpty(content) && content.indexOf(":") > -1) {
                wechatMessage.setFriend_talker(content.substring(0, content.indexOf(":")));
                if(!TextUtils.isEmpty(wechatMessage.getFriend_talker())) {
                    wechatMessage.setFriend_chatroom_img(contactManager.getImg(wechatMessage.getFriend_talker()));
                }
            }
        }

        String fname = contentValues.getAsString("imgPath").substring(23);
        String basePath = userDir + "image2/" + fname.substring(0, 2) + "/" + fname.substring(2, 4);
        String filePath = basePath + "/th_" + fname;

        //上传图片
        File bigImageFile = null;
        for (String imageType : imageTypes) {
            File bigimg = new File(basePath, fname + imageType);
            if (bigimg.exists()) {
                bigImageFile = bigimg;
                break;
            }
        }
        if (bigImageFile != null && bigImageFile.exists()) {
            //上传大图
//            LogUtils.log(TAG, "存在大图，直接上传");
            wechatMessage.setContent(bigImageFile.getAbsolutePath());
            MessageUtils.uploadMessage(wechatMessage);
            return;
        }

        LogUtils.log(TAG, "开始下载大图");
        //缓存大图信息
        MessageUtils.IMAGE_CACHE.put(fname, wechatMessage);
//        downloadHDImage(packageParam.classLoader, wechatMessage, basePath, fname);
        downloadHDImage(packageParam.classLoader, wechatMessage.getMsgId(), wechatMessage.getMsgSvrId());

        //上传小图
        wechatMessage.setContent(filePath);

    }

//    /**
//     * 下载大图
//     *
//     * @param classLoader
//     * @param wechatMessage
//     */
//    private static void downloadHDImage(final ClassLoader classLoader, final WechatMessage wechatMessage, final String basePath, final String fname) {
//        new Thread(new Runnable() {
//            @Override
//            public void run() {
//                Class ImgService = XposedHelpers.findClass(WechatConfig.CLASS_IMG_SERVICE, classLoader);
//                Object hdStateObject = XposedHelpers.callMethod(XposedHelpers.callStaticMethod(ImgService, WechatConfig.METHOD_GET_STORE_OBJECT),
//                        WechatConfig.METHOD_GET_HD_DOWNLOAD_STATE, wechatMessage.getMsgSvrId());
//                if (hdStateObject == null) {
//                    LogUtils.log(TAG, "获取HdStateObject失败");
//                    return;
//                }
//
//                Integer isHdDownload = XposedHelpers.getIntField(hdStateObject, WechatConfig.FIELD_HD_STATE);
//                if (isHdDownload != null && isHdDownload.intValue() == 1) {
//                    LogUtils.log(TAG, "[" + wechatMessage.getMsgSvrId() + "]大图已经下载");
//                    return;
//                }
//
//                //下载大图
//                Long imageId = XposedHelpers.getLongField(hdStateObject, WechatConfig.FIELD_IMAGE_ID);
//
//                Object hdImageLogic = XposedHelpers.callStaticMethod(ImgService, WechatConfig.METHOD_GET_HD_IMAGE_LOGIC);
//                Object hdImageService = XposedHelpers.callStaticMethod(ImgService, WechatConfig.METHOD_GET_DOWNLOAD_IMAGE_SERVICE);
//
//                XposedHelpers.callMethod(hdImageService, WechatConfig.METHOD_DOWNLOAD_HD_TASK, imageId, wechatMessage.getMsgId(), Integer.valueOf(0), wechatMessage.getMsgId(), Integer.valueOf(0), hdImageLogic);
//
//                for (int i = 0; i < 30; i++) {
//                    try {
//                        for (String imageType : imageTypes) {
//                            File bigimg = new File(basePath, fname + imageType);
//                            if (bigimg.exists()) {
//                                LogUtils.log(TAG, "下载大图完成：" + bigimg.getAbsolutePath());
//                                if(MessageUtils.IMAGE_CACHE.contains(fname)) {
//                                    MessageUtils.IMAGE_CACHE.remove(fname);
//                                    wechatMessage.setContent(bigimg.getAbsolutePath());
//                                    MessageUtils.uploadMessage(wechatMessage);
//                                }
//                                return;
//                            }
//                        }
//                        Thread.sleep(1000);
//                        LogUtils.log(TAG, "等待下载完成：" + i);
//                    } catch (InterruptedException e) {
//                        e.printStackTrace();
//                    }
//                }
//
//                LogUtils.log(TAG, "大图下载失败完成");
//
//            }
//        }).start();
//    }

    /**
     * 下载大图
     *
     * @param classLoader
     * @param msgId
     * @param msgSvrId
     */
    private static void downloadHDImage(final ClassLoader classLoader, final long msgId, final long msgSvrId) {
        Class ImgService = XposedHelpers.findClass(WechatConfig.CLASS_IMG_SERVICE, classLoader);
        Object hdStateObject = XposedHelpers.callMethod(XposedHelpers.callStaticMethod(ImgService, WechatConfig.METHOD_GET_STORE_OBJECT),
                WechatConfig.METHOD_GET_HD_DOWNLOAD_STATE, msgSvrId);
        if (hdStateObject == null) {
            LogUtils.log(TAG, "获取HdStateObject失败");
            return;
        }

        Integer isHdDownload = XposedHelpers.getIntField(hdStateObject, WechatConfig.FIELD_HD_STATE);
        if (isHdDownload != null && isHdDownload.intValue() == 1) {
            LogUtils.log(TAG, "[" + msgSvrId + "]大图已经下载");
            return;
        }

        //下载大图
        Long imageId = XposedHelpers.getLongField(hdStateObject, WechatConfig.FIELD_IMAGE_ID);

        Object hdImageLogic = XposedHelpers.callStaticMethod(ImgService, WechatConfig.METHOD_GET_HD_IMAGE_LOGIC);
        Object hdImageService = XposedHelpers.callStaticMethod(ImgService, WechatConfig.METHOD_GET_DOWNLOAD_IMAGE_SERVICE);

        XposedHelpers.callMethod(hdImageService, WechatConfig.METHOD_DOWNLOAD_HD_TASK, imageId, msgId, Integer.valueOf(0), msgId, Integer.valueOf(0), hdImageLogic);

        LogUtils.log(TAG, "下载大图完成");
    }

}
