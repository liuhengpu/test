package com.baigesoft.corelib.wechat;

import android.content.ContentValues;
import android.text.TextUtils;

import com.baigesoft.corelib.Constants;
import com.baigesoft.corelib.NewFriendReply;
import com.baigesoft.corelib.config.WechatConfig;
import com.baigesoft.corelib.db.ContactManager;
import com.baigesoft.corelib.model.WechatContact;
import com.baigesoft.corelib.model.WechatMessage;
import com.baigesoft.corelib.model.WechatMessageType;
import com.baigesoft.corelib.model.WechatUser;
import com.baigesoft.corelib.robot.AutoReply;
import com.baigesoft.corelib.robot.AutoReplyResult;
import com.baigesoft.corelib.utils.LogUtils;
import com.baigesoft.corelib.utils.MessageUtils;
import com.baigesoft.corelib.utils.ThreadUtils;

import java.io.File;
import java.util.Random;
import java.util.concurrent.TimeUnit;

import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

/**
 * Created by Dawei on 18/05/2017.
 */

public class SendMessage implements Runnable {

    private static final String TAG = "Plugin_SendMessage";

    private XC_LoadPackage.LoadPackageParam packageParam;

    //接收者
    private String talker;

    //内容
    private String content;

    public SendMessage(XC_LoadPackage.LoadPackageParam packageParam, String talker, String content) {
        this.packageParam = packageParam;
        this.talker = talker;
        this.content = content;
    }

    @Override
    public void run() {
        send();
    }

    /**
     * 发送消息
     */
    public void send() {
        Class modelClass = XposedHelpers.findClass(WechatConfig.CLASS_SEND_MODEL, packageParam.classLoader);
        Class modelMultiClass = XposedHelpers.findClass(WechatConfig.CLASS_SEND_MESSAGE_MODEL_MULTI, packageParam.classLoader);
        if (modelClass == null || modelMultiClass == null) {
            return;
        }

        for (int i = 0; i < 2; i++) {
            //构造消息对象
            Object messageObject = null;
            try{
                messageObject = XposedHelpers.newInstance(modelMultiClass, talker, content, 1);
            }catch(Exception ex){
                ex.printStackTrace();
                LogUtils.log(TAG, "构造对象出错了：" + ex.getMessage());
            }
            if (messageObject == null) {
                LogUtils.log(TAG, "构造消息对象失败！");
                return;
            }

            //获取消息发送者
            Object messageSender = XposedHelpers.callStaticMethod(modelClass, WechatConfig.METHOD_SEND_MODEL_GET_MESSAGE_SENDER, new Object[0]);
            if (messageSender == null) {
                LogUtils.log(TAG, "获取消息发送者失败！");
                return;
            }

            Boolean sendResult = (Boolean) XposedHelpers.callMethod(messageSender, WechatConfig.METHOD_SENDER_SEND, messageObject);
            if (sendResult != null) {
                LogUtils.log(TAG, "发送消息成功");
                return;
            }
            LogUtils.log(TAG, "发送消息失败");
        }
    }

    /**
     * 处理文本消息
     *
     * @param packageParam
     * @param contentValues
     * @param currentUser
     */
    public static void processMessage(final XC_LoadPackage.LoadPackageParam packageParam, ContentValues contentValues, WechatUser currentUser) {
        String talker = contentValues.getAsString("talker");
        if (TextUtils.isEmpty(talker)) {
            LogUtils.log(TAG, "talkerid 为空");
            return;
        }

        //是否处理群消息
        if (!Constants.HANDLE_CHAT_ROOM && talker.endsWith("@chatroom")) {
            return;
        }

        //是否发送：0为接收的消息；1为发送的消息
        Integer isSend = contentValues.getAsInteger("isSend");

        //发送的消息不上传
        if (isSend == null || isSend == 1) {
            return;
        }

        ContactManager contactManager = new ContactManager(packageParam.classLoader);
        String nickName = contactManager.getNickName(talker);
        String friendImg = contactManager.getImg(talker);

        WechatMessage wechatMessage = new WechatMessage(WechatMessageType.TEXT);
        wechatMessage.setSourceWeixinId(currentUser.weixinId);
        wechatMessage.setSourceMobile(currentUser.mobile);
        wechatMessage.setSourceTalker(currentUser.talkerId);
        wechatMessage.setTalker(talker);
        wechatMessage.setNick(nickName);
        wechatMessage.setFriendImg(friendImg);
        wechatMessage.setCreateTime(contentValues.getAsLong("createTime"));
        wechatMessage.setStatus(contentValues.getAsInteger("status"));
        wechatMessage.setSend((isSend == null || isSend == 1) ? true : false);
        wechatMessage.setMsgId(contentValues.getAsLong("msgId"));
        wechatMessage.setMsgSvrId(contentValues.getAsLong("msgSvrId"));

        //内容
        String content = contentValues.getAsString("content");

        //群聊，直接上传消息
        if (wechatMessage.getTalker().endsWith("@chatroom")) {
            if (!TextUtils.isEmpty(content) && content.indexOf(":") > -1) {
                wechatMessage.setFriend_talker(content.substring(0, content.indexOf(":")));
                if (!TextUtils.isEmpty(wechatMessage.getFriend_talker())) {
                    wechatMessage.setFriend_chatroom_img(contactManager.getImg(wechatMessage.getFriend_talker()));
                }
                content = content.substring(content.indexOf(":") + 1);
            }
            wechatMessage.setContent(content);
            MessageUtils.addMessage(wechatMessage);
            return;
        }

        //上传消息
        if (!TextUtils.isEmpty(content)) {
            wechatMessage.setContent(content);
            MessageUtils.addMessage(wechatMessage);
        }

        //新的好友：好友申请通过验证
        if (!TextUtils.isEmpty(content) && content.contains("我通过了你的") && content.contains("验证请求")) {
            //添加联系人
            WechatContact contact = contactManager.getContact(wechatMessage.getTalker());
            if (contact != null) {
                contact.setSourceTalker(currentUser.talkerId);
                contact.setSourceWeixinId(currentUser.weixinId);
                contact.setSourceMobile(currentUser.mobile);
                MessageUtils.addFriend(contact);
            }
            //自动消息
            new NewFriendReply(packageParam, currentUser).reply(talker, 2, wechatMessage.getNick(), friendImg);
            return;
        }

        if (TextUtils.isEmpty(content)) {
            return;
        }

        //是否是自动聊天对象
        AutoReplyResult replyResult = AutoReply.randomTalk(content, talker);

        //是否启用自动回复
        if (replyResult == null) {
            replyResult = AutoReply.reply(content, talker);
        }

        //不自动回复，直接上传消息
        if (replyResult == null) {
            return;
        }

        //自动回复消息，不进行上传
        int seconds = new Random().nextInt(15 - 8 + 1) + 8;
        if (replyResult.getMessage_type() == WechatMessageType.TEXT) {
            ThreadUtils.runOnWorkerThreadDelayed(seconds, TimeUnit.SECONDS, new SendMessage(packageParam, talker, replyResult.getReply()));
        } else if (replyResult.getMessage_type() == WechatMessageType.IMAGE) {
            if (new File(replyResult.getReply()).exists()) {
                ThreadUtils.runOnWorkerThreadDelayed(seconds, TimeUnit.SECONDS, new SendImage(packageParam, talker, replyResult.getReply()));
            }
        }

        //保存
        WechatMessage replyMessage = new WechatMessage(WechatMessageType.TEXT);
        replyMessage.setSourceWeixinId(currentUser.weixinId);
        replyMessage.setSourceMobile(currentUser.mobile);
        replyMessage.setSourceTalker(currentUser.talkerId);
        replyMessage.setTalker(talker);
        replyMessage.setNick(nickName);
        replyMessage.setFriendImg(friendImg);
        replyMessage.setCreateTime(System.currentTimeMillis());
        replyMessage.setStatus(0);
        replyMessage.setSend(true);
        replyMessage.setMsgId(0L);
        replyMessage.setMsgSvrId(0L);
        replyMessage.setType(replyResult.getMessage_type());
        if (replyResult.getMessage_type() == WechatMessageType.TEXT) {
            replyMessage.setContent(replyResult.getReply());
        } else if (replyResult.getMessage_type() == WechatMessageType.IMAGE) {
            replyMessage.setContent(replyResult.getUrl());
        }
        if (!TextUtils.isEmpty(replyMessage.getContent())) {
            MessageUtils.addMessage(replyMessage);
        }
        return;
    }

}
