package com.baigesoft.corelib.wechat;

import android.database.Cursor;
import android.text.TextUtils;

import com.baigesoft.corelib.config.WechatConfig;
import com.baigesoft.corelib.utils.LogUtils;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import de.robv.android.xposed.XposedHelpers;

/**
 * Created by Dawei on 20/12/2017.
 */

public class FriendLabel {

    private static final String TAG = "Plugin_FriendLabel";

    /**
     * 建立标签
     *
     * @param classLoader
     * @param labelList
     */
    public static void createLabel(ClassLoader classLoader, List<String> labelList) {
        Object labelVar = XposedHelpers.newInstance(XposedHelpers.findClass(WechatConfig.CLASS_LABEL_VAR, classLoader), new Object[]{labelList});

        Class clsGetLabelObject = XposedHelpers.findClass(WechatConfig.CLASS_SEND_MODEL, classLoader);
        Object labelObject = XposedHelpers.callStaticMethod(clsGetLabelObject, WechatConfig.METHOD_SEND_MODEL_GET_MESSAGE_SENDER);
        boolean result = (boolean) XposedHelpers.callMethod(labelObject, "a", new Object[]{labelVar, 0});
        LogUtils.log(TAG, "建标签结果：" + result);
    }

    /**
     * 给好友打标签
     *
     * @param classLoader
     * @param talker
     * @param labelList
     */
    public static void labelFriend(ClassLoader classLoader, String talker, List<String> labelList) {
        if(labelList == null || labelList.size() == 0){
            LogUtils.log(TAG, "标签参数为空");
            return;
        }
        if(TextUtils.isEmpty(talker)){
            LogUtils.log(TAG, "talker参数为空");
            return;
        }
        List<String> newLabelList = queryLabel(classLoader, labelList);
        if(newLabelList != null && newLabelList.size() > 0){
            LogUtils.log(TAG, "创建新标签：" + TextUtils.join(",", newLabelList));
            createLabel(classLoader, newLabelList);

            //等待标签创建完成
            for(int i = 0; i < 15; i++){
                try {
                    Thread.sleep(1000);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                if(queryLabel(classLoader, labelList).size() == 0){
                    break;
                }
            }
        }

        Class clsGetLabelId = XposedHelpers.findClass(WechatConfig.CLASS_GET_LABELID_OBJECT, classLoader);
        Object getLabelIdObj = XposedHelpers.callStaticMethod(clsGetLabelId, WechatConfig.METHOD_GET_LABELID_OBJECT);
        ArrayList labelIdList = (ArrayList) XposedHelpers.callMethod(getLabelIdObj, WechatConfig.METHOD_GET_LABELID, new Object[]{labelList});
        if (labelIdList == null || labelIdList.size() == 0) {
            LogUtils.log(TAG, "获取标签id列表为空");
            return;
        }

        Class clsJoinLabelId = XposedHelpers.findClass(WechatConfig.CLASS_JOIN_LABELID, classLoader);
        String labelIdStr = (String) XposedHelpers.callStaticMethod(clsJoinLabelId, WechatConfig.METHOD_JOIN_LABELID, new Object[]{labelIdList});

        Class clsLabelObject = XposedHelpers.findClass(WechatConfig.CLASS_LABEL_OBJECT, classLoader);
        Object labelObject = XposedHelpers.newInstance(clsLabelObject);
        XposedHelpers.setObjectField(labelObject, WechatConfig.FIELD_LABEL_OBJECT_LABEL, labelIdStr);
        XposedHelpers.setObjectField(labelObject, WechatConfig.FIELD_LABEL_OBJECT_USERNAME, talker);
        LinkedList linkedList = new LinkedList();
        linkedList.add(labelObject);

        Class clsModifyLabel = XposedHelpers.findClass(WechatConfig.CLASS_MODITY_LABEL, classLoader);
        Object modifyLabelObject = XposedHelpers.newInstance(clsModifyLabel, new Object[]{linkedList});


        Class clsGetLabelObject = XposedHelpers.findClass(WechatConfig.CLASS_SEND_MODEL, classLoader);
        Object getLabelObject = XposedHelpers.callStaticMethod(clsGetLabelObject, WechatConfig.METHOD_SEND_MODEL_GET_MESSAGE_SENDER);

        boolean result = (boolean) XposedHelpers.callMethod(getLabelObject, "a", new Object[]{modifyLabelObject, 0});
        LogUtils.log(TAG, "打标签结果：" + result);
    }

    /**
     * 查询数据库中是否存在标签
     *
     * @param classLoader
     * @param labelList
     * @return 不在数据库中的标签列表
     */
    private static List<String> queryLabel(ClassLoader classLoader, List<String> labelList) {
        List<String> strList = new ArrayList<>();
        if (labelList == null || labelList.size() == 0) {
            return strList;
        }
        WechatDb wechatDb = new WechatDb(classLoader);
        if (wechatDb == null) {
            LogUtils.log(TAG, "获取WechatDB失败");
            return strList;
        }

        Map<String, Integer> map = new HashMap<>();
        String sql = "SELECT * FROM ContactLabel WHERE labelName IN (";
        for (String label : labelList) {
            sql += "'" + label + "',";
            map.put(label, 1);
        }
        sql += "'afdsafdrewfsfdsa')";

        Cursor cursor = null;
        try {
            cursor = wechatDb.rawQuery(sql);
            while (cursor.moveToNext()) {
                String label = cursor.getString(cursor.getColumnIndex("labelName"));
                if (map.containsKey(label)) {
                    map.remove(label);
                }
            }
        } catch (Exception ex) {

        } finally {
            if (cursor != null) {
                try {
                    cursor.close();
                } catch (Exception ex) {
                }
            }
        }

        for (String label : map.keySet()) {
            strList.add(label);
        }
        return strList;
    }

}
