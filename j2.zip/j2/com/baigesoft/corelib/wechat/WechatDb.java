package com.baigesoft.corelib.wechat;

import android.content.ContentValues;
import android.database.Cursor;

import com.baigesoft.corelib.config.WechatConfig;
import com.baigesoft.corelib.utils.ClassUtils;

import de.robv.android.xposed.XposedHelpers;

/**
 * Created by Dawei on 08/01/2018.
 */

public class WechatDb {

    private static final String TAG = "Plugin_WechatDb";

    private Object dbObj;

    private ClassLoader classLoader;

    private Object getQueryObject() {
        Class modelClass = ClassUtils.getClass(classLoader, WechatConfig.CLASS_SEND_MODEL);
        Object tool = XposedHelpers.callStaticMethod(modelClass, WechatConfig.METHOD_GET_TOOL, new Object[0]);
        if (tool == null) {
            return null;
        }
        Object tool2 = XposedHelpers.callMethod(tool, WechatConfig.METHOD_GET_TOOL2, new Object[0]);
        if (tool2 == null) {
            return null;
        }
        Object e = XposedHelpers.getObjectField(tool2, WechatConfig.FIELD_GET_QUERY_OBJECT);
        return e;
    }

    public WechatDb(ClassLoader classLoader) {
        this.classLoader = classLoader;
        this.dbObj = getQueryObject();
    }

    public Cursor rawQuery(String sql) {
        return rawQuery(sql, null);
    }

    public Cursor rawQuery(String sql, String[] strArr) {
        if (dbObj == null) {
            return null;
        }
        return (Cursor) XposedHelpers.callMethod(dbObj, WechatConfig.DB_RAW_QUERY, new Object[]{sql, strArr});
    }

    public Long insert(String tableName, String unkonw, ContentValues contentValue) {
        if (dbObj == null) {
            return null;
        }
        return (Long) XposedHelpers.callMethod(dbObj, WechatConfig.DB_RAW_INSERT, new Object[]{tableName, unkonw, contentValue});
    }

    public Integer delete(String tableName, String unkonw, String[] args) {
        if (dbObj == null) {
            return null;
        }
        return (Integer) XposedHelpers.callMethod(dbObj, WechatConfig.DB_RAW_DELETE, new Object[]{tableName, unkonw, args});
    }

    public Boolean execSQL(String tableName, String sql) {
        if (dbObj == null) {
            return null;
        }
        return (Boolean) XposedHelpers.callMethod(dbObj, WechatConfig.DB_RAW_EXECUTE, new Object[]{tableName, sql});
    }

}
