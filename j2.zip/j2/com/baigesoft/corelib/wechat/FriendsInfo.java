package com.baigesoft.corelib.wechat;

import android.util.Log;

import com.baigesoft.corelib.Constants;
import com.baigesoft.corelib.VersionCode;
import com.baigesoft.corelib.WechatHook;
import com.baigesoft.corelib.config.WechatConfig;
import com.baigesoft.corelib.utils.LogUtils;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

/**
 * Created by Dawei on 23/06/2017.
 */

public class FriendsInfo {

    private static final String TAG = "Plugin_FriendsInfo";

    private XC_LoadPackage.LoadPackageParam packageParam;

    public FriendsInfo(XC_LoadPackage.LoadPackageParam packageParam) {
        this.packageParam = packageParam;
    }

    public void hook() {
        getInfo();
    }

    private void getInfo() {
        nearby();
    }

    /**
     * 附近的人
     */
    private void nearby() {
        XposedHelpers.findAndHookMethod(XposedHelpers.findClass(WechatConfig.CLASS_NEARBY_BY, packageParam.classLoader), WechatConfig.METHOD_NEARBY_BY, new XC_MethodHook() {
            protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                LogUtils.log(TAG, "进行nearby方法hook");
                List list = (List) param.getResult();
                if (list != null && !list.isEmpty()) {
                    LogUtils.log(TAG, "nearby内找到好友");
                    int i;
                    List<HashMap> talkerlist = new ArrayList();
                    for (i = 0; i < list.size(); i++) {
                        Log.d("Api", "class name2:" + list.get(i).getClass().getName());
                        Object talkerId = XposedHelpers.getObjectField(list.get(i), WechatConfig.FIELD_NEARBY_TALKER_ID);
                        Object nickName = XposedHelpers.getObjectField(list.get(i), WechatConfig.FIELD_NEARBY_NICKNAME);
                        Object lat = XposedHelpers.getObjectField(list.get(i), WechatConfig.FIELD_NEARBY_LAT);
                        Object lng = XposedHelpers.getObjectField(list.get(i), WechatConfig.FIELD_NEARBY_LNG);
                        Object signature = XposedHelpers.getObjectField(list.get(i), WechatConfig.FIELD_NEARBY_SIGNATURE);
                        Object sex = XposedHelpers.getObjectField(list.get(i), WechatConfig.FIELD_NEARBY_SEX);
                        Object headImage = XposedHelpers.getObjectField(list.get(i), WechatConfig.FIELD_NEARBY_HEAD_IMAGE);
                        HashMap map = new HashMap();
                        map.put("username", talkerId);
                        map.put("nickname", nickName);
                        talkerlist.add(map);


//                        LogUtils.log(TAG, "list " + i + "TalkerId:" + talkerId);
//                        LogUtils.log(TAG, "list " + i + " NickName:" + nickName);
//                        LogUtils.log(TAG, "list " + i + " Locality:" + lat + " " + lng);
//                        LogUtils.log(TAG, "list " + i + " Signature:" + signature);
//                        LogUtils.log(TAG, "list " + i + " Sex:" + sex);
//                        LogUtils.log(TAG, "list " + i + " HeadImage:" + headImage);
//                        LogUtils.log(TAG, "Source:附近的人");
                    }
                } else {
                    LogUtils.log(TAG, "nearby好友为空");
                }
            }
        });
    }

    /**
     * 自动通过好友
     *
     * @param classLoader
     * @param talker
     * @param ticket
     * @param scene
     * @param fromNickName
     */
    public static void through(final ClassLoader classLoader, final String talker, final String ticket, final Integer scene, final String fromNickName) {
        if (!Constants.AUTO_THROUGH_FRIEND) {
            return;
        }
        new Thread(new Runnable() {
            public void run() {
                Class clsThroughObject = XposedHelpers.findClass(WechatConfig.CLASS_THROUGH_OBJECT, classLoader);
                Object throughObject = null;
                if (WechatHook.version.equals(VersionCode.V663) || WechatHook.version.equals(VersionCode.V665) || WechatHook.version.equals(VersionCode.V666)) {
                    throughObject = XposedHelpers.newInstance(clsThroughObject, new Object[]{talker, ticket, scene});
                } else {
                    byte b = 0;
                    throughObject = XposedHelpers.newInstance(clsThroughObject, new Object[]{talker, ticket, scene, b});
                }

                Class ah = XposedHelpers.findClass(WechatConfig.CLASS_SEND_MODEL, classLoader);

                XposedHelpers.callMethod(XposedHelpers.callStaticMethod(ah, WechatConfig.METHOD_SEND_MODEL_GET_MESSAGE_SENDER), "a", new Object[]{throughObject, 0});
                LogUtils.log(TAG, "已确认添加好友：" + fromNickName);
            }
        }).start();
    }

    /**
     * 删除好友
     *
     * @param classLoader
     * @param talker
     */
    public static void delete(final ClassLoader classLoader, final String talker) {
        LogUtils.log(TAG, "删除好友：" + talker);
        Class clsDeleteModel = XposedHelpers.findClass(WechatConfig.DELETE_FRIEND_MODEL_CLASS, classLoader);
        Object deleteModel = XposedHelpers.newInstance(clsDeleteModel, talker);

        Class clsModel = XposedHelpers.findClass(WechatConfig.CHAT_ROOM_CLASS_MODEL_C, classLoader);

        Object fqObject = XposedHelpers.callStaticMethod(clsModel, WechatConfig.CHAT_ROOM_GET_FE_METHOD);
        XposedHelpers.callMethod(fqObject, WechatConfig.DELETE_FRIEND_METHOD, deleteModel);

        Object fwObject = XposedHelpers.callStaticMethod(clsModel, WechatConfig.MSG_READ_METHOD_Fk);
        XposedHelpers.callMethod(fwObject, WechatConfig.DELETE_FRIEND_CHAT_METHOD, talker);
        LogUtils.log(TAG, "delete friend: " + XposedHelpers.callStaticMethod(clsModel, WechatConfig.DELETE_FRIEND_GA, new Object[0]));

        XposedHelpers.callMethod(XposedHelpers.callStaticMethod(clsModel, WechatConfig.CHAT_ROOM_METHOD_GET_FF, new Object[0]), WechatConfig.DELETE_FRIEND_YM_METHOD, new Object[]{talker});
        XposedHelpers.callMethod(XposedHelpers.callStaticMethod(clsModel, WechatConfig.DELETE_FRIEND_GA, new Object[0]), WechatConfig.DELETE_FRIEND_IN_METHOD, new Object[]{talker});
        LogUtils.log(TAG, "删除好友成功：" + talker);
    }
}
