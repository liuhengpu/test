package com.baigesoft.corelib.wechat;

import com.baigesoft.corelib.VersionCode;
import com.baigesoft.corelib.WechatHook;
import com.baigesoft.corelib.config.WechatConfig;
import com.baigesoft.corelib.db.ChatRoomManager;
import com.baigesoft.corelib.model.ChatRoom;
import com.baigesoft.corelib.utils.LogUtils;

import java.util.ArrayList;
import java.util.List;

import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;

public class ChatRoomHook {

    public static final String TAG = "Plugin_ChatRoom";

    /**
     * 新建群
     *
     * @param loader
     * @param roomName   群名称
     * @param talkerList 群成员talker列表
     * @return
     */
    public static void create(ClassLoader loader, String roomName, List<String> talkerList) {
        LogUtils.log(TAG, "执行新建群命令");

        Class classCreateChatroom = XposedHelpers.findClass(WechatConfig.CHAT_ROOM_CLASS_CREATE_CHAT_ROOM, loader);
        Object createRoomVar = XposedHelpers.newInstance(classCreateChatroom, new Object[]{roomName, talkerList});

        Class classSender = XposedHelpers.findClass(WechatConfig.CLASS_SEND_MODEL, loader);
        Object senderObject = XposedHelpers.callStaticMethod(classSender, WechatConfig.METHOD_SEND_MODEL_GET_MESSAGE_SENDER);

        XposedHelpers.callMethod(senderObject, "a", new Object[]{createRoomVar, Integer.valueOf(0)});
        LogUtils.log(TAG, "新建群任务执行结束");
    }

    /**
     * 保存群到通讯录
     *
     * @param loader
     * @param talker
     */
    public static void saveToContact(ClassLoader loader, String talker) {
        LogUtils.log(TAG, "执行保存群到通讯录命令");
        Class clxXv = XposedHelpers.findClass(WechatConfig.CHAT_ROOM_CLASS_MODEL_C, loader);
        Object ff = XposedHelpers.callStaticMethod(clxXv, WechatConfig.CHAT_ROOM_METHOD_GET_FF);
        Object xv = XposedHelpers.callMethod(ff, WechatConfig.CHAT_ROOM_METHOD_GET_XV, new Object[]{talker});

        Class clsS = XposedHelpers.findClass(WechatConfig.CHAT_ROOM_CLASS_Y_S, loader);
        XposedHelpers.callStaticMethod(clsS, WechatConfig.CHAT_ROOM_METHOD_SAVE, new Object[]{xv});
        LogUtils.log(TAG, "保存群到通讯录执行结束");
    }

    /**
     * 踢人
     *
     * @param loader
     * @param chatroomTalker
     * @param memberTalker
     */
    public static void deleteMember(ClassLoader loader, String chatroomTalker, String memberTalker) {
        LogUtils.log(TAG, "执行踢人命令");

        List<String> talkerList = new ArrayList<>();
        talkerList.add(memberTalker);

        Class classCreateChatroom = XposedHelpers.findClass(WechatConfig.CHAT_ROOM_CLASS_DELETE_MEMBER, loader);
        Object createRoomVar = null;
        if (WechatHook.version.equals(VersionCode.V6523)
                || WechatHook.version.equals(VersionCode.V663)
                || WechatHook.version.equals(VersionCode.V665)
                || WechatHook.version.equals(VersionCode.V666)
                || WechatHook.version.equals(VersionCode.V667)) {
            createRoomVar = XposedHelpers.newInstance(classCreateChatroom, new Object[]{chatroomTalker, talkerList});
        } else {
            createRoomVar = XposedHelpers.newInstance(classCreateChatroom, new Object[]{chatroomTalker, talkerList, 0});
        }

        Class classSender = XposedHelpers.findClass(WechatConfig.CLASS_SEND_MODEL, loader);
        Object senderObject = XposedHelpers.callStaticMethod(classSender, WechatConfig.METHOD_SEND_MODEL_GET_MESSAGE_SENDER);

        XposedHelpers.callMethod(senderObject, "a", new Object[]{createRoomVar, Integer.valueOf(0)});
        LogUtils.log(TAG, "踢人任务执行结束");
    }

    /**
     * 拉人进群
     *
     * @param loader
     * @param chatroomTalker
     * @param talkerList
     */
    public static void pullFriend(ClassLoader loader, String chatroomTalker, List<String> talkerList) {
        LogUtils.log(TAG, "执行拉人进群命令");

        ChatRoom chatRoom = new ChatRoomManager(loader).getChatRoom(chatroomTalker);
        if (chatRoom == null) {
            LogUtils.log(TAG, "群不存在：" + chatroomTalker);
            return;
        }

        Class classAddMember = XposedHelpers.findClass(WechatConfig.CHATROOM_CLASS_PULLFRIEND_ADD_MEMBER, loader);
        Class classInviteMember = XposedHelpers.findClass(WechatConfig.CHAT_ROOM_CLASS_PULLFRIEND_INVITE_MEMBER, loader);
        Object addMemberObject = null;
        if (chatRoom.getMemberCount() < 40) {
            addMemberObject = XposedHelpers.newInstance(classAddMember, new Object[]{chatroomTalker, talkerList, null});
        } else {
            addMemberObject = XposedHelpers.newInstance(classInviteMember, new Object[]{chatroomTalker, talkerList});
        }

        Class classSender = XposedHelpers.findClass(WechatConfig.CLASS_SEND_MODEL, loader);
        Object senderObject = XposedHelpers.callStaticMethod(classSender, WechatConfig.METHOD_SEND_MODEL_GET_MESSAGE_SENDER);

        XposedHelpers.callMethod(senderObject, "a", new Object[]{addMemberObject, Integer.valueOf(0)});
        LogUtils.log(TAG, "拉人进群任务执行结束");
    }

    /**
     * 修改群名称
     * 从修改群名称的UI入手
     *
     * @param loader
     * @param chatroomTalker
     * @param name
     */
    public static void changeName(final ClassLoader loader, final String chatroomTalker, final String name) {
        new Thread(new Runnable() {
            @Override
            public void run() {
                LogUtils.log(TAG, "执行修改群名称命令");

                Class classChatroomModel = XposedHelpers.findClass(WechatConfig.CHAT_ROOM_NAME_OBJECT_CLASS, loader);
                Object nameObject = XposedHelpers.callMethod(XposedHelpers.newInstance(classChatroomModel), WechatConfig.CHAT_ROOM_NAME_OBJECT_METHOD_SET, name);
                Object talkerObject = XposedHelpers.callMethod(XposedHelpers.newInstance(classChatroomModel), WechatConfig.CHAT_ROOM_NAME_OBJECT_METHOD_SET, chatroomTalker);

                Class classAsb = XposedHelpers.findClass(WechatConfig.CHAT_ROOM_OBJECT_CLASS, loader);
                Object objectAsb = XposedHelpers.newInstance(classAsb);
                XposedHelpers.setObjectField(objectAsb, WechatConfig.CHAT_ROOM_OBJECT_FIELD_TALKER, talkerObject);
                XposedHelpers.setObjectField(objectAsb, WechatConfig.CHAT_ROOM_OBJECT_FIELD_NAME, nameObject);

                Class classEA = XposedHelpers.findClass(WechatConfig.CHAT_ROOM_CHANGE_NAME_OBJECT_CLASS, loader);
                Object objectEA = XposedHelpers.newInstance(classEA, 27, objectAsb);

                Class classSendModel = XposedHelpers.findClass(WechatConfig.CLASS_SEND_MODEL, loader);
                XposedHelpers.callStaticMethod(classSendModel, WechatConfig.CHAT_ROOM_METHOD_MMCORE_INIT, new Object[0]);

                Class classModelC = XposedHelpers.findClass(WechatConfig.CHAT_ROOM_CLASS_MODEL_C, loader);
                Object objectFe = XposedHelpers.callStaticMethod(classModelC, WechatConfig.CHAT_ROOM_GET_FE_METHOD);
                XposedHelpers.callMethod(objectFe, WechatConfig.CHAT_ROOM_CHANGE_NAME_SEND_METHOD, objectEA);
                LogUtils.log(TAG, "修改群名称任务执行结束");
            }
        }).start();

    }

    /**
     * 修改群公告
     *
     * @param loader
     * @param chatroomTalker
     * @param notice
     */
    public static void changeNotice(ClassLoader loader, String chatroomTalker, String notice) {
        try {
            LogUtils.log(TAG, "执行修改群公告命令");
            CommonHook.coreInit(loader);
            Class classSetNotice = XposedHelpers.findClass(WechatConfig.CHAT_ROOM_CLASS_SET_NOTICE, loader);

            Class classSender = XposedHelpers.findClass(WechatConfig.CLASS_SEND_MODEL, loader);
            Object senderObject = XposedHelpers.callStaticMethod(classSender, WechatConfig.METHOD_SEND_MODEL_GET_MESSAGE_SENDER, new Object[0]);

            Object objectSetNotice = XposedHelpers.newInstance(classSetNotice, new Object[]{chatroomTalker, notice});
            boolean result = (boolean) XposedHelpers.callMethod(senderObject, "a", new Object[]{objectSetNotice, Integer.valueOf(0)});
            LogUtils.log(TAG, "修改群公告任务执行结束 : " + result);
        } catch (Exception ex) {
            XposedBridge.log(ex);
        }
    }

    /**
     * 修改群昵称
     *
     * @param loader
     * @param talker
     * @param chatroomTalker
     * @param nickname
     */
    public static void changeNickname(ClassLoader loader, String talker, String chatroomTalker, String nickname) {
        try {
            LogUtils.log(TAG, "执行修改群昵称命令");
            CommonHook.coreInit(loader);
            Class ajv = XposedHelpers.findClass(WechatConfig.CHAT_ROOM_NICK_PROTOCOL, loader);
            Class ea = XposedHelpers.findClass(WechatConfig.CHAT_ROOM_CHANGE_NAME_OBJECT_CLASS, loader);
            Class an = XposedHelpers.findClass(WechatConfig.CLASS_SEND_MODEL, loader);
            Class modelc = XposedHelpers.findClass(WechatConfig.CHAT_ROOM_CLASS_MODEL_C, loader);
            Object ajvvar = XposedHelpers.newInstance(ajv, new Object[0]);
            XposedHelpers.setObjectField(ajvvar, WechatConfig.CHAR_ROOM_FIELD_NICK_PROTOCOL_CHATROOM_TALKER, chatroomTalker);
            XposedHelpers.setObjectField(ajvvar, WechatConfig.CHAR_ROOM_FIELD_NICK_PROTOCOL_TALKER, talker);
            XposedHelpers.setObjectField(ajvvar, WechatConfig.CHAR_ROOM_FIELD_NICK_PROTOCOL_NICKNAME, nickname);
            Object kjA = XposedHelpers.newInstance(ea, new Object[]{Integer.valueOf(48), ajvvar});
            XposedHelpers.callStaticMethod(an, WechatConfig.CHAT_ROOM_METHOD_MMCORE_INIT, new Object[0]);
            XposedHelpers.callMethod(XposedHelpers.callStaticMethod(modelc, WechatConfig.CHAT_ROOM_GET_FE_METHOD, new Object[0]), WechatConfig.CHAT_ROOM_CHANGE_NAME_SEND_METHOD, new Object[]{kjA});
            LogUtils.log(TAG, "修改群昵称任务执行结束");
        } catch (Exception ex) {
            XposedBridge.log(ex);
        }
    }

    /**
     * 退群
     * @param classLoader
     * @param chatroomTalker
     */
    public static void quit(ClassLoader classLoader, String chatroomTalker) {
        try {
            CommonHook.coreInit(classLoader);
            Class xc = XposedHelpers.findClass(WechatConfig.CHAT_ROOM_CLASS_MODEL_C, classLoader);
            Object b = XposedHelpers.callStaticMethod(xc, WechatConfig.METHOD_DELETE_CHATROOM_FV);

            Class aub = XposedHelpers.findClass(WechatConfig.CLASS_CHATROOM_E_A, classLoader);
            Object obj = XposedHelpers.newInstance(aub, chatroomTalker);
            XposedHelpers.callMethod(b, WechatConfig.METHOD_DELETE_CHATROOM_B, obj);

            CommonHook.coreInit(classLoader);
            XposedHelpers.callMethod(XposedHelpers.callStaticMethod(xc, WechatConfig.METHOD_DELETE_CHATROOM_FB), WechatConfig.METHOD_DELETE_CHATROOM_FROM_RCONVERSATION, chatroomTalker);

            CommonHook.coreInit(classLoader);
            Class auc = XposedHelpers.findClass(WechatConfig.DELETE_FRIEND_MODEL_CLASS, classLoader);
            Object bObj = XposedHelpers.newInstance(auc, chatroomTalker);
            XposedHelpers.callMethod(b, WechatConfig.METHOD_DELETE_CHATROOM_B, bObj);

            CommonHook.coreInit(classLoader);
            XposedHelpers.callStaticMethod(xc, WechatConfig.METHOD_DELETE_CHATROOM_FV);

            CommonHook.coreInit(classLoader);
            Class aup = XposedHelpers.findClass(WechatConfig.CLASS_CHAT_ROOM_E_C, classLoader);
            Object xi = XposedHelpers.callMethod(XposedHelpers.callStaticMethod(xc, WechatConfig.METHOD_CHATROOM_INFO), "get", new Object[]{Integer.valueOf(2), null});
            Object objAup = XposedHelpers.newInstance(aup, xi, chatroomTalker);
            XposedHelpers.callMethod(b, WechatConfig.METHOD_DELETE_CHATROOM_B, objAup);

            Boolean bool = (Boolean) XposedHelpers.callStaticMethod(XposedHelpers.findClass(WechatConfig.CLASS_CHATROOM_MEMBERS_LOGIC, classLoader), WechatConfig.METHOD_DELETE_CHATROOM, chatroomTalker);
        } catch (Exception ex) {
            LogUtils.log(TAG, ex.getMessage());
        }
    }


}
