package com.baigesoft.corelib.wechat;

import android.content.ContentValues;
import android.text.TextUtils;

import com.baigesoft.corelib.Constants;
import com.baigesoft.corelib.NewFriendReply;
import com.baigesoft.corelib.db.ContactManager;
import com.baigesoft.corelib.model.WechatContact;
import com.baigesoft.corelib.model.WechatMessage;
import com.baigesoft.corelib.model.WechatMessageType;
import com.baigesoft.corelib.model.WechatUser;
import com.baigesoft.corelib.utils.LogUtils;
import com.baigesoft.corelib.utils.MessageUtils;
import com.baigesoft.corelib.utils.StringUtils;

import org.jsoup.Jsoup;
import org.jsoup.safety.Whitelist;

import de.robv.android.xposed.callbacks.XC_LoadPackage;

/**
 * Created by Dawei on 31/07/2017.
 */

public class SendSystem {

    private static final String TAG = "Plugin_SendSystem";

    /**
     * 处理文本消息
     *
     * @param packageParam
     * @param contentValues
     * @param currentUser
     */
    public static void processMessage(final XC_LoadPackage.LoadPackageParam packageParam, ContentValues contentValues, WechatUser currentUser) {
        //是否发送：0为接收的消息；1为发送的消息
        Integer isSend = contentValues.getAsInteger("isSend");
        Integer status = contentValues.getAsInteger("status");

        String talker = contentValues.getAsString("talker");
        if (TextUtils.isEmpty(talker)) {
            LogUtils.log(TAG, "talkerid 为空");
            return;
        }
        //跳过群消息
        if (!Constants.HANDLE_CHAT_ROOM && talker.endsWith("@chatroom")) {
            return;
        }

        ContactManager contactManager = new ContactManager(packageParam.classLoader);
        String nickName = contactManager.getNickName(talker);
        String friendImg = contactManager.getImg(talker);

        WechatMessage wechatMessage = new WechatMessage(WechatMessageType.SYSTEM);
        wechatMessage.setSourceWeixinId(currentUser.weixinId);
        wechatMessage.setSourceMobile(currentUser.mobile);
        wechatMessage.setSourceTalker(currentUser.talkerId);
        wechatMessage.setTalker(talker);
        wechatMessage.setNick(nickName);
        wechatMessage.setFriendImg(friendImg);
        wechatMessage.setCreateTime(contentValues.getAsLong("createTime"));
        wechatMessage.setStatus(status);
        wechatMessage.setSend((isSend == null || isSend == 1) ? true : false);
        wechatMessage.setMsgId(contentValues.getAsLong("msgId"));
        wechatMessage.setMsgSvrId(contentValues.getAsLong("msgSvrId"));

        //内容
        String content = contentValues.getAsString("content");
        //群聊
        if (wechatMessage.getTalker().endsWith("@chatroom")) {
            if (!TextUtils.isEmpty(content) && content.indexOf(":") > -1) {
                wechatMessage.setFriend_talker(content.substring(0, content.indexOf(":")));
                if(!TextUtils.isEmpty(wechatMessage.getFriend_talker())) {
                    wechatMessage.setFriend_chatroom_img(contactManager.getImg(wechatMessage.getFriend_talker()));
                }
                content = content.substring(content.indexOf(":") + 1);
            }
        }

        //被删掉
//        if (status != null && status.intValue() == 4) {
//            //TODO 清理僵尸粉
//
//        }

        if (TextUtils.isEmpty(content)) {
            return;
        }

        //打招呼
        if (isSend.intValue() == 0 && content.contains("以上是打招呼的内容")) {
            wechatMessage.setContent(content);
            MessageUtils.addMessage(wechatMessage);
            return;
        }

        //通过好友申请
        if ((content.contains("你已添加") || content.contains("添加到通讯录")) && content.contains("现在可以开始聊天了")) {
            wechatMessage.setContent(content);
            if (TextUtils.isEmpty(wechatMessage.getNick()) || wechatMessage.getTalker().equals(wechatMessage.getNick())) {
                if (content.contains("刚刚把")) {
                    int index = content.indexOf("刚刚把");
                    if(index > -1) {
                        wechatMessage.setNick(content.substring(0, index));
                    }
                } else if (content.contains("你已添加了")) {
                    wechatMessage.setNick(StringUtils.subString(content, "你已添加了", "，现在可以"));
                }
            }

            //新的好友
            WechatContact contact = contactManager.getContact(wechatMessage.getTalker());
            if (contact != null) {
                if(TextUtils.isEmpty(contact.getNickname())) {
                    contact.setNickname(wechatMessage.getNick());
                }
                contact.setSourceTalker(currentUser.talkerId);
                contact.setSourceWeixinId(currentUser.weixinId);
                contact.setSourceMobile(currentUser.mobile);
                MessageUtils.addFriend(contact);
            }

            //自动消息
            new NewFriendReply(packageParam, currentUser).reply(talker, 1, wechatMessage.getNick(), friendImg);
            MessageUtils.addMessage(wechatMessage);
            return;
        }

        //好友申请通过验证
        if (content.contains("我通过了你的") && content.contains("验证请求")) {
            wechatMessage.setContent(content);
            //新的好友
            WechatContact contact = contactManager.getContact(wechatMessage.getTalker());
            if (contact != null) {
                contact.setSourceTalker(currentUser.talkerId);
                contact.setSourceWeixinId(currentUser.weixinId);
                contact.setSourceMobile(currentUser.mobile);
                MessageUtils.addFriend(contact);
            }
            //自动消息
            new NewFriendReply(packageParam, currentUser).reply(talker, 2, wechatMessage.getNick(), friendImg);
            MessageUtils.addMessage(wechatMessage);
            return;
        }

        //被踢出群
        if (content.contains("你被") && content.contains("移出群聊")) {
            wechatMessage.setContent(content);
            wechatMessage.setNick(StringUtils.subString(content, "你被\"", "\"移出群聊"));
            MessageUtils.addMessage(wechatMessage);
            return;
        }

        //被删除
        if (content.contains("消息已发出，但被对方拒收了") && content.contains("开启了朋友验证")) {
            wechatMessage.setContent(content);
            MessageUtils.addMessage(wechatMessage);

            //删除好友
            MessageUtils.removeFriend(currentUser.weixinId, currentUser.mobile, wechatMessage.getTalker());
            return;
        }

        //红包被领取
        if (isSend.intValue() != 0 && content.contains("领取了") && content.contains("SystemMessages_HongbaoIcon")) {
            return;
        }

        content = content.replace("_wc_custom_link_", "a");
        content = Jsoup.clean(content, Whitelist.simpleText());
        wechatMessage.setContent(content);
        MessageUtils.addMessage(wechatMessage);

//        LogUtils.log(TAG, "收到消息：[" + wechatMessage.getNick() + "]" + content);

    }

}
