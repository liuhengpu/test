package com.baigesoft.corelib.wechat;

import android.content.ContentValues;
import android.os.CountDownTimer;
import android.text.TextUtils;
import android.util.Log;

import com.baigesoft.corelib.Constants;
import com.baigesoft.corelib.VersionCode;
import com.baigesoft.corelib.WechatHook;
import com.baigesoft.corelib.config.WechatConfig;
import com.baigesoft.corelib.db.ContactManager;
import com.baigesoft.corelib.db.SystemManager;
import com.baigesoft.corelib.model.WechatMessage;
import com.baigesoft.corelib.model.WechatMessageType;
import com.baigesoft.corelib.model.WechatUser;
import com.baigesoft.corelib.robot.AutoReply;
import com.baigesoft.corelib.utils.ClassUtils;
import com.baigesoft.corelib.utils.FileUtils;
import com.baigesoft.corelib.utils.LogUtils;
import com.baigesoft.corelib.utils.MessageUtils;
import com.baigesoft.corelib.utils.RandomUtils;
import com.baigesoft.corelib.utils.StringUtils;

import java.io.File;
import java.io.IOException;
import java.io.RandomAccessFile;

import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

/**
 * Created by Dawei on 19/05/2017.
 */

public class SendVoice {

    private static final String TAG = "Plugin_SendVoice";

    private XC_LoadPackage.LoadPackageParam packageParam;

    //接收者
    private String talker;

    //音频路径
    private String path;

    public SendVoice(XC_LoadPackage.LoadPackageParam packageParam, String talker, String path) {
        this.packageParam = packageParam;
        this.talker = talker;
        this.path = path;
    }

    /**
     * 发送消息
     */
    public void send() {
        final File file = new File(path);
        if (!file.exists()) {
            return;
        }

        Object sendMethod = null;
        if (WechatHook.version.equals(VersionCode.V6523)
                || WechatHook.version.equals(VersionCode.V663)
                || WechatHook.version.equals(VersionCode.V665)
                || WechatHook.version.equals(VersionCode.V666)
                || WechatHook.version.equals(VersionCode.V667)
                || WechatHook.version.equals(VersionCode.V672)
                || WechatHook.version.equals(VersionCode.V673)) {

            Class modelClass = ClassUtils.getClass(packageParam.classLoader, WechatConfig.CLASS_SEND_MODEL);
            if (modelClass == null) {
                LogUtils.log(TAG, "modelClass为空");
                return;
            }
            sendMethod = XposedHelpers.callStaticMethod(modelClass, WechatConfig.METHOD_SEND_MODEL_GET_VOICE_SENDER, new Object[0]);
        } else {
            Object objectG = XposedHelpers.callStaticMethod(XposedHelpers.findClass(WechatConfig.CLASS_KERNEL_PATH, packageParam.classLoader), WechatConfig.METHOD_SEND_MODEL_GET_VOICE_SENDER);
            sendMethod = XposedHelpers.getObjectField(objectG, WechatConfig.FIELD_GET_VOICE_SENDER_OBJECT);
        }

        Runnable runnable = new Runnable() {
            @Override
            public void run() {

                Class m = XposedHelpers.findClass(WechatConfig.CLASS_VOICE_CREATE, packageParam.classLoader);
                Class q = XposedHelpers.findClass(WechatConfig.CLASS_VOICE_FILE_CREATE, packageParam.classLoader);
                if (m == null || q == null) {
                    LogUtils.log(TAG, "语音创建对象为空");
                    return;
                }

                String mfilename = (String) XposedHelpers.callStaticMethod(q, WechatConfig.METHOD_VOICE_FILE_CREATE_NAME, new Object[]{talker});
                String mfilepath = (String) XposedHelpers.callStaticMethod(q, WechatConfig.METHOD_VOICE_FILE_CREATE_PATH, new Object[]{mfilename});

                if (FileUtils.moveFile(path, mfilepath)) {

                    int duration = 60000;
                    try {
                        duration = getAmrDuration(file);
                    } catch (Exception ex) {
                        LogUtils.log(TAG, "获取音频文件时长失败");
                    }

                    if (WechatHook.version.equals(VersionCode.V6523) || WechatHook.version.equals(VersionCode.V663)) {
                        XposedHelpers.callStaticMethod(q, WechatConfig.METHOD_VOICE_FILE_LENGTH, new Object[]{mfilename, duration, 0});
                    } else {
                        XposedHelpers.callStaticMethod(q, WechatConfig.METHOD_VOICE_FILE_LENGTH, new Object[]{mfilename, duration});
                    }
                    XposedHelpers.callMethod(XposedHelpers.callStaticMethod(m, WechatConfig.METHOD_VOICE_TRANSFER, new Object[0]), "run", new Object[0]);
                    LogUtils.log(TAG, "发送语音完成");
                }
            }
        };

        //发送语音
        XposedHelpers.callMethod(sendMethod, WechatConfig.METHOD_SENDER_SEND_VOICE_VIDEO, new Object[]{runnable});

    }

    /**
     * 得到amr的时长
     *
     * @param file
     * @return amr文件时间长度
     * @throws IOException
     */
    public static int getAmrDuration(File file) throws IOException {
        long duration = -1;
        int[] packedSize = {12, 13, 15, 17, 19, 20, 26, 31, 5, 0, 0, 0, 0, 0,
                0, 0};
        RandomAccessFile randomAccessFile = null;
        try {
            randomAccessFile = new RandomAccessFile(file, "rw");
            long length = file.length();// 文件的长度
            int pos = 6;// 设置初始位置
            int frameCount = 0;// 初始帧数
            int packedPos = -1;

            byte[] datas = new byte[1];// 初始数据值
            while (pos <= length) {
                randomAccessFile.seek(pos);
                if (randomAccessFile.read(datas, 0, 1) != 1) {
                    duration = length > 0 ? ((length - 6) / 650) : 0;
                    break;
                }
                packedPos = (datas[0] >> 3) & 0x0F;
                pos += packedSize[packedPos] + 1;
                frameCount++;
            }

            duration += frameCount * 20;// 帧数*20
        } finally {
            if (randomAccessFile != null) {
                randomAccessFile.close();
            }
        }
//        return (int)((duration/1000)+1);
        return (int) duration;

    }

    /**
     * 处理语音消息
     *
     * @param packageParam
     * @param contentValues
     * @param currentUser
     */
    public static void processMessage(final XC_LoadPackage.LoadPackageParam packageParam, ContentValues contentValues, WechatUser currentUser) {
        if (!Constants.HANDLE_VOICE_MSG) {
            return;
        }
        final String talker = contentValues.getAsString("talker");
        if (TextUtils.isEmpty(talker)) {
            LogUtils.log(TAG, "talkerid 为空");
            return;
        }
        //跳过群消息
        if (!Constants.HANDLE_CHAT_ROOM && talker.endsWith("@chatroom")) {
            return;
        }

        String userDir = new SystemManager(packageParam.classLoader).getUserDir();
        if (TextUtils.isEmpty(userDir)) {
            LogUtils.log(TAG, "获取用户目录失败");
            return;
        }

        //是否发送：0为接收的消息；1为发送的消息
        Integer isSend = contentValues.getAsInteger("isSend");
        if (isSend == null || isSend.intValue() == 1) {
            return;
        }

        ContactManager contactManager = new ContactManager(packageParam.classLoader);
        String nickName = contactManager.getNickName(talker);
        String friendImg = contactManager.getImg(talker);

        WechatMessage wechatMessage = new WechatMessage(WechatMessageType.VOICE);
        wechatMessage.setSourceWeixinId(currentUser.weixinId);
        wechatMessage.setSourceMobile(currentUser.mobile);
        wechatMessage.setSourceTalker(currentUser.talkerId);
        wechatMessage.setTalker(talker);
        wechatMessage.setNick(nickName);
        wechatMessage.setFriendImg(friendImg);
        wechatMessage.setCreateTime(contentValues.getAsLong("createTime"));
        wechatMessage.setStatus(contentValues.getAsInteger("status"));
        wechatMessage.setSend((isSend.intValue() == 1) ? true : false);
        wechatMessage.setMsgId(contentValues.getAsLong("msgId"));
        wechatMessage.setMsgSvrId(contentValues.getAsLong("msgSvrId"));

        //内容
        String content = contentValues.getAsString("content");
        //群聊
        if (wechatMessage.getTalker().endsWith("@chatroom")) {
            if (!TextUtils.isEmpty(content) && content.indexOf(":") > -1) {
                wechatMessage.setFriend_talker(content.substring(0, content.indexOf(":")));
                if (!TextUtils.isEmpty(wechatMessage.getFriend_talker())) {
                    wechatMessage.setFriend_chatroom_img(contactManager.getImg(wechatMessage.getFriend_talker()));
                }
            }
        }

        String imgPath = contentValues.getAsString("imgPath");
        String fname = StringUtils.md5(imgPath);

        String filePath = userDir + "voice2/" + fname.substring(0, 2) + "/" + fname.substring(2, 4) + "/" + String.format("msg_%s.amr", imgPath);

        wechatMessage.setContent(filePath);

        //是否是自动聊天对象
        String reply = AutoReply.randomTalkVoice(talker);

        //是否启用自动回复
        if (TextUtils.isEmpty(reply)) {
            reply = AutoReply.replyVoice(talker);
        }

        //不自动回复，直接上传消息
        if (TextUtils.isEmpty(reply)) {
            MessageUtils.uploadMessage(wechatMessage);
            return;
        }

        //自动回复消息，不进行上传
        int duration = 30000;
        try {
            duration = getAmrDuration(new File(reply));
        } catch (Exception ex) {
            LogUtils.log(TAG, "获取音频文件时长失败");
        }
        LogUtils.log(TAG, "语音时长：" + duration);

        int millSeconds = RandomUtils.randomInt(duration, duration + 10000);
        Log.d(TAG, "延迟：" + millSeconds);

        new SendVoiceCountDownTimer(millSeconds, millSeconds, packageParam, talker, reply).start();
    }

    static class SendVoiceCountDownTimer extends CountDownTimer {

        private String talker;
        private String voice;
        private XC_LoadPackage.LoadPackageParam packageParam;

        public SendVoiceCountDownTimer(long millisInFuture, long countDownInterval, final XC_LoadPackage.LoadPackageParam packageParam, String talker, String voice) {
            super(millisInFuture, countDownInterval);
            this.talker = talker;
            this.voice = voice;
            this.packageParam = packageParam;
        }

        @Override
        public void onTick(long millisUntilFinished) {

        }

        @Override
        public void onFinish() {
            new SendVoice(packageParam, talker, voice).send();
            LogUtils.log(TAG, "回复语音完成： " + voice);
        }
    }

}
