package com.baigesoft.corelib.wechat;

import com.baigesoft.corelib.config.WechatConfig;
import com.baigesoft.corelib.utils.LogUtils;

import de.robv.android.xposed.XposedHelpers;

public class CommonHook {

    private static final String TAG = "Plugin_CommonHook";

    /**
     * 微信内核初始化
     *
     * @param loader
     * @return
     */
    public static boolean coreInit(ClassLoader loader) {
        try {
            Class classSendModel = XposedHelpers.findClass(WechatConfig.CLASS_SEND_MODEL, loader);
            XposedHelpers.callStaticMethod(classSendModel, WechatConfig.CHAT_ROOM_METHOD_MMCORE_INIT, new Object[0]);
            Boolean isNull = (Boolean) XposedHelpers.callStaticMethod(classSendModel, WechatConfig.CHAT_ROOM_METHOD_CHECK_MMCORE_INIT, new Object[0]);
            if (isNull != null) {
                return isNull.booleanValue();
            }
        } catch (Exception ex) {
            LogUtils.log(TAG, ex.getMessage());
        }
        return true;
    }

}
