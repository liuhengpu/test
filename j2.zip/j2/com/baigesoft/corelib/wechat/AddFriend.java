package com.baigesoft.corelib.wechat;


import com.baigesoft.corelib.VersionCode;
import com.baigesoft.corelib.WechatHook;
import com.baigesoft.corelib.config.WechatConfig;
import com.baigesoft.corelib.utils.LogUtils;

import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;

import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

/**
 * Created by Dawei on 23/06/2017.
 */

public class AddFriend implements Runnable {

    private static final String TAG = "Plugin_AddFriend";

    private XC_LoadPackage.LoadPackageParam packageParam;

    private String talker;

    private int source;

    private String hi;


    public AddFriend(XC_LoadPackage.LoadPackageParam packageParam, String talker, int source, String hi) {
        this.packageParam = packageParam;
        this.talker = talker;
        this.source = source;
        this.hi = hi;
    }

    @Override
    public void run() {
        addfriend();
    }

    private void addfriend() {

        LogUtils.log(TAG, "添加好友，talker:" + talker + ", source:" + source + ", content:" + hi);
        try {

            Class clsPluginsdkModelM = XposedHelpers.findClass(WechatConfig.CLASS_PLUGINSDK_MODEL_M, packageParam.classLoader);

            Class clsModelAl = XposedHelpers.findClass(WechatConfig.CLASS_SEND_MODEL, packageParam.classLoader);

            List talkerList = new LinkedList();
            talkerList.add(talker);

            List sourceList = new LinkedList();
            sourceList.add(source);

            HashMap talkerMap = new HashMap();

            Object addmodel = null;
            try {
                if (WechatHook.version.equals(VersionCode.V6523)) {
                    addmodel = XposedHelpers.newInstance(clsPluginsdkModelM, talkerList, sourceList, hi, "", talkerMap, null);
                } else if (WechatHook.version.equals(VersionCode.V663) || WechatHook.version.equals(VersionCode.V665) || WechatHook.version.equals(VersionCode.V666)) {
                    addmodel = XposedHelpers.newInstance(clsPluginsdkModelM, 2, talkerList, sourceList, hi, "", talkerMap, null);
                } else {
                    addmodel = XposedHelpers.newInstance(clsPluginsdkModelM, talkerList, sourceList, hi, "", talkerMap, null);
                }
            } catch (Exception ex) {
                ex.printStackTrace();
            }

            boolean result = (boolean) XposedHelpers.callMethod(XposedHelpers.callStaticMethod(clsModelAl, WechatConfig.METHOD_SEND_MODEL_GET_MESSAGE_SENDER, new Object[0]), WechatConfig.METHOD_SENDER_SEND, new Object[]{addmodel});
            if (result) {
                LogUtils.log(TAG, "加好友请求发送成功！");
            }
        } catch (Exception ex) {
            LogUtils.log(TAG, "添加好友抛出异常：" + ex.getMessage());
        }
    }
}
