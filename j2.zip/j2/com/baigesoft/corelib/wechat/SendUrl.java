package com.baigesoft.corelib.wechat;

import android.content.ContentValues;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.text.TextUtils;
import android.util.Base64;

import com.baigesoft.corelib.Constants;
import com.baigesoft.corelib.config.WechatConfig;
import com.baigesoft.corelib.db.ContactManager;
import com.baigesoft.corelib.model.WechatMessage;
import com.baigesoft.corelib.model.WechatMessageType;
import com.baigesoft.corelib.model.WechatUser;
import com.baigesoft.corelib.utils.LogUtils;
import com.baigesoft.corelib.utils.MessageUtils;
import com.baigesoft.corelib.utils.StringUtils;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;

import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

/**
 * Created by Dawei on 31/07/2017.
 */

public class SendUrl implements Runnable {

    private static final String TAG = "Plugin_SendUrl";

    private XC_LoadPackage.LoadPackageParam packageParam;

    private ClassLoader classLoader;

    //接收者
    private String talker;

    //链接
    private String url;

    /**
     * 缩略图
     */
    private String thumbnail;

    /**
     * 标题
     */
    private String title;

    /**
     * 描述
     */
    private String description;

    private String myTalker = "";

    public SendUrl(XC_LoadPackage.LoadPackageParam packageParam, String myTalker, String talker, String url, String thumbnail, String title, String description) {
        this.packageParam = packageParam;
        this.classLoader = packageParam.classLoader;
        this.talker = talker;
        this.url = url;
        this.thumbnail = thumbnail;
        this.title = title;
        this.description = description;
        this.myTalker = myTalker;
    }

    public void run() {
        sendUrl();
    }

    /**
     * 发送链接
     */
    private void sendUrl() {
        LogUtils.log(TAG, "发送链接: " + url);

        //缩略图
        Class clsUrlImage = XposedHelpers.findClass(WechatConfig.CLASS_URL_IMAGE, classLoader);
        Bitmap urlThumbnail = null;
        if (!TextUtils.isEmpty(thumbnail)) {
            try {
                urlThumbnail = BitmapFactory.decodeFile(thumbnail);
            } catch (Exception ex) {
            }
            if (urlThumbnail != null) {
                XposedHelpers.callStaticMethod(clsUrlImage, WechatConfig.METHOD_URL_IMAGE_PUSH, thumbnail, urlThumbnail);
            }
        }

        //组装链接对象
        Class clsWebPageObject = XposedHelpers.findClass(WechatConfig.CLASS_WEBPAGE_OBJECT, classLoader);
        Object objWebPageObject = XposedHelpers.newInstance(clsWebPageObject);
        XposedHelpers.setObjectField(objWebPageObject, WechatConfig.FIELD_WEBPAGE_URL, url);

        Class clsMediaMessage = XposedHelpers.findClass(WechatConfig.CLASS_MEDIA_MESSAGE, classLoader);
        Object objMediaMessage = XposedHelpers.newInstance(clsMediaMessage);
        XposedHelpers.setObjectField(objMediaMessage, WechatConfig.FIELD_MEDIA_MESSAGE_MEDIA_OBJECT, objWebPageObject);
        XposedHelpers.setObjectField(objMediaMessage, WechatConfig.FIELD_MEDIA_MESSAGE_TITLE, title);
        XposedHelpers.setObjectField(objMediaMessage, WechatConfig.FIELD_MEDIA_MESSAGE_DESCRIPTION, description);

        if (urlThumbnail != null) {
            ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
            urlThumbnail.compress(Bitmap.CompressFormat.WEBP, 100, byteArrayOutputStream);
            XposedHelpers.setObjectField(objMediaMessage, WechatConfig.FIELD_MEDIA_MESSAGE_THUMB_DATA, byteArrayOutputStream.toByteArray());
        } else {
            XposedHelpers.setObjectField(objMediaMessage, WechatConfig.FIELD_MEDIA_MESSAGE_THUMB_DATA, Base64.decode("/9j/4AAQSkZJRgABAQEAYABgAAD/2wBDAAMCAgMCAgMDAwMEAwMEBQgFBQQEBQoHBwYIDAoMDAsKCwsNDhIQDQ4RDgsLEBYQERMUFRUVDA8XGBYUGBIUFRT/2wBDAQMEBAUEBQkFBQkUDQsNFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBT/wAARCAAxADEDASIAAhEBAxEB/8QAHwAAAQUBAQEBAQEAAAAAAAAAAAECAwQFBgcICQoL/8QAtRAAAgEDAwIEAwUFBAQAAAF9AQIDAAQRBRIhMUEGE1FhByJxFDKBkaEII0KxwRVS0fAkM2JyggkKFhcYGRolJicoKSo0NTY3ODk6Q0RFRkdISUpTVFVWV1hZWmNkZWZnaGlqc3R1dnd4eXqDhIWGh4iJipKTlJWWl5iZmqKjpKWmp6ipqrKztLW2t7i5usLDxMXGx8jJytLT1NXW19jZ2uHi4+Tl5ufo6erx8vP09fb3+Pn6/8QAHwEAAwEBAQEBAQEBAQAAAAAAAAECAwQFBgcICQoL/8QAtREAAgECBAQDBAcFBAQAAQJ3AAECAxEEBSExBhJBUQdhcRMiMoEIFEKRobHBCSMzUvAVYnLRChYkNOEl8RcYGRomJygpKjU2Nzg5OkNERUZHSElKU1RVVldYWVpjZGVmZ2hpanN0dXZ3eHl6goOEhYaHiImKkpOUlZaXmJmaoqOkpaanqKmqsrO0tba3uLm6wsPExcbHyMnK0tPU1dbX2Nna4uPk5ebn6Onq8vP09fb3+Pn6/9oADAMBAAIRAxEAPwD9Mde1240u8WKJY9mzd8wrP/4S29/uw/kaXxd/yFE/65J/6E9YVAG5/wAJbe/3YfyNH/CW3v8Adh/I1h1eTSp3VP8AVo7fdR22O1AF7/hLb3+7D+RrY8P6pNqizmdVBTb9yuMdGRtrfeSun8G/6m6/31oA6aiiigDjvF3/ACFE/wCuSf8AoT1hVu+Lv+Qon/XJP/QnqhpSI9193e6q7qn996ACwRYYri5lXe8Wzaj/AN+j7NLc3SNPKqeavm+a7fwUWyT38su6RkRv9fK9Q39ys0qLEv7qJdib6AC/uVub2WRfuM1dB4N/1N1/vrXL11Hg3/U3X++tAHTUUUUAcd4u/wCQon/XJP8A0J6wkdkfcrbHrtdV8PrqlykrTbNq7fu1S/4Qxf8An6f/AL5oA5+a/ubldss7OlV66j/hDF/5+n/75o/4Qxf+fp/++aAOXrqPBv8Aqbr/AH1o/wCEMX/n6f8A75rT0jR10lJFWQy+Yc8rQBp0UUUAFFFFABRRRQAUUUUAFFFFAH//2Q==", 0));
        }

        Class clsUrlMessage = XposedHelpers.findClass(WechatConfig.CLASS_URL_MESSAGE, classLoader);
        Object objUrlMessageGetter = XposedHelpers.newInstance(clsUrlMessage);
        Object objUrlMessage = XposedHelpers.getObjectField(objUrlMessageGetter, WechatConfig.FIELD_URL_MESSAGE_MSG);
        XposedHelpers.setObjectField(objUrlMessage, WechatConfig.FIELD_URL_MESSAGE_MEDIA, objMediaMessage);
        XposedHelpers.setObjectField(objUrlMessage, WechatConfig.FIELD_URL_MESSAGE_APP_NAME, "");
        XposedHelpers.setObjectField(objUrlMessage, WechatConfig.FIELD_URL_MESSAGE_TO_USER, talker);
        XposedHelpers.setObjectField(objUrlMessage, WechatConfig.FIELD_URL_MESSAGE_INT, Integer.valueOf(2));
        XposedHelpers.setObjectField(objUrlMessage, WechatConfig.FIELD_URL_MESSAGE_OWNER_TALKER, myTalker);
        XposedHelpers.setObjectField(objUrlMessage, WechatConfig.FIELD_URL_MESSAGE_SNSAD, "");
        XposedHelpers.setObjectField(objUrlMessage, WechatConfig.FIELD_URL_MESSAGE_URL, url);


        Class clsUrlSenderGetter = XposedHelpers.findClass(WechatConfig.CLASS_URL_SENDER_GETTER, classLoader);
        Object objUrlSender = XposedHelpers.getObjectField(XposedHelpers.newInstance(clsUrlSenderGetter), WechatConfig.FIELD_URL_SENDER_GETTER_FIELD);

        XposedHelpers.callMethod(objUrlSender, WechatConfig.METHOD_URL_SENDER_SEND, new Object[]{objUrlMessageGetter});
    }

    /**
     * 处理文本消息
     *
     * @param packageParam
     * @param contentValues
     * @param currentUser
     */
    public static void processMessage(final XC_LoadPackage.LoadPackageParam packageParam, ContentValues contentValues, WechatUser currentUser) {
        String talker = contentValues.getAsString("talker");
        if (TextUtils.isEmpty(talker)) {
            LogUtils.log(TAG, "talkerid 为空");
            return;
        }
        //跳过群消息
        if (!Constants.HANDLE_CHAT_ROOM && talker.endsWith("@chatroom")) {
            return;
        }

        //是否发送：0为接收的消息；1为发送的消息
        Integer isSend = contentValues.getAsInteger("isSend");
        //发送的消息不上传
        if (isSend == null || isSend == 1) {
            return;
        }

        ContactManager contactManager = new ContactManager(packageParam.classLoader);
        String nickName = contactManager.getNickName(talker);
        String friendImg = contactManager.getImg(talker);

        WechatMessage wechatMessage = new WechatMessage(WechatMessageType.URL);
        wechatMessage.setSourceWeixinId(currentUser.weixinId);
        wechatMessage.setSourceMobile(currentUser.mobile);
        wechatMessage.setSourceTalker(currentUser.talkerId);
        wechatMessage.setTalker(talker);
        wechatMessage.setNick(nickName);
        wechatMessage.setFriendImg(friendImg);
        wechatMessage.setCreateTime(contentValues.getAsLong("createTime"));
        wechatMessage.setStatus(contentValues.getAsInteger("status"));
        wechatMessage.setSend((isSend == null || isSend == 1) ? true : false);
        wechatMessage.setMsgId(contentValues.getAsLong("msgId"));
        wechatMessage.setMsgSvrId(contentValues.getAsLong("msgSvrId"));

        //内容
        String content = contentValues.getAsString("content");
        if (TextUtils.isEmpty(content)) {
            return;
        }

        //群聊
        if (wechatMessage.getTalker().endsWith("@chatroom")) {
            if (!TextUtils.isEmpty(content) && content.indexOf(":") > -1) {
                wechatMessage.setFriend_talker(content.substring(0, content.indexOf(":")));
                if (!TextUtils.isEmpty(wechatMessage.getFriend_talker())) {
                    wechatMessage.setFriend_chatroom_img(contactManager.getImg(wechatMessage.getFriend_talker()));
                }
            }
        }

        //链接
        if (content.contains("<type>5</type>") || content.contains("<type>4</type>")) {
            JSONObject jsonObject = new JSONObject();
            try {
                String url = StringUtils.subXmlString(content, "<url>", "</url>");
                //邀请进群消息，不添加超链接
                if (url.contains("mmsupport-bin/addchatroombyinvite")) {
                    url = "";
                }
                jsonObject.put("title", StringUtils.subXmlString(content, "<title>", "</title>"));
                jsonObject.put("des", StringUtils.subXmlString(content, "<des>", "</des>"));
                jsonObject.put("url", url);
            } catch (JSONException ex) {
            }
            wechatMessage.setContent(jsonObject.toString());
            MessageUtils.addMessage(wechatMessage);
            return;
        }

        //网址
        if (content.contains("<type>6</type>")) {
            JSONObject jsonObject = new JSONObject();
            try {
                String title = StringUtils.subXmlString(content, "<title>", "</title>");
                String des = StringUtils.subXmlString(content, "<des>", "</des>");
                if (TextUtils.isEmpty(title)) {
                    title = des;
                }
                jsonObject.put("title", title);
                jsonObject.put("des", des);
                jsonObject.put("url", "");
            } catch (JSONException ex) {
            }
            wechatMessage.setContent(jsonObject.toString());
            MessageUtils.addMessage(wechatMessage);
            return;
        }

        //小程序
        if (content.contains("<type>33</type>")) {
            JSONObject jsonObject = new JSONObject();
            try {
                String title = StringUtils.subXmlString(content, "<title>", "</title>");
                String icon = StringUtils.subXmlString(content, "<weappiconurl>", "</weappiconurl>");
                String name = StringUtils.subXmlString(content, "<sourcedisplayname>", "</sourcedisplayname>");
                String appid = StringUtils.subXmlString(content, "<appid>", "</appid>");
                String gh = StringUtils.subXmlString(content, "<username>", "</username>");
                String page = StringUtils.subXmlString(content, "<pagepath>", "</pagepath>");
                if (!TextUtils.isEmpty(gh)) {
                    gh = gh.replaceAll("@app", "");
                }

                jsonObject.put("title", title);
                jsonObject.put("name", name);
                jsonObject.put("img", icon);
                jsonObject.put("page", page);
                jsonObject.put("appid", appid);
                jsonObject.put("gh", gh);
            } catch (JSONException ex) {
            }
            wechatMessage.setContent(jsonObject.toString());
            wechatMessage.setType(WechatMessageType.URL_SMALL_APP);
            MessageUtils.addMessage(wechatMessage);
            return;
        }

        if (content.contains("<type>24</type>")) {
            return;
        }


        //其它，如笔记文件等
        String title = StringUtils.subXmlString(content, "<des>", "</des>");
        if (TextUtils.isEmpty(title)) {
            title = "笔记文件";
        }
        JSONObject jsonObject = new JSONObject();
        try {
            jsonObject.put("title", title);
            jsonObject.put("des", "请在手机上查看笔记文件");
            jsonObject.put("url", "");
        } catch (JSONException ex) {
        }
        wechatMessage.setContent(jsonObject.toString());
        MessageUtils.addMessage(wechatMessage);
        return;

    }

}
