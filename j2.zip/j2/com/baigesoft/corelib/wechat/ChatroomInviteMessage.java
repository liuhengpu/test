package com.baigesoft.corelib.wechat;

import android.content.ContentValues;
import android.text.TextUtils;

import com.baigesoft.corelib.Constants;
import com.baigesoft.corelib.db.ContactManager;
import com.baigesoft.corelib.model.WechatMessage;
import com.baigesoft.corelib.model.WechatMessageType;
import com.baigesoft.corelib.model.WechatUser;
import com.baigesoft.corelib.utils.LogUtils;
import com.baigesoft.corelib.utils.MessageUtils;
import com.baigesoft.corelib.utils.XmlParser;

import org.json.JSONException;
import org.json.JSONObject;

import de.robv.android.xposed.callbacks.XC_LoadPackage;

public class ChatroomInviteMessage {

    private static final String TAG = "Plugin_ChatroomInviteMsg";

    /**
     * 处理文本消息
     *
     * @param packageParam
     * @param contentValues
     * @param currentUser
     */
    public static void processMessage(final XC_LoadPackage.LoadPackageParam packageParam, ContentValues contentValues, WechatUser currentUser) {
        //是否发送：0为接收的消息；1为发送的消息
        Integer isSend = contentValues.getAsInteger("isSend");
        Integer status = contentValues.getAsInteger("status");

        String talker = contentValues.getAsString("talker");
        if (TextUtils.isEmpty(talker)) {
            LogUtils.log(TAG, "talkerid 为空");
            return;
        }
        //跳过群消息
        if (!Constants.HANDLE_CHAT_ROOM && talker.endsWith("@chatroom")) {
            return;
        }

        ContactManager contactManager = new ContactManager(packageParam.classLoader);
        String nickName = contactManager.getNickName(talker);
        String friendImg = contactManager.getImg(talker);

        WechatMessage wechatMessage = new WechatMessage(WechatMessageType.SYSTEM);
        wechatMessage.setSourceWeixinId(currentUser.weixinId);
        wechatMessage.setSourceMobile(currentUser.mobile);
        wechatMessage.setSourceTalker(currentUser.talkerId);
        wechatMessage.setTalker(talker);
        wechatMessage.setNick(nickName);
        wechatMessage.setFriendImg(friendImg);
        wechatMessage.setCreateTime(contentValues.getAsLong("createTime"));
        wechatMessage.setStatus(status);
        wechatMessage.setSend((isSend == null || isSend == 1) ? true : false);
        wechatMessage.setMsgId(contentValues.getAsLong("msgId"));
        wechatMessage.setMsgSvrId(contentValues.getAsLong("msgSvrId"));

        //内容
        String content = contentValues.getAsString("content");
        //群聊
        if (wechatMessage.getTalker().endsWith("@chatroom")) {
            if (!TextUtils.isEmpty(content) && content.indexOf(":") > -1) {
                wechatMessage.setFriend_talker(content.substring(0, content.indexOf(":")));
                if (!TextUtils.isEmpty(wechatMessage.getFriend_talker())) {
                    wechatMessage.setFriend_chatroom_img(contactManager.getImg(wechatMessage.getFriend_talker()));
                }
                content = content.substring(content.indexOf(":") + 1);
            }
        }

        if (TextUtils.isEmpty(content)) {
            return;
        }

        //邀请进群
        if (content.contains("\"$username$\"邀请\"$names$\"加入了群聊") || content.contains("你邀请\"$names$\"加入了群聊")) {
            XmlParser xmlParser = new XmlParser(content);
            String toUserName = xmlParser.getText("link[name=names]>memberlist>member>username");
            String toNickName = xmlParser.getText("link[name=names]>memberlist>member>nickname");
            String fromUserName = "";
            String fromNickName = "";
            if (content.contains("\"$username$\"邀请")) {
                fromUserName = xmlParser.getText("link[name=username]>memberlist>member>username");
                fromNickName = xmlParser.getText("link[name=username]>memberlist>member>nickname");
            } else if (content.contains("你邀请")) {
                fromUserName = currentUser.username;
                fromNickName = currentUser.nickname;
            }

            JSONObject jsonObject = new JSONObject();
            try {
                jsonObject.put("fromUsername", fromUserName);
                jsonObject.put("fromNickname", fromNickName);
                jsonObject.put("toUsername", toUserName);
                jsonObject.put("toNickname", toNickName);
            } catch (JSONException ex) {

            }

            wechatMessage.setContent(jsonObject.toString());
            MessageUtils.addMessage(wechatMessage);
            return;
        }

    }

}
