package com.baigesoft.corelib.wechat;

import android.content.ContentValues;
import android.text.TextUtils;

import com.baigesoft.corelib.Constants;
import com.baigesoft.corelib.VersionCode;
import com.baigesoft.corelib.WechatHook;
import com.baigesoft.corelib.config.WechatConfig;
import com.baigesoft.corelib.db.ContactManager;
import com.baigesoft.corelib.db.SystemManager;
import com.baigesoft.corelib.model.WechatMessage;
import com.baigesoft.corelib.model.WechatMessageType;
import com.baigesoft.corelib.model.WechatUser;
import com.baigesoft.corelib.utils.FileUtils;
import com.baigesoft.corelib.utils.LogUtils;
import com.baigesoft.corelib.utils.MessageUtils;
import com.baigesoft.corelib.utils.VideoUtils;

import java.io.File;

import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

/**
 * Created by Dawei on 19/05/2017.
 */

public class SendVideo implements Runnable {

    private static final String TAG = "Plugin_SendVideo";

    private XC_LoadPackage.LoadPackageParam packageParam;

    //接收者
    private String talker;

    //视频路径
    private String mp4Path;

    public SendVideo(XC_LoadPackage.LoadPackageParam packageParam, String talker, String mp4Path) {
        this.packageParam = packageParam;
        this.talker = talker;
        this.mp4Path = mp4Path;
    }

    public void run() {
        send();
    }

    /**
     * 发送消息
     */
    public void send() {
        final File mp4File = new File(mp4Path);
        if (!mp4File.exists()) {
            LogUtils.log(TAG, "mp4文件不存在！");
            return;
        }

//        Class modelClass = ClassUtils.getClass(packageParam.classLoader, WechatConfig.CLASS_SEND_MODEL);
//        if (modelClass == null) {
//            LogUtils.log(TAG, "modelClass为空");
//            return;
//        }

//        Object sendMethod = XposedHelpers.callStaticMethod(modelClass, WechatConfig.METHOD_SEND_MODEL_GET_VOICE_SENDER, new Object[0]);

        Runnable runnable = new Runnable() {
            @Override
            public void run() {
                Class MainSight = XposedHelpers.findClass(WechatConfig.CLASS_CREATE_VIDEO_FILE, packageParam.classLoader);
                String filename = (String) XposedHelpers.callStaticMethod(MainSight, WechatConfig.METHOD_CREATE_VIDEO_FILE_NAME, new Object[]{talker});
                if (TextUtils.isEmpty(filename)) {
                    LogUtils.log(TAG, "文件名不存在");
                    return;
                }

                String Mp4FilePath = (String) XposedHelpers.callStaticMethod(MainSight, WechatConfig.METHOD_CREATE_VIDEO_FILE_MP4, new Object[]{filename});
                LogUtils.log(TAG, "mp4path：" + Mp4FilePath);

                if (!FileUtils.moveFile(mp4Path, Mp4FilePath)) {
                    LogUtils.log(TAG, "移动视频失败：[from]" + mp4Path + "[to]" + Mp4FilePath);
                }

                String Jpgfilepath = (String) XposedHelpers.callStaticMethod(MainSight, WechatConfig.METHOD_CREATE_VIDEO_FILE_THUMBNAIL, new Object[]{filename});
                LogUtils.log(TAG, "jpgPath：" + Jpgfilepath);

                VideoUtils.createThumb(mp4Path, Jpgfilepath);
                Class aso = XposedHelpers.findClass(WechatConfig.CLASS_CREATE_VIDEO, packageParam.classLoader);
                if (WechatHook.version.equals("6.5.7")) {
                    LogUtils.log(TAG, "6.5.7返回值：" + XposedHelpers.callStaticMethod(aso, WechatConfig.METHOD_CREATE_VIDEO_D, new Object[]{filename, Integer.valueOf(6), talker}));
                } else if(WechatHook.version.equals(VersionCode.V6523)
                        || WechatHook.version.equals(VersionCode.V663)
                        || WechatHook.version.equals(VersionCode.V665)
                        || WechatHook.version.equals(VersionCode.V666)) {
                    LogUtils.log(TAG, "返回值：" + XposedHelpers.callStaticMethod(aso, WechatConfig.METHOD_CREATE_VIDEO_D, new Object[]{filename, Integer.valueOf(6), talker, null, 62}));
                }else{
                    LogUtils.log(TAG, "返回值：" + XposedHelpers.callStaticMethod(aso, WechatConfig.METHOD_CREATE_VIDEO_D, new Object[]{filename, talker, null, 62}));
                }
                XposedHelpers.callStaticMethod(aso, WechatConfig.METHOD_CREATE_VIDEO_F, new Object[]{filename, Integer.valueOf(6), Integer.valueOf(62)});
                XposedHelpers.callStaticMethod(aso, WechatConfig.METHOD_CREATE_VIDEO_LT, new Object[]{filename});

                LogUtils.log(TAG, "发送视频完成");

            }
        };

        //发送视频
//        XposedHelpers.callMethod(sendMethod, WechatConfig.METHOD_SENDER_SEND_VOICE_VIDEO, new Object[]{runnable});

        new Thread(runnable).start();
    }

    /**
     * 处理视频消息
     *
     * @param packageParam
     * @param contentValues
     * @param currentUser
     */
    public static void processMessage(final XC_LoadPackage.LoadPackageParam packageParam, ContentValues contentValues, WechatUser currentUser) {
        if (!Constants.HANDLE_VIDEO_MSG) {
            return;
        }
        String talker = contentValues.getAsString("talker");
        if(TextUtils.isEmpty(talker)){
            LogUtils.log(TAG, "talkerid 为空");
            return;
        }

        //跳过处理群消息
        if (!Constants.HANDLE_CHAT_ROOM && talker.endsWith("@chatroom")) {
            return;
        }

        String userDir = new SystemManager(packageParam.classLoader).getUserDir();
        if (TextUtils.isEmpty(userDir)) {
            LogUtils.log(TAG, "获取用户目录失败");
            return;
        }

        String imgPath = contentValues.getAsString("imgPath");
        if (TextUtils.isEmpty(imgPath)) {
            LogUtils.log(TAG, "视频文件路径为空");
            return;
        }

        //是否发送：0为接收的消息；1为发送的消息
        Integer isSend = contentValues.getAsInteger("isSend");
        if (isSend == null || isSend == 1) {
            LogUtils.log(TAG, "发送的小视频");
            return;
        }

        ContactManager contactManager = new ContactManager(packageParam.classLoader);
        String nickName = contactManager.getNickName(talker);
        String friendImg = contactManager.getImg(talker);

        WechatMessage wechatMessage = new WechatMessage(WechatMessageType.VIDEO);
        wechatMessage.setSourceWeixinId(currentUser.weixinId);
        wechatMessage.setSourceMobile(currentUser.mobile);
        wechatMessage.setSourceTalker(currentUser.talkerId);
        wechatMessage.setTalker(talker);
        wechatMessage.setNick(nickName);
        wechatMessage.setFriendImg(friendImg);
        wechatMessage.setCreateTime(contentValues.getAsLong("createTime"));
        wechatMessage.setStatus(contentValues.getAsInteger("status"));
        wechatMessage.setSend((isSend.intValue() == 1) ? true : false);
        wechatMessage.setMsgId(contentValues.getAsLong("msgId"));
        wechatMessage.setMsgSvrId(contentValues.getAsLong("msgSvrId"));

        //内容
        String content = contentValues.getAsString("content");
        //群聊
        if (wechatMessage.getTalker().endsWith("@chatroom")) {
            if (!TextUtils.isEmpty(content) && content.indexOf(":") > -1) {
                wechatMessage.setFriend_talker(content.substring(0, content.indexOf(":")));
                if(!TextUtils.isEmpty(wechatMessage.getFriend_talker())) {
                    wechatMessage.setFriend_chatroom_img(contactManager.getImg(wechatMessage.getFriend_talker()));
                }
            }
        }

        String bashPath = userDir + "video/" + imgPath;
        File mp4File = new File(bashPath + ".mp4");
        if (mp4File.exists()) {
            wechatMessage.setContent(mp4File.getAbsolutePath());
            MessageUtils.uploadMessage(wechatMessage);
            return;
        }

        //下载小视频
        File file = new File(bashPath + ".mp4.tmp");
        if (!mp4File.exists() && !file.exists()) {
            LogUtils.log(TAG, "开始下载小视频：" + file.getAbsolutePath());
            Object downloadVideoObject = XposedHelpers.newInstance(XposedHelpers.findClass(WechatConfig.CLASS_DOWNLOAD_VIDEO, packageParam.classLoader), imgPath, Boolean.valueOf(false));
            XposedHelpers.callMethod(XposedHelpers.callStaticMethod(XposedHelpers.findClass(WechatConfig.CLASS_SEND_MODEL, packageParam.classLoader), WechatConfig.METHOD_SEND_MODEL_GET_MESSAGE_SENDER), "a", downloadVideoObject, Integer.valueOf(0));
            LogUtils.log(TAG, "下载小视频完成");

            //缓存视频消息
            MessageUtils.VIDEO_CACHE.put(imgPath, wechatMessage);
        }
    }

    /**
     * 上传好友发过来的链接视频
     *
     * @param packageParam
     * @param contentValues
     * @param currentUser
     */
    public static void uploadVideo(final XC_LoadPackage.LoadPackageParam packageParam, ContentValues contentValues, WechatUser currentUser) {
        String talker = contentValues.getAsString("talker");
        if(TextUtils.isEmpty(talker)){
            LogUtils.log(TAG, "talkerid 为空");
            return;
        }
        //跳过群消息
        if (!Constants.HANDLE_CHAT_ROOM && talker.endsWith("@chatroom")) {
            return;
        }

        ContactManager contactManager = new ContactManager(packageParam.classLoader);
        String nickName = contactManager.getNickName(talker);
        String friendImg = contactManager.getImg(talker);

        WechatMessage wechatMessage = new WechatMessage(WechatMessageType.URL_VIDEO);
        wechatMessage.setSourceWeixinId(currentUser.weixinId);
        wechatMessage.setSourceMobile(currentUser.mobile);
        wechatMessage.setSourceTalker(currentUser.talkerId);
        wechatMessage.setTalker(talker);
        wechatMessage.setNick(nickName);
        wechatMessage.setFriendImg(friendImg);
        wechatMessage.setCreateTime(contentValues.getAsLong("createTime"));
        wechatMessage.setStatus(contentValues.getAsInteger("status"));
        wechatMessage.setSend(false);
        wechatMessage.setMsgId(contentValues.getAsLong("msgId"));
        wechatMessage.setMsgSvrId(contentValues.getAsLong("msgSvrId"));
        wechatMessage.setContent(contentValues.getAsString("imgPath"));

        if (!TextUtils.isEmpty(wechatMessage.getContent())) {
            MessageUtils.uploadMessage(wechatMessage);
            LogUtils.log(TAG, "上传62视频：" + wechatMessage.getContent());
        }
    }
}
