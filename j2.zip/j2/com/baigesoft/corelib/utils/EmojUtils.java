package com.baigesoft.corelib.utils;

/**
 * Created by Dawei on 01/08/2017.
 */

public class EmojUtils {

    private static String[] emojStrings = {"/::)", "/::~", "/::B", "/::|", "/:8-)", "/::<", "/::$", "/::X", "/::Z", "/::'(",
            "/::-|", "/::@", "/::P", "/::D", "/::O", "/::(", "/::[add]", "/:-b", "/::Q", "/::T",
            "/:,@P", "/:,@-D", "/::d", "/:,@o", "/::g", "/:|-)", "/::!", "/::L", "/::>", "/::,@",
            "/:,@f", "/::-S", "/:?", "/:,@x", "/:,@@", "/::8", "/:,@!", "/:!!!", "/:xx", "/:bye",
            "/:wipe", "/:dig", "/:handclap", "/:[and]-(", "/:B-)", "/:<@", "/:@>", "/::-O", "/:>-|", "/:P-(",
            "/::'|", "/:X-)", "/::*", "/:@x", "/:8*", "/:pd", "/:<W>", "/:beer", "/:basketb", "/:oo",
            "/:coffee", "/:eat", "/:pig", "/:rose", "/:fade", "/:showlove", "/:heart", "/:break", "/:cake", "/:li",
            "/:bome", "/:kn", "/:footb", "/:ladybug", "/:shit", "/:moon", "/:sun", "/:gift", "/:hug", "/:strong",
            "/:weak", "/:share", "/:v", "/:@)", "/:jj", "/:@@", "/:bad", "/:lvu", "/:no", "/:ok",
            "/:love", "/:<L>", "/:jump", "/:shake", "/:<O>", "/:circle", "/:kotow", "/:turn", "/:skip", "/:oY",
            "/:#-0", "", "/:kiss", "/:<[and]", "/:[and]>"
    };

    public static String getEmoj(int index){
        if(index < 1 || index > 105){
            return emojStrings[0];
        }
        return emojStrings[index-1];
    }


}
