package com.baigesoft.corelib.utils;

import java.security.MessageDigest;
import java.util.regex.Pattern;

/**
 * Created by Dawei on 22/05/2017.
 */

public class StringUtils {

    public static String subString(String source, String from, String to) {
        int start = source.indexOf(from);
        if (start != -1) {
            if (to.length() == 0) {
                return source.substring(from.length() + start);
            }
            int end = source.substring(from.length() + start).indexOf(to);
            if (end != -1) {
                return source.substring(from.length() + start, (from.length() + start) + end);
            }
        }
        return null;
    }

    public static String subXmlString(String source, String form, String to){
        String subStr = StringUtils.subString(source, form, to);
        if(subStr.contains("<![CDATA[") && subStr.contains("]]>")){
            subStr = StringUtils.subString(subStr, "<![CDATA[", "]]>");
        }
        return subStr;
    }

    public static String md5(String inStr) {
        try {
            int i;
            MessageDigest md5 = MessageDigest.getInstance("MD5");
            char[] charArray = inStr.toCharArray();
            byte[] byteArray = new byte[charArray.length];
            for (i = 0; i < charArray.length; i++) {
                byteArray[i] = (byte) charArray[i];
            }
            byte[] md5Bytes = md5.digest(byteArray);
            StringBuffer hexValue = new StringBuffer();
            for (byte b : md5Bytes) {
                int val = b & 255;
                if (val < 16) {
                    hexValue.append("0");
                }
                hexValue.append(Integer.toHexString(val));
            }
            return hexValue.toString();
        } catch (Exception e) {
            System.out.println(e.toString());
            e.printStackTrace();
            return "";
        }
    }

    public static boolean isMobile(String str) {
        return Pattern.matches("^((13[0-9])|(14[5,7])|(15[0-3,5-9])|(16[0-9])|(17[0,1,3,5-8])|(18[0-9])|(19[0-9])|(147))\\d{8}$", str);
    }

}
