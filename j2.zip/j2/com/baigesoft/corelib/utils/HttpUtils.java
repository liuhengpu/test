package com.baigesoft.corelib.utils;

import com.baigesoft.corelib.WechatHook;
import com.loopj.android.http.AsyncHttpResponseHandler;
import com.loopj.android.http.RequestParams;
import com.loopj.android.http.SyncHttpClient;

import org.apache.http.Header;
import org.apache.http.entity.StringEntity;

import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Executors;

/**
 * Created by Dawei on 7/28/16.
 */
public class HttpUtils {

    private static SyncHttpClient client = null;

    private static void init() {
        if (client != null)
            return;
        client = new SyncHttpClient();
        client.setThreadPool(Executors.newFixedThreadPool(3));
        client.setMaxConnections(5);
        client.setConnectTimeout(3000);
        client.setResponseTimeout(3000);
    }

    /**
     * 下载
     * @param url
     * @return
     */
    public static byte[] download(String url){
        final List<byte[]> byteList = new ArrayList<>();
        get(url, null, new AsyncHttpResponseHandler() {
            @Override
            public void onSuccess(int statusCode, Header[] headers, byte[] responseBody) {
                byteList.add(responseBody);
            }

            @Override
            public void onFailure(int statusCode, Header[] headers, byte[] responseBody, Throwable error) {

            }
        });
        if(byteList.size() == 0){
            return null;
        }
        return byteList.get(0);
    }

    /**
     * Get获取网络内容
     *
     * @param url
     * @param responseHandler
     */
    public static void get(String url, AsyncHttpResponseHandler responseHandler) {
        get(url, null, responseHandler);
    }

    /**
     * Get获取网络内容
     *
     * @param url
     * @param params
     * @param responseHandler
     */
    public static void get(String url, RequestParams params, AsyncHttpResponseHandler responseHandler) {
        init();
        client.get(url, params, responseHandler);
    }

    /**
     * Post提交数据
     *
     * @param url
     * @param params
     * @param responseHandler
     */
    public static void post(String url, RequestParams params, AsyncHttpResponseHandler responseHandler) {
        init();
        client.post(url, params, responseHandler);
    }

    public static void postJson(String url, String json, AsyncHttpResponseHandler responseHandler) {
        init();
        try {
            client.post(WechatHook.context, url, new StringEntity(json, "utf-8"), "application/json; charset=utf-8", responseHandler);
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }
    }

}
