package com.baigesoft.corelib.utils;

import android.graphics.Bitmap;
import android.media.ThumbnailUtils;
import android.provider.MediaStore;

import java.io.FileOutputStream;
import java.io.IOException;

/**
 * Created by Dawei on 22/05/2017.
 */

public class VideoUtils {

    private static final String TAG = "Plugin_VideoUtils";

    public static void createThumb(String mp4Uri, String thumbUri) {
        try {
            Bitmap bitmap = ThumbnailUtils.createVideoThumbnail(mp4Uri, MediaStore.Images.Thumbnails.MINI_KIND);
            if (bitmap != null) {
                FileOutputStream out = new FileOutputStream(thumbUri);
                bitmap.compress(Bitmap.CompressFormat.JPEG, 90, out);
                out.flush();
                out.close();
            }
        } catch (IOException ex) {
            LogUtils.log(TAG, ex.getMessage());
        }
    }

}
