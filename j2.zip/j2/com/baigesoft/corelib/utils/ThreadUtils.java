package com.baigesoft.corelib.utils;

import android.os.Handler;
import android.os.HandlerThread;
import android.os.Looper;
import java.util.concurrent.TimeUnit;

public class ThreadUtils {
    private static volatile ThreadUtils helper;
    private static Handler sUIHandler;
    private static HandlerThread workerThread = new HandlerThread("sWorkerThread");
    private static Handler worker = null;

    static {
        workerThread.start();
        worker = new Handler(workerThread.getLooper());
    }

    private ThreadUtils() {
    }

    public static ThreadUtils getInstance() {
        if (helper == null) {
            synchronized (ThreadUtils.class) {
                if (helper == null) {
                    helper = new ThreadUtils();
                }
            }
        }
        return helper;
    }

    private static boolean isCurrentUIThread() {
        return Looper.getMainLooper() == Looper.myLooper();
    }

    private static Handler getUIHandler() {
        synchronized (ThreadUtils.class) {
            if (sUIHandler == null) {
                sUIHandler = new Handler(Looper.getMainLooper());
            }
        }
        return sUIHandler;
    }

    public static void runOnUIThread(Runnable runnable) {
        if (isCurrentUIThread()) {
            runnable.run();
        } else {
            getUIHandler().post(runnable);
        }
    }

    public static void runOnWorkerThread(Runnable runnable) {
        if (isCurrentUIThread()) {
            worker.post(runnable);
        } else {
            runnable.run();
        }
    }

    public static void runOnWorkerThreadDelayed(long time, TimeUnit unit, Runnable runnable) {
        long delay = time;
        if (unit != null) {
            delay = unit.toMillis(time);
        }
        worker.postDelayed(runnable, delay);
    }
}