package com.baigesoft.corelib.utils;

import android.content.Intent;
import android.text.TextUtils;

import com.baigesoft.corelib.Constants;
import com.baigesoft.corelib.MarketingActions;
import com.baigesoft.corelib.WechatHook;
import com.baigesoft.corelib.db.ChatRoomManager;
import com.baigesoft.corelib.db.ContactManager;
import com.baigesoft.corelib.db.UserManager;
import com.baigesoft.corelib.model.ChatRoom;
import com.baigesoft.corelib.model.WechatContact;
import com.baigesoft.corelib.model.WechatMessage;
import com.baigesoft.corelib.model.WechatUser;
import com.loopj.android.http.RequestParams;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.Hashtable;
import java.util.List;

/**
 * Created by Dawei on 19/07/2017.
 */

public class MessageUtils {

    private static final String TAG = "Plugin_MsgUtils";

    public static final Hashtable<String, WechatMessage> IMAGE_CACHE = new Hashtable<>();

    public static final Hashtable<String, WechatMessage> VIDEO_CACHE = new Hashtable<>();

    /**
     * 添加消息到服务端
     *
     * @param message
     */
    public static void addMessage(final WechatMessage message) {
        addMessage(message, false);
    }

    /**
     * 添加消息到服务端
     *
     * @param message
     * @param sync    是否同步
     */
    public static void addMessage(final WechatMessage message, boolean sync) {
        if (WechatUtils.skipTalker(message.getTalker())) {
            return;
        }
        RequestParams requestParams = new RequestParams();
        requestParams.add("sn", WechatHook.getSn());
        requestParams.add("sourceTalker", message.getSourceTalker());
        requestParams.add("sourceWeixinId", message.getSourceWeixinId());
        requestParams.add("sourceMobile", message.getSourceMobile());
        requestParams.add("type", "" + message.getType());
        requestParams.add("talker", message.getTalker());
        requestParams.add("nickname", message.getNick());
        requestParams.add("friend_img", message.getFriendImg());
        requestParams.add("createTime", "" + message.getCreateTime());
        requestParams.add("content", message.getContent());
        requestParams.add("status", "" + message.getStatus());
        requestParams.add("isSend", (message.isSend() ? "1" : "0"));
        requestParams.add("msgId", "" + (message.getMsgId() == null ? 0 : message.getMsgId()));
        requestParams.add("msgSvrId", "" + (message.getMsgSvrId() == null ? 0 : message.getMsgSvrId()));
        requestParams.add("friend_talker", message.getFriend_talker() == null ? "" : message.getFriend_talker());
        requestParams.add("friend_chatroom_img", message.getFriend_chatroom_img() == null ? "" : message.getFriend_chatroom_img());
        JsonResponseHandler jsonResponseHandler = new JsonResponseHandler() {
            @Override
            public void success(JSONObject jsonObject) {
                if (jsonObject == null || jsonObject.optInt("result", 0) != 1) {
                    LogUtils.log(TAG, "[上传消息失败]" + jsonObject.toString());
                }
            }

            @Override
            public void failure(String responseString) {
                LogUtils.log(TAG, "[上传消息出错]" + responseString);
            }
        };
        String url = Constants.SERVER_URL + "/wechat/add_msg.do";
        if (sync) {
            HttpUtils.post(url, requestParams, jsonResponseHandler);
        } else {
            AsyncHttpUtils.post(url, requestParams, jsonResponseHandler);
        }
    }

    /**
     * 上传消息
     *
     * @param wechatMessage
     */
    public static void uploadMessage(WechatMessage wechatMessage) {
        LogUtils.log(TAG, "上传消息：" + wechatMessage.getContent());
        Intent intent = new Intent(Constants.BROADCAST_MARKETING_ACTION);
        intent.putExtra("action", MarketingActions.UPLOAD_MESSAGE);
        intent.putExtra("sourceTalker", wechatMessage.getSourceTalker());
        intent.putExtra("sourceWeixinId", wechatMessage.getSourceWeixinId());
        intent.putExtra("sourceMobile", wechatMessage.getSourceMobile());
        intent.putExtra("type", wechatMessage.getType());
        intent.putExtra("msgSvrId", (wechatMessage.getMsgSvrId() == null ? 0 : wechatMessage.getMsgSvrId()));
        intent.putExtra("msgId", (wechatMessage.getMsgId() == null ? 0 : wechatMessage.getMsgId()));
        intent.putExtra("talker", wechatMessage.getTalker());
        intent.putExtra("nickname", wechatMessage.getNick());
        intent.putExtra("createTime", wechatMessage.getCreateTime());
        intent.putExtra("friendImg", wechatMessage.getFriendImg());
        intent.putExtra("content", wechatMessage.getContent());
        WechatHook.sendBroadcast(intent);
        LogUtils.log(TAG, "上传消息结束：" + wechatMessage.getContent());
    }

    /**
     * 添加任务日志
     *
     * @param push_id
     * @param friend
     * @param content
     */
    public static void taskLog(int push_id, String friend, String content) {
        LogUtils.log(TAG, "任务日志：" + friend + " : " + content);
        Intent intent = new Intent(Constants.BROADCAST_MARKETING_ACTION);
        intent.putExtra("action", MarketingActions.TASK_LOG);
        intent.putExtra("push_id", push_id);
        intent.putExtra("friend", friend);
        intent.putExtra("content", content);
        WechatHook.sendBroadcast(intent);
        LogUtils.log(TAG, "任务日志结束：" + push_id);
    }

    /**
     * 任务结果上报
     *
     * @param push_id
     * @param success
     * @param json
     */
    public static void taskResult(int push_id, boolean success, String json) {
        if (push_id <= 0) {
            return;
        }
        LogUtils.log(TAG, "任务结果：" + success + " : " + json);
        Intent intent = new Intent(Constants.BROADCAST_MARKETING_ACTION);
        intent.putExtra("action", MarketingActions.TASK_RESULT);
        intent.putExtra("push_id", push_id);
        intent.putExtra("success", success);
        intent.putExtra("json", json);
        WechatHook.sendBroadcast(intent);
        LogUtils.log(TAG, "任务结果结束：" + push_id);
    }

    /**
     * 添加好友
     *
     * @param contact
     * @param sync
     */
    public static void addFriend(WechatContact contact, boolean sync) {
        if (contact == null) {
            return;
        }
        RequestParams requestParams = new RequestParams();
        requestParams.add("sn", WechatHook.getSn());
        requestParams.add("sourceWeixinId", contact.getSourceWeixinId());
        requestParams.add("sourceMobile", contact.getSourceMobile());
        requestParams.add("sourceTalker", contact.getSourceTalker());
        requestParams.add("talker", TextUtils.isEmpty(contact.getTalker()) ? "" : contact.getTalker());
        requestParams.add("alias", TextUtils.isEmpty(contact.getAlias()) ? "" : contact.getAlias());
        requestParams.add("conRemark", TextUtils.isEmpty(contact.getConRemark()) ? "" : contact.getConRemark());
        requestParams.add("nickname", TextUtils.isEmpty(contact.getNickname()) ? "" : contact.getNickname());
        requestParams.add("pyInitial", TextUtils.isEmpty(contact.getPyInitial()) ? "" : contact.getPyInitial());
        requestParams.add("quanPin", TextUtils.isEmpty(contact.getQuanPin()) ? "" : contact.getQuanPin());
        requestParams.add("encryptUsername", TextUtils.isEmpty(contact.getEncryptUsername()) ? "" : contact.getEncryptUsername());
        requestParams.add("weibo", TextUtils.isEmpty(contact.getWeibo()) ? "" : contact.getWeibo());
        requestParams.add("tags", TextUtils.isEmpty(contact.getTags()) ? "" : contact.getTags());
        requestParams.add("sex", (contact.getSex() == null ? "0" : contact.getSex().toString()));
        requestParams.add("province", TextUtils.isEmpty(contact.getProvince()) ? "" : contact.getProvince());
        requestParams.add("city", TextUtils.isEmpty(contact.getCity()) ? "" : contact.getCity());
        requestParams.add("area_en", TextUtils.isEmpty(contact.getArea_en()) ? "" : contact.getArea_en());
        requestParams.add("source", (contact.getSource() == null ? "0" : contact.getSource().toString()));
        requestParams.add("description", TextUtils.isEmpty(contact.getDescription()) ? "" : contact.getDescription());
        requestParams.add("mobile", TextUtils.isEmpty(contact.getMobile()) ? "" : contact.getMobile());
        requestParams.add("sign", TextUtils.isEmpty(contact.getSign()) ? "" : contact.getSign());
        requestParams.add("friend_img", TextUtils.isEmpty(contact.getFriend_img()) ? "" : contact.getFriend_img());
        requestParams.add("chatroom", (contact.getChatroom() == null ? "0" : contact.getChatroom().toString()));

        JsonResponseHandler jsonResponseHandler = new JsonResponseHandler() {
            @Override
            public void success(JSONObject jsonObject) {
                if (jsonObject == null || jsonObject.optInt("result", 0) != 1) {
                    LogUtils.log(TAG, "[上传好友失败]" + jsonObject.toString());
                }
            }

            @Override
            public void failure(String responseString) {
                LogUtils.log(TAG, "[上传好友出错]" + responseString);
            }
        };
        String url = Constants.SERVER_URL + "/wechat/add_friend.do";
        if (sync) {
            HttpUtils.post(url, requestParams, jsonResponseHandler);
        } else {
            AsyncHttpUtils.post(url, requestParams, jsonResponseHandler);
        }
    }

    /**
     * 添加好友
     *
     * @param contact
     */
    public static void addFriend(WechatContact contact) {
        addFriend(contact, false);
    }


    /**
     * 更新好友
     *
     * @param contact
     * @param sync
     */
    public static void updateFriend(WechatContact contact, boolean sync) {
        if (contact == null) {
            return;
        }
        RequestParams requestParams = new RequestParams();
        requestParams.add("sn", WechatHook.getSn());
        requestParams.add("sourceWeixinId", contact.getSourceWeixinId());
        requestParams.add("sourceMobile", contact.getSourceMobile());
        requestParams.add("sourceTalker", contact.getSourceTalker());
        requestParams.add("talker", TextUtils.isEmpty(contact.getTalker()) ? "" : contact.getTalker());
        requestParams.add("alias", TextUtils.isEmpty(contact.getAlias()) ? "" : contact.getAlias());
        requestParams.add("conRemark", TextUtils.isEmpty(contact.getConRemark()) ? "" : contact.getConRemark());
        requestParams.add("nickname", TextUtils.isEmpty(contact.getNickname()) ? "" : contact.getNickname());
        requestParams.add("pyInitial", TextUtils.isEmpty(contact.getPyInitial()) ? "" : contact.getPyInitial());
        requestParams.add("quanPin", TextUtils.isEmpty(contact.getQuanPin()) ? "" : contact.getQuanPin());
        requestParams.add("encryptUsername", TextUtils.isEmpty(contact.getEncryptUsername()) ? "" : contact.getEncryptUsername());
        requestParams.add("weibo", TextUtils.isEmpty(contact.getWeibo()) ? "" : contact.getWeibo());
        requestParams.add("tags", TextUtils.isEmpty(contact.getTags()) ? "" : contact.getTags());
        requestParams.add("sex", (contact.getSex() == null ? "0" : contact.getSex().toString()));
        requestParams.add("province", TextUtils.isEmpty(contact.getProvince()) ? "" : contact.getProvince());
        requestParams.add("city", TextUtils.isEmpty(contact.getCity()) ? "" : contact.getCity());
        requestParams.add("area_en", TextUtils.isEmpty(contact.getArea_en()) ? "" : contact.getArea_en());
        requestParams.add("source", (contact.getSource() == null ? "0" : contact.getSource().toString()));
        requestParams.add("description", TextUtils.isEmpty(contact.getDescription()) ? "" : contact.getDescription());
        requestParams.add("mobile", TextUtils.isEmpty(contact.getMobile()) ? "" : contact.getMobile());
        requestParams.add("sign", TextUtils.isEmpty(contact.getSign()) ? "" : contact.getSign());
        requestParams.add("friend_img", TextUtils.isEmpty(contact.getFriend_img()) ? "" : contact.getFriend_img());
        requestParams.add("chatroom", (contact.getChatroom() == null ? "0" : contact.getChatroom().toString()));

        JsonResponseHandler jsonResponseHandler = new JsonResponseHandler() {
            @Override
            public void success(JSONObject jsonObject) {
                if (jsonObject == null || jsonObject.optInt("result", 0) != 1) {
                    LogUtils.log(TAG, "[更新好友失败]" + jsonObject.toString());
                }
            }

            @Override
            public void failure(String responseString) {
                LogUtils.log(TAG, "[更新好友出错]" + responseString);
            }
        };
        String url = Constants.SERVER_URL + "/wechat/update_friend.do";
        if (sync) {
            HttpUtils.post(url, requestParams, jsonResponseHandler);
        } else {
            AsyncHttpUtils.post(url, requestParams, jsonResponseHandler);
        }
    }

    /**
     * 删除好友
     */
    public static void removeFriend(String sourceWeixinId, String sourceMobile, String talker) {
        if (talker == null) {
            return;
        }
        RequestParams requestParams = new RequestParams();
        requestParams.add("sn", WechatHook.getSn());
        requestParams.add("sourceWeixinId", sourceWeixinId);
        requestParams.add("sourceMobile", sourceMobile);
        requestParams.add("talker", talker);
        String url = Constants.SERVER_URL + "/wechat/remove_friend.do";
        AsyncHttpUtils.post(url, requestParams, new JsonResponseHandler() {
            @Override
            public void success(JSONObject jsonObject) {
                LogUtils.log(TAG, "[删除好友失败]" + jsonObject.toString());
            }

            @Override
            public void failure(String responseString) {
                LogUtils.log(TAG, "[删除好友出错]" + responseString);
            }
        });
    }

    /**
     * 同步微信用户信息
     *
     * @param wechatUser
     * @param push_id
     */
    public static void syncUserInfo(WechatUser wechatUser, final int push_id) {
        LogUtils.log(TAG, "开始上传微信信息");
        RequestParams requestParams = new RequestParams();
        requestParams.add("sn", WechatHook.getSn());
        requestParams.add("push_id", "" + push_id);
        if (wechatUser == null && TextUtils.isEmpty(wechatUser.talkerId)) {
            requestParams.add("result", "0");
        } else {
            requestParams.add("result", "1");
            requestParams.add("talker", wechatUser.talkerId);
            requestParams.add("nickname", TextUtils.isEmpty(wechatUser.nickname) ? "" : wechatUser.nickname);
            requestParams.add("email", TextUtils.isEmpty(wechatUser.email) ? "" : wechatUser.email);
            requestParams.add("mobile", TextUtils.isEmpty(wechatUser.mobile) ? "" : wechatUser.mobile);
            requestParams.add("weixin_id", TextUtils.isEmpty(wechatUser.weixinId) ? "" : wechatUser.weixinId);
            requestParams.add("sex", "" + wechatUser.sex);
            requestParams.add("sign", TextUtils.isEmpty(wechatUser.sign) ? "" : wechatUser.sign);
            requestParams.add("province", TextUtils.isEmpty(wechatUser.province) ? "" : wechatUser.province);
            requestParams.add("city", TextUtils.isEmpty(wechatUser.area) ? "" : wechatUser.area);
            requestParams.add("qq", TextUtils.isEmpty(wechatUser.qq) ? "" : wechatUser.qq);
            requestParams.add("country", TextUtils.isEmpty(wechatUser.country) ? "" : wechatUser.country);
            requestParams.add("avatar", TextUtils.isEmpty(wechatUser.avatar) ? "" : wechatUser.avatar);
        }

        LogUtils.log(TAG, "上传微信信息：" + requestParams.toString());

        String url = Constants.SERVER_URL + "/wechat/sync.do";
        AsyncHttpUtils.post(url, requestParams, new JsonResponseHandler() {
            @Override
            public void success(JSONObject jsonObject) {
                if (jsonObject == null || jsonObject.optInt("result", 0) != 1) {
                    LogUtils.log(TAG, "[同步微信信息失败]" + jsonObject.toString());
                    if (jsonObject != null) {
                        taskLog(push_id, "同步失败", jsonObject.optString("msg", ""));
                    } else {
                        taskLog(push_id, "同步失败", "未返回失败原因");
                    }
                    return;
                }
                LogUtils.log(TAG, "同步微信成功");
            }

            @Override
            public void failure(String responseString) {
                LogUtils.log(TAG, "同步微信出错" + responseString);
                taskLog(push_id, "同步失败", "服务错误");
            }
        });
    }

    /**
     * 同步微信群
     *
     * @param classLoader
     * @param push_id
     * @param synced
     */
    public static void syncChatroom(ClassLoader classLoader, int push_id, boolean synced) {
        LogUtils.log(TAG, "开始同步微信群信息");
        WechatUser userInfo = new UserManager(classLoader).getCurrentUser();
        List<ChatRoom> chatRoomList = new ChatRoomManager(classLoader).getAllChatRooms();
        LogUtils.log(TAG, "获取到" + chatRoomList.size() + "个群，开始提交");
        taskLog(push_id, "", "获取到" + chatRoomList.size() + "个群");

        for (final ChatRoom chatRoom : chatRoomList) {
//            LogUtils.log(TAG, "群信息：" + chatRoom.toString());
            taskLog(push_id, chatRoom.getNickName(), "同步微信群");
            syncChatroom(classLoader, chatRoom, userInfo, push_id, synced);
        }
        LogUtils.log(TAG, "同步群完成：" + chatRoomList.size());
    }

    /**
     * 同步一个微信群
     *
     * @param classLoader
     * @param push_id
     * @param chatRoomTalker
     * @param synced
     */
    public static void syncChatroom(ClassLoader classLoader, int push_id, String chatRoomTalker, boolean synced) {
        WechatUser userInfo = new UserManager(classLoader).getCurrentUser();
        ChatRoom chatRoom = new ChatRoomManager(classLoader).getChatRoom(chatRoomTalker);
        if (chatRoom == null) {
            LogUtils.log(TAG, "获取微信群失败：" + chatRoomTalker);
            return;
        }
        syncChatroom(classLoader, chatRoom, userInfo, push_id, synced);
        LogUtils.log(TAG, "同步微信群完成：" + chatRoomTalker);
    }

    /**
     * 同步一个微信群
     *
     * @param classLoader
     * @param chatroom
     * @param currentUser
     * @param push_id
     * @param synced
     * @return
     */
    private static void syncChatroom(ClassLoader classLoader, final ChatRoom chatroom, WechatUser currentUser, final int push_id, boolean synced) {
        RequestParams requestParams = new RequestParams();
        requestParams.add("sn", WechatHook.getSn());
        requestParams.add("source_weixin_id", currentUser.weixinId);
        requestParams.add("source_mobile", currentUser.mobile);
        requestParams.add("source_talker", currentUser.talkerId);
        requestParams.add("push_id", "" + push_id);

        //群信息
        requestParams.add("talker", chatroom.getTalker());
        requestParams.add("nick_name", chatroom.getNickName());
        requestParams.add("member_count", "" + chatroom.getMemberCount());
        requestParams.add("owner", chatroom.getOwner());
        requestParams.add("owner_nick", chatroom.getOwnerNick());
        requestParams.add("friend_img", chatroom.getFriend_img());
        requestParams.add("notice", chatroom.getNotice());

        JSONArray memberArray = new JSONArray();

        ContactManager contactManager = new ContactManager(classLoader);
        for (String talker : chatroom.getMemberTalkers()) {
            WechatContact contact = contactManager.getContactWithoutType(talker);
            if (contact == null) {
                contact = new WechatContact();
                contact.setTalker(talker);
                contact.setAlias("");
                contact.setNickname(chatroom.getNickNameMap().get(talker));
                if(contact.getNickname() == null){
                    contact.setNickname("");
                }
                contact.setEncryptUsername("");
                contact.setSex(0);
                contact.setProvince("");
                contact.setCity("");
                contact.setArea_en("");
                contact.setMobile("");
                contact.setSign("");
                contact.setFriend_img("");
            }
            JSONObject contactObject = new JSONObject();
            try {
                contactObject.put("talker", contact.getTalker());
                contactObject.put("alias", contact.getAlias());
                contactObject.put("nickname", contact.getNickname());
                contactObject.put("encryptUsername", contact.getEncryptUsername());
                contactObject.put("sex", contact.getSex());
                contactObject.put("province", contact.getProvince());
                contactObject.put("city", contact.getCity());
                contactObject.put("area_en", contact.getArea_en());
                contactObject.put("mobile", contact.getMobile());
                contactObject.put("sign", contact.getSign());
                contactObject.put("friend_img", contact.getFriend_img());

                String chatNick = chatroom.getChatNameMap().get(contact.getTalker());
                if (TextUtils.isEmpty(chatNick)) {
                    contactObject.put("chat_nick", "");
                } else {
                    contactObject.put("chat_nick", chatNick);
                }
            } catch (JSONException ex) {
            }
            memberArray.put(contactObject);
        }
        requestParams.add("members", memberArray.toString());
        if (synced) {
            HttpUtils.post(Constants.SERVER_URL + "/wechat/sync_chatroom.do", requestParams, new JsonResponseHandler() {
                @Override
                public void success(JSONObject jsonObject) {
                    if (jsonObject == null) {
                        taskLog(push_id, chatroom.getTalker() + "同步群失败", "未返回失败原因");
                        LogUtils.log(TAG, "同步群失败：未返回失败原因");
                        return;
                    }
                    if (jsonObject.optInt("result", 0) != 1) {
                        taskLog(push_id, chatroom.getTalker() + "同步群失败", jsonObject.optString("msg", ""));
                        LogUtils.log(TAG, "同步群失败：" + jsonObject.optString("msg", ""));
                        return;
                    }
                    LogUtils.log(TAG, "[同步群成功]" + chatroom.getTalker());
                }

                @Override
                public void failure(String responseString) {
                    LogUtils.log(TAG, "同步群出错:" + chatroom.getTalker() + " : " + responseString);
                    taskLog(push_id, "同步群失败", "服务错误");
                }
            });
            return;
        }
        AsyncHttpUtils.post(Constants.SERVER_URL + "/wechat/sync_chatroom.do", requestParams, new JsonResponseHandler() {
            @Override
            public void success(JSONObject jsonObject) {
                if (jsonObject == null) {
                    taskLog(push_id, chatroom.getTalker() + "同步群失败", "未返回失败原因");
                    LogUtils.log(TAG, "同步群失败：未返回失败原因");
                    return;
                }
                if (jsonObject.optInt("result", 0) != 1) {
                    taskLog(push_id, chatroom.getTalker() + "同步群失败", jsonObject.optString("msg", ""));
                    LogUtils.log(TAG, "同步群失败：" + jsonObject.optString("msg", ""));
                    return;
                }
                LogUtils.log(TAG, "[同步群成功]" + chatroom.getTalker());
            }

            @Override
            public void failure(String responseString) {
                LogUtils.log(TAG, "同步群出错:" + chatroom.getTalker() + " : " + responseString);
                taskLog(push_id, "同步群失败", "服务错误");
            }
        });
    }

}
