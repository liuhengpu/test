package com.baigesoft.corelib.utils;

import java.util.HashMap;

import de.robv.android.xposed.XposedHelpers;

/**
 * Created by Dawei on 18/05/2017.
 */

public class ClassUtils {

    private static final HashMap<String, Class<?>> CLASS_MAP = new HashMap<>();

    /**
     * 获取类
     * @param classLoader
     * @param className
     * @return
     */
    public static Class<?> getClass(ClassLoader classLoader, String className){
        Class clazz = XposedHelpers.findClass(className, classLoader);
        return clazz;
    }

}
