package com.baigesoft.corelib.utils;

import android.util.Log;

import com.baigesoft.corelib.Constants;

import de.robv.android.xposed.XposedBridge;

/**
 * Created by Dawei on 4/21/17.
 */

public class LogUtils {

    /**
     * 日志
     * @param tag
     * @param text
     */
    public static void log(String tag, String text){
        if(!Constants.DEBUG)
            return;
        XposedBridge.log("「" + tag + "」" + text);
        Log.d(tag, text);
    }

}
