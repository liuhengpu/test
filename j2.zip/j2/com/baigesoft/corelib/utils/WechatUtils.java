package com.baigesoft.corelib.utils;

import android.text.TextUtils;

/**
 * Created by Dawei on 04/01/2018.
 */

public class WechatUtils {

    public static final String[] WECHAT_APPS = new String[]{"qqmail", "fmessage", "tmessage", "qmessage", "qqsync", "floatbottle", "lbsapp", "shakeapp", "medianote", "qqfriend", "newsapp", "blogapp", "facebookapp", "masssendapp", "feedsapp", "voipapp", "cardpackage", "voicevoipapp", "voiceinputapp", "officialaccounts", "linkedinplugin", "notifymessage", "appbrandcustomerservicemsg", "weixin", "helper_entry", "filehelper"};

    /**
     * 是否跳过用户名
     * @param talker
     * @return
     */
    public static boolean skipTalker(String talker) {
        if (TextUtils.isEmpty(talker)) {
            return true;
        }
        if (talker.startsWith("fake_") || talker.startsWith("gh_") || talker.endsWith("@stranger")) {
            return true;
        }
        for (String appname : WECHAT_APPS) {
            if (talker.equalsIgnoreCase(appname)) {
                return true;
            }
        }
        return false;
    }

}
