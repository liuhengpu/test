package com.baigesoft.corelib.utils;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.parser.Parser;
import org.jsoup.select.Elements;

public class XmlParser {

    private String xml;

    private Document document;

    public XmlParser(String xml) {
        this.xml = xml;
        document = Jsoup.parse(xml, "", Parser.xmlParser());
    }

    /**
     * 根据css表达式获取一个节点的文本内容
     * @param cssSelector
     * @return
     */
    public String getText(String cssSelector){
        Element element = getElement(cssSelector);
        if(element == null){
            return null;
        }
        return element.text();
    }

    /**
     * 根据css表达式获取一个节点
     * @param cssSelector
     * @return
     */
    public Element getElement(String cssSelector){
        Elements elements = findElements(cssSelector);
        if(elements == null || elements.isEmpty()){
            return null;
        }
        return elements.get(0);
    }

    /**
     * 根据css表达式获取多个节点
     * @param cssSelector
     * @return
     */
    public Elements findElements(String cssSelector){
        return document.select(cssSelector);
    }

}
