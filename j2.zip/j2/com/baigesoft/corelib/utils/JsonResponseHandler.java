package com.baigesoft.corelib.utils;

import android.util.Log;

import com.loopj.android.http.JsonHttpResponseHandler;

import org.apache.http.Header;
import org.json.JSONObject;

/**
 * Created by Dawei on 8/1/16.
 */
public abstract class JsonResponseHandler extends JsonHttpResponseHandler {

    @Override
    public void onSuccess(int statusCode, Header[] headers, JSONObject response) {
        success(response);
    }

    @Override
    public void onFailure(int statusCode, Header[] headers, String responseString, Throwable throwable) {
        failure(responseString);
        Log.e("JsonResponseHander:f", throwable.getMessage(), throwable);
    }

    public abstract void success(JSONObject jsonObject);

    public abstract void failure(String responseString);
}
