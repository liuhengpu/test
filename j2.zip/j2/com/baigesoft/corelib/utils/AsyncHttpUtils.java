package com.baigesoft.corelib.utils;

import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.AsyncHttpResponseHandler;
import com.loopj.android.http.RequestParams;

import java.util.concurrent.Executors;

/**
 * Created by Dawei on 7/28/16.
 */
public class AsyncHttpUtils {

    private static AsyncHttpClient client = null;

    private static void init(){
        if(client != null)
            return;
        client = new AsyncHttpClient();
        client.setThreadPool(Executors.newFixedThreadPool(3));
        client.setMaxConnections(5);
        client.setConnectTimeout(3000);
        client.setResponseTimeout(3000);
    }

    /**
     * Get获取网络内容
     * @param url
     * @param responseHandler
     */
    public static void get(String url, AsyncHttpResponseHandler responseHandler){
        get(url, null, responseHandler);
    }

    /**
     * Get获取网络内容
     * @param url
     * @param params
     * @param responseHandler
     */
    public static void get(String url, RequestParams params, AsyncHttpResponseHandler responseHandler) {
        init();
        client.get(url, params, responseHandler);
    }

    /**
     * Post提交数据
     * @param url
     * @param params
     * @param responseHandler
     */
    public static void post(String url, RequestParams params, AsyncHttpResponseHandler responseHandler) {
        init();
        client.post(url, params, responseHandler);
    }

}
