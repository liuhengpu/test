package com.baigesoft.corelib.roomdata;

import java.io.OutputStream;
import java.io.UnsupportedEncodingException;
import java.util.LinkedList;

public final class Baaca {
    public final OutputStream gvB = null;
    public final byte[] yLd;
    private final Baabba yLe;

    public Baaca(byte[] bArr) {
        this.yLd = bArr;
        this.yLe = new Baabba(bArr, 0, bArr.length);
    }

    public final void ai(int i, boolean z) {
        int i2 = 0;
        Baabba aVar = this.yLe;
        aVar.at(i, 0);
        if (z) {
            i2 = 1;
        }
        aVar.cJ(i2);
    }

    public final void b(int i, Bnb bVar) {
        Baabba aVar = this.yLe;
        if (bVar != null) {
            aVar.at(i, 2);
            byte[] toByteArray = bVar.toByteArray();
            aVar.cL(toByteArray.length);
            aVar.j(toByteArray);
        }
    }

    public final void b(int i, double d) {
        Baabba aVar = this.yLe;
        aVar.at(i, 1);
        long doubleToLongBits = Double.doubleToLongBits(d);
        aVar.cJ(((int) doubleToLongBits) & 255);
        aVar.cJ(((int) (doubleToLongBits >> 8)) & 255);
        aVar.cJ(((int) (doubleToLongBits >> 16)) & 255);
        aVar.cJ(((int) (doubleToLongBits >> 24)) & 255);
        aVar.cJ(((int) (doubleToLongBits >> 32)) & 255);
        aVar.cJ(((int) (doubleToLongBits >> 40)) & 255);
        aVar.cJ(((int) (doubleToLongBits >> 48)) & 255);
        aVar.cJ(((int) (doubleToLongBits >> 56)) & 255);
    }

    public final void n(int i, float f) {
        Baabba aVar = this.yLe;
        aVar.at(i, 5);
        int floatToIntBits = Float.floatToIntBits(f);
        aVar.cJ(floatToIntBits & 255);
        aVar.cJ((floatToIntBits >> 8) & 255);
        aVar.cJ((floatToIntBits >> 16) & 255);
        aVar.cJ((floatToIntBits >> 24) & 255);
    }

    public final void fn(int i, int i2) {
        Baabba aVar = this.yLe;
        aVar.at(i, 0);
        if (i2 >= 0) {
            aVar.cL(i2);
        } else {
            aVar.q((long) i2);
        }
    }

    public final void fo(int i, int i2) {
        fn(i, i2);
    }

    public final void T(int i, long j) {
        Baabba aVar = this.yLe;
        aVar.at(i, 0);
        aVar.q(j);
    }

    public final void e(int i, String str) {
        Baabba aVar = this.yLe;
        if (str != null) {
            aVar.at(i, 2);
            byte[] bytes = new byte[0];
            try {
                bytes = str.getBytes("UTF-8");
            } catch (UnsupportedEncodingException e) {
                e.printStackTrace();
            }
            aVar.cL(bytes.length);
            aVar.j(bytes);
        }
    }

    public final void fp(int i, int i2) {
        Baabba aVar = this.yLe;
        aVar.at(i, 2);
        aVar.cL(i2);
    }

    public final void d(int i, int i2, LinkedList<?> linkedList) {
        if (linkedList != null) {
            int i3;
            switch (i2) {
                case 1:
                    for (i3 = 0; i3 < linkedList.size(); i3++) {
                        e(i, (String) linkedList.get(i3));
                    }
                    return;
                case 2:
                    for (i3 = 0; i3 < linkedList.size(); i3++) {
                        fn(i, ((Integer) linkedList.get(i3)).intValue());
                    }
                    return;
                case 3:
                    for (i3 = 0; i3 < linkedList.size(); i3++) {
                        T(i, ((Long) linkedList.get(i3)).longValue());
                    }
                    return;
                case 4:
                    for (i3 = 0; i3 < linkedList.size(); i3++) {
                        b(i, ((Double) linkedList.get(i3)).doubleValue());
                    }
                    return;
                case 5:
                    for (i3 = 0; i3 < linkedList.size(); i3++) {
                        n(i, ((Float) linkedList.get(i3)).floatValue());
                    }
                    return;
                case 6:
                    for (i3 = 0; i3 < linkedList.size(); i3++) {
                        b(i, (Bnb) linkedList.get(i3));
                    }
                    return;
                case 7:
                    for (i3 = 0; i3 < linkedList.size(); i3++) {
                        ai(i, ((Boolean) linkedList.get(i3)).booleanValue());
                    }
                    return;
                case 8:
                    for (i3 = 0; i3 < linkedList.size(); i3++) {
                        Bna aVar = (Bna) linkedList.get(i3);
                        fp(i, aVar.baC());
                        aVar.a(this);
                    }
                    return;
                default:
                    throw new IllegalArgumentException("The data type was not found, the id used was " + i2);
            }
        }
    }

    public final void c(int i, LinkedList<?> linkedList) {
        int i2 = 0;
        if (linkedList != null && linkedList.size() > 0) {
            int i3;
            this.yLe.at(i, 2);
            Baabba aVar = this.yLe;
            if (linkedList == null || linkedList.size() <= 0) {
                i3 = 0;
            } else {
                i3 = 0;
                int i4 = 0;
                while (i4 < linkedList.size()) {
                    int cM = Baabba.cM(((Integer) linkedList.get(i4)).intValue()) + i3;
                    i4++;
                    i3 = cM;
                }
            }
            aVar.cL(i3);
            while (i2 < linkedList.size()) {
                this.yLe.cL(((Integer) linkedList.get(i2)).intValue());
                i2++;
            }
        }
    }
}