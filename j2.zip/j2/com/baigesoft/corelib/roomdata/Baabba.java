package com.baigesoft.corelib.roomdata;

import java.io.UnsupportedEncodingException;

public final class Baabba {
    public static final int S_IWUSR = 128;
    private final int aCN;
    private final byte[] buffer;
    private int position = 0;

    public Baabba(byte[] bArr, int i, int i2) {
        this.buffer = bArr;
        this.aCN = i2 + 0;
    }

    public static int f(int i, String str) {
        if (str == null) {
            return 0;
        }
        try {
            byte[] bytes = str.getBytes("UTF-8");
            return bytes.length + (cK(i) + cM(bytes.length));
        } catch (UnsupportedEncodingException e) {
            throw new IllegalStateException("UTF-8 not supported.");
        }
    }

    public final void cJ(int i) {
        byte b = (byte) i;
        byte[] bArr = this.buffer;
        int i2 = this.position;
        this.position = i2 + 1;
        bArr[i2] = b;
    }

    public final void j(byte[] bArr) {
        if (bArr != null) {
            int length = bArr.length;
            if (bArr == null) {
                return;
            }
            if (this.aCN - this.position >= length) {
                System.arraycopy(bArr, 0, this.buffer, this.position, length);
                this.position = length + this.position;
                return;
            }
            int i = this.aCN - this.position;
            System.arraycopy(bArr, 0, this.buffer, this.position, i);
            int i2 = i + 0;
            length -= i;
            this.position = this.aCN;
            if (length <= this.aCN) {
                System.arraycopy(bArr, i2, this.buffer, 0, length);
                this.position = length;
            }
        }
    }

    public final void at(int i, int i2) {
        cL(au(i, i2));
    }

    public static int cK(int i) {
        return cM(au(i, 0));
    }

    public final void cL(int i) {
        while ((i & -128) != 0) {
            cJ((i & 127) | S_IWUSR);
            i >>>= 7;
        }
        cJ(i);
    }

    public static int cM(int i) {
        if ((i & -128) == 0) {
            return 1;
        }
        if ((i & -16384) == 0) {
            return 2;
        }
        if ((-2097152 & i) == 0) {
            return 3;
        }
        if ((-268435456 & i) == 0) {
            return 4;
        }
        return 5;
    }

    public final void q(long j) {
        while ((-128 & j) != 0) {
            cJ((((int) j) & 127) | S_IWUSR);
            j >>>= 7;
        }
        cJ((int) j);
    }

    public static int au(int i, int i2) {
        return (i << 3) | i2;
    }
}
