package com.baigesoft.corelib.roomdata;

import java.io.IOException;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.util.LinkedList;

/**
 * Created by Dawei on 17/01/2018.
 */

public class Baabaa {

    public static final int S_IWUSR = 128;

    private int aCG = 0;
    public int aCH;
    public int aCI = 0;
    private int aCJ = Integer.MAX_VALUE;
    private int aCM = 67108864;
    public byte[] buffer;
    public int bufferSize;
    private InputStream yLb;
    private int yLc = 0;

    public final double readDouble() {
        byte nn = nn();
        byte nn2 = nn();
        return Double.longBitsToDouble(((((((((((long) nn2) & 255) << 8) | (((long) nn) & 255)) | ((((long) nn()) & 255) << 16)) | ((((long) nn()) & 255) << 24)) | ((((long) nn()) & 255) << 32)) | ((((long) nn()) & 255) << 40)) | ((((long) nn()) & 255) << 48)) | ((((long) nn()) & 255) << 56));
    }

    public final float readFloat() {
        return Float.intBitsToFloat((((nn() & 255) | ((nn() & 255) << 8)) | ((nn() & 255) << 16)) | ((nn() & 255) << 24));
    }

    public final LinkedList<byte[]> GS(int i) {
        LinkedList<byte[]> linkedList = new LinkedList();
        int nj = nj();
        try {
            byte[] obj = new byte[nj];
            System.arraycopy(this.buffer, this.aCH, obj, 0, nj);
            linkedList.add(obj);
            this.aCH = nj + this.aCH;
            nj = this.aCH;
            if (this.aCH == this.bufferSize) {
                return linkedList;
            }
            int[] GT = GT(nj);
            nj = GT[0];
            while (cO(nj) == i) {
                this.aCH = GT[1];
                nj = nj();
                obj = new byte[nj];
                System.arraycopy(this.buffer, this.aCH, obj, 0, nj);
                linkedList.add(obj);
                this.aCH = nj + this.aCH;
                if (this.aCH == this.bufferSize) {
                    break;
                }
                GT = GT(this.aCH);
                nj = GT[0];
            }
            return linkedList;
        } catch (OutOfMemoryError e) {
            throw new OutOfMemoryError("alloc bytes:" + nj);
        }
    }

    public final String readString() {
        int nj = nj();
        if (nj >= this.bufferSize - this.aCH || nj <= 0) {
            try {
                return new String(cG(nj), "UTF-8");
            } catch (UnsupportedEncodingException e) {
                e.printStackTrace();
            }
        }
        String str = null;
        try {
            str = new String(this.buffer, this.aCH, nj, "UTF-8");
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }
        this.aCH = nj + this.aCH;
        return str;
    }

    private int[] GT(int i) {
        byte b = this.buffer[i];
        int i2 = i + 1;
        if (b >= (byte) 0) {
            return new int[]{b, i2};
        }
        int i3;
        int i4 = b & 127;
        byte b2 = this.buffer[i2];
        if (b2 >= (byte) 0) {
            i3 = i2 + 1;
            i4 |= b2 << 7;
        } else {
            i4 |= (b2 & 127) << 7;
            b2 = this.buffer[i2];
            if (b2 >= (byte) 0) {
                i3 = i2 + 1;
                i4 |= b2 << 14;
            } else {
                i4 |= (b2 & 127) << 14;
                b2 = this.buffer[i2];
                if (b2 >= (byte) 0) {
                    i3 = i2 + 1;
                    i4 |= b2 << 21;
                } else {
                    i4 |= (b2 & 127) << 21;
                    b2 = this.buffer[i2];
                    i4 |= b2 << 28;
                    i3 = i2 + 1;
                    if (b2 < (byte) 0) {
                        for (i4 = 0; i4 < 5; i4++) {
                            if (this.buffer[i3] >= (byte) 0) {
                                i3++;
                                return new int[]{b2, i3};
                            }
                        }
                        throw new RuntimeException();
                    }
                }
            }
        }
        return new int[]{i4, i3};
    }

    public final int nj() {
        byte nn = nn();
        if (nn >= (byte) 0) {
            return nn;
        }
        int i = nn & 127;
        byte nn2 = nn();
        if (nn2 >= (byte) 0) {
            return i | (nn2 << 7);
        }
        i |= (nn2 & 127) << 7;
        nn2 = nn();
        if (nn2 >= (byte) 0) {
            return i | (nn2 << 14);
        }
        i |= (nn2 & 127) << 14;
        nn2 = nn();
        if (nn2 >= (byte) 0) {
            return i | (nn2 << 21);
        }
        i |= (nn2 & 127) << 21;
        nn2 = nn();
        i |= nn2 << 28;
        if (nn2 >= (byte) 0) {
            return i;
        }
        for (int i2 = 0; i2 < 5; i2++) {
            if (nn() >= (byte) 0) {
                return i;
            }
        }
        throw new RuntimeException();
    }

    public final long nk() {
        long j = 0;
        for (int i = 0; i < 64; i += 7) {
            byte nn = nn();
            j |= ((long) (nn & 127)) << i;
            if ((nn & S_IWUSR) == 0) {
                return j;
            }
        }
        throw new RuntimeException();
    }

    public Baabaa(byte[] bArr, int i) {
        this.buffer = bArr;
        this.bufferSize = i + 0;
        this.aCH = 0;
        this.yLb = null;
    }

    public final boolean nE(boolean z) {
        if (this.aCH < this.bufferSize) {
            throw new IllegalStateException("refillBuffer() called when buffer wasn't empty.");
        } else if (this.yLc + this.bufferSize != this.aCJ) {
            this.yLc += this.bufferSize;
            this.aCH = 0;
            try {
                this.bufferSize = this.yLb == null ? -1 : this.yLb.read(this.buffer);
            } catch (IOException e) {
                e.printStackTrace();
            }
            if (this.bufferSize == -1) {
                this.bufferSize = 0;
                if (!z) {
                    return false;
                }
                throw new RuntimeException();
            }
            this.bufferSize += this.aCG;
            int i = this.yLc + this.bufferSize;
            if (i > this.aCJ) {
                this.aCG = i - this.aCJ;
                this.bufferSize -= this.aCG;
            } else {
                this.aCG = 0;
            }
            i = (this.yLc + this.bufferSize) + this.aCG;
            if (i <= this.aCM && i >= 0) {
                return true;
            }
            throw new RuntimeException();
        } else if (!z) {
            return false;
        } else {
            throw new RuntimeException();
        }
    }

    private byte nn() {
        if (this.aCH == this.bufferSize) {
            nE(true);
        }
        byte[] bArr = this.buffer;
        int i = this.aCH;
        this.aCH = i + 1;
        return bArr[i];
    }

    public final byte[] cG(int i) {
        if (i < 0) {
            throw new RuntimeException();
        } else if ((this.yLc + this.aCH) + i > this.aCJ) {
            cH((this.aCJ - this.yLc) - this.aCH);
            throw new RuntimeException();
        } else if (i <= this.bufferSize - this.aCH) {
            byte[] obj = new byte[i];
            System.arraycopy(this.buffer, this.aCH, obj, 0, i);
            this.aCH += i;
            return obj;
        } else if (i < 2048) {
            byte[] obj2 = new byte[i];
            int r0 = this.bufferSize - this.aCH;
            System.arraycopy(this.buffer, this.aCH, obj2, 0, r0);
            this.aCH = this.bufferSize;
            nE(true);
            while (i - r0 > this.bufferSize) {
                System.arraycopy(this.buffer, 0, obj2, r0, this.bufferSize);
                r0 += this.bufferSize;
                this.aCH = this.bufferSize;
                nE(true);
            }
            System.arraycopy(this.buffer, 0, obj2, r0, i - r0);
            this.aCH = i - r0;
            return obj2;
        } else {
            int read = 0;
            int i2 = this.aCH;
            int i3 = this.bufferSize;
            this.yLc += this.bufferSize;
            this.aCH = 0;
            this.bufferSize = 0;
            int r0 = i - (i3 - i2);
            LinkedList linkedList = new LinkedList();
            int i4 = r0;
            while (i4 > 0) {
                byte[] obj3 = new byte[Math.min(i4, 2048)];
                r0 = 0;
                while (r0 < obj3.length) {
                    try {
                        read = this.yLb == null ? -1 : this.yLb.read(obj3, r0, obj3.length - r0);
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                    if (read == -1) {
                        throw new RuntimeException();
                    }
                    this.yLc += read;
                    r0 += read;
                }
                r0 = i4 - obj3.length;
                linkedList.add(obj3);
                i4 = r0;
            }
            byte[] obj4 = new byte[i];
            r0 = i3 - i2;
            System.arraycopy(this.buffer, i2, obj4, 0, r0);
            int i5 = r0;
            for (read = 0; read < linkedList.size(); read++) {
                byte[] bArr = (byte[]) linkedList.get(read);
                System.arraycopy(bArr, 0, obj4, i5, bArr.length);
                i5 += bArr.length;
            }
            return obj4;
        }
    }

    private void cH(int i) {
        if (i < 0) {
            throw new RuntimeException();
        } else if ((this.yLc + this.aCH) + i > this.aCJ) {
            cH((this.aCJ - this.yLc) - this.aCH);
            throw new RuntimeException();
        } else if (i < this.bufferSize - this.aCH) {
            this.aCH += i;
        } else {
            int i2 = this.bufferSize - this.aCH;
            this.yLc += i2;
            this.aCH = 0;
            this.bufferSize = 0;
            int i3 = i2;
            while (i3 < i) {
                try {
                    i2 = this.yLb == null ? -1 : (int) this.yLb.skip((long) (i - i3));
                } catch (IOException e) {
                    e.printStackTrace();
                }
                if (i2 <= 0) {
                    throw new RuntimeException();
                }
                i3 += i2;
                this.yLc = i2 + this.yLc;
            }
        }
    }

    public static int cO(int i) {
        return i >>> 3;
    }
}
