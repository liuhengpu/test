package com.baigesoft.corelib.roomdata;

/**
 * Created by Dawei on 17/01/2018.
 */

public class UnknowTagHandlerImpl implements UnknownTagHandler {
}
