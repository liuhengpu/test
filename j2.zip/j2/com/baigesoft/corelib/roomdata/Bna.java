package com.baigesoft.corelib.roomdata;

import java.io.IOException;

/**
 * Created by Dawei on 17/01/2018.
 */

public class Bna {

    protected static final int OPCODE_COMPUTESIZE = 1;
    protected static final int OPCODE_PARSEFROM = 2;
    protected static final int OPCODE_POPULATEBUILDERWITHFIELD = 3;
    protected static final int OPCODE_WRITEFIELDS = 0;
    public static UnknownTagHandler unknownTagHandler = new UnknowTagHandlerImpl();

    public Bna() {
    }

    public byte[] toByteArray() {
        baD();
        byte[] bArr = new byte[baC()];
        Baaca aVar = new Baaca(bArr);
        a(aVar);
        if (aVar.gvB != null) {
            try {
                aVar.gvB.write(aVar.yLd);
            } catch (IOException e) {
                e.printStackTrace();
            }
            try {
                aVar.gvB.flush();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        return bArr;
    }

    public static int a(Baaaa aVar) {
        int i = 0;
        Baabaa aVar2 = aVar.yKX;
        if (aVar2.aCH != aVar2.bufferSize || aVar2.nE(false)) {
            aVar2.aCI = aVar2.nj();
            if (aVar2.aCI == 0) {
                throw new RuntimeException();
            }
            i = aVar2.aCI;
        } else {
            aVar2.aCI = 0;
        }
        aVar.yKY = i;
        i = cO(aVar.yKY);
        return i;
    }

    public Bna baD() {
        return this;
    }

    public int a(int i, Object... objArr) {
        throw new Error("Cannot use this method");
    }

    public void a(Baaca aVar) {
        a(0, aVar);
    }

    public int baC() {
        int i = 0;
        try {
            i = a(1, new Object[0]);
        } catch (Exception e) {
        }
        return i;
    }

    public Bna aD(byte[] bArr) {
        a(2, bArr);
        return this;
    }

    public boolean a(Baaaa aVar, Bna aVar2, int i) {
        if (a(3, aVar, aVar2, Integer.valueOf(i)) == 0) {
            return true;
        }
        return false;
    }

    public static int cO(int i) {
        return i >>> 3;
    }
}
