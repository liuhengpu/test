package com.baigesoft.corelib.roomdata;

import java.util.LinkedList;

/**
 * Created by Dawei on 17/01/2018.
 */

public class ByteUtils extends Bna {

    public int eQm;
    public int eSJ;
    public LinkedList<Bna> memberList = new LinkedList<>();
    public int fOM;
    public String fON;
    public int fOO;
    public int status;
    public int type;

    public ByteUtils() {
    }

    @Override
    public int a(int i, Object... objArr) {
        if (i == 0) {
            Baaca aVar = (Baaca) objArr[0];
            aVar.d(1, 8, this.memberList);
            aVar.fn(2, this.eSJ);
            aVar.fn(3, this.type);
            aVar.fn(4, this.status);
            aVar.fn(5, this.fOM);
            if (this.fON != null) {
                aVar.e(6, this.fON);
            }
            aVar.fn(7, this.eQm);
            aVar.fn(8, this.fOO);
            return 0;
        } else if (i == 1) {
            int r0 = ((((Baaa.c(1, 8, this.memberList) + 0) + Baaa.fk(2, this.eSJ)) + Baaa.fk(3, this.type)) + Baaa.fk(4, this.status)) + Baaa.fk(5, this.fOM);
            if (this.fON != null) {
                r0 += Baabba.f(6, this.fON);
            }
            r0 = (r0 + Baaa.fk(7, this.eQm)) + Baaa.fk(8, this.fOO);
            return r0;
        } else if (i == 2) {
            byte[] r0 = (byte[]) objArr[0];
            this.memberList.clear();
            Baaaa aVar2 = new Baaaa(r0, unknownTagHandler);
            for (int r1 = Bna.a(aVar2); r1 > 0; r1 = Bna.a(aVar2)) {
                if (!super.a(aVar2, this, r1)) {
                    aVar2.cwC();
                }
            }
            return 0;
        } else if (i == 3) {
            Baaaa aVar3 = (Baaaa) objArr[0];
            ByteUtils aVar4 = (ByteUtils) objArr[1];
            int intValue = ((Integer) objArr[2]).intValue();
            switch (intValue) {
                case 1:
                    LinkedList GS = aVar3.GS(intValue);
                    int size = GS.size();
                    for (intValue = 0; intValue < size; intValue++) {
                        byte[] r0 = (byte[]) GS.get(intValue);
                        Bna bVar = new ByteUtilsB();
                        Baaaa aVar5 = new Baaaa(r0, unknownTagHandler);
                        for (boolean z = true; z; z = bVar.a(aVar5, bVar, Bna.a(aVar5))) {
                            System.out.println("aa");
                        }
                        aVar4.memberList.add(bVar);
                    }
                    return 0;
                case 2:
                    aVar4.eSJ = aVar3.yKX.nj();
                    return 0;
                case 3:
                    aVar4.type = aVar3.yKX.nj();
                    return 0;
                case 4:
                    aVar4.status = aVar3.yKX.nj();
                    return 0;
                case 5:
                    aVar4.fOM = aVar3.yKX.nj();
                    return 0;
                case 6:
                    aVar4.fON = aVar3.yKX.readString();
                    return 0;
                case 7:
                    aVar4.eQm = aVar3.yKX.nj();
                    return 0;
                case 8:
                    aVar4.fOO = aVar3.yKX.nj();
                    return 0;
                default:
                    return -1;
            }
        } else {
            return -1;
        }
    }

}
