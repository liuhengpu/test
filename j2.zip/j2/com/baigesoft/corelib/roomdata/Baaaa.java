package com.baigesoft.corelib.roomdata;

import java.util.LinkedList;

/**
 * Created by Dawei on 17/01/2018.
 */

public class Baaaa {

    private final UnknownTagHandler unknownTagHandler;
    public final Baabaa yKX;
    public int yKY = 0;

    public Baaaa(byte[] bArr, UnknownTagHandler bVar) {
        this.yKX = new Baabaa(bArr, bArr.length);
        this.unknownTagHandler = bVar;
    }

    public final int cwx() {
        return this.yKX.nj();
    }

    public final LinkedList<Integer> cwy() {
        Baabaa aVar = this.yKX;
        LinkedList<Integer> linkedList = new LinkedList();
        while (aVar.aCH < aVar.bufferSize) {
            linkedList.add(Integer.valueOf(aVar.nj()));
        }
        return linkedList;
    }

    public final String cwz() {
        return this.yKX.readString();
    }

    public final boolean cwA() {
        return this.yKX.nj() != 0;
    }

    public final Bnb cwB() {
        Baabaa aVar = this.yKX;
        int nj = aVar.nj();
        if (nj >= aVar.bufferSize - aVar.aCH || nj <= 0) {
            return Bnb.aX(aVar.cG(nj));
        }
        Bnb h = Bnb.h(aVar.buffer, aVar.aCH, nj);
        aVar.aCH = nj + aVar.aCH;
        return h;
    }

    public final void cwC() {
        int cN = cN(this.yKY);
        StringBuffer stringBuffer = new StringBuffer();
        stringBuffer.append("FieldNumber: ").append(cO(this.yKY)).append(" - ");
        switch (cN) {
            case 0:
                stringBuffer.append("varint (long, int or boolean) value: ").append(this.yKX.nk());
                return;
            case 1:
                stringBuffer.append("double value: ").append(Double.toString(this.yKX.readDouble()));
                return;
            case 2:
                stringBuffer.append("Length delimited (String or ByteString) value: ").append(this.yKX.readString());
                return;
            case 5:
                stringBuffer.append("float value: ").append(Float.toString(this.yKX.readFloat()));
                return;
            default:
                return;
        }
    }

    public final LinkedList<byte[]> GS(int i) {
        return this.yKX.GS(i);
    }

    public static int cN(int i) {
        return i & 7;
    }

    public static int cO(int i) {
        return i >>> 3;
    }

}
