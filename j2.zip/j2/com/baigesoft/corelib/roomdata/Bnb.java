package com.baigesoft.corelib.roomdata;

import java.io.UnsupportedEncodingException;

public final class Bnb {
    public byte[] ubG;

    public Bnb() {
    }

    public Bnb(byte[] bArr) {
        this(bArr, 0, bArr.length);
    }

    public Bnb(byte[] bArr, int i, int i2) {
        this.ubG = new byte[i2];
        System.arraycopy(bArr, i, this.ubG, 0, i2);
    }

    public static Bnb h(byte[] bArr, int i, int i2) {
        Bnb bVar = new Bnb(bArr, i, i2);
        return bVar;
    }

    public static Bnb aX(byte[] bArr) {
        if (bArr == null) {
            bArr = new byte[0];
        }
        Bnb bVar = new Bnb(bArr);
        return bVar;
    }

    public static Bnb RJ(String str) {
        try {
            Bnb bVar = new Bnb();
            bVar.ubG = str.getBytes("UTF-8");
            return bVar;
        } catch (Throwable e) {
            throw new RuntimeException("UTF-8 not supported?", e);
        }
    }

    public final Bnb Aj(int i) {
        byte[] obj = new byte[i];
        if (this.ubG.length >= i) {
            System.arraycopy(this.ubG, 0, obj, 0, i - 1);
            this.ubG = obj;
        } else {
            System.arraycopy(this.ubG, 0, obj, 0, this.ubG.length);
            this.ubG = obj;
        }
        return this;
    }

    public final byte[] toByteArray() {
        int length = this.ubG.length;
        byte[] obj = new byte[length];
        System.arraycopy(this.ubG, 0, obj, 0, length);
        return obj;
    }

    public final String bRu() {
        int i = 0;
        while (i < this.ubG.length) {
            try {
                if (this.ubG[i] == (byte) 0) {
                    break;
                }
                i++;
            } catch (Exception e) {
                throw new RuntimeException("UTF-8 not supported?");
            }
        }
        String str = null;
        try {
            str = new String(this.ubG, 0, i, "UTF-8");
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }
        return str;
    }
}