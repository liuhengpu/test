package com.baigesoft.corelib.roomdata;


public final class ByteUtilsB extends ByteUtils {
    public String chatNick;
    public int fOQ;
    public String fOR;
    public String userName;

    public ByteUtilsB() {
    }

    public final int a(int i, Object... objArr) {
        if (i == 0) {
            Baaca aVar = (Baaca) objArr[0];
            if (this.userName != null) {
                aVar.e(1, this.userName);
            }
            if (this.chatNick != null) {
                aVar.e(2, this.chatNick);
            }
            aVar.fn(3, this.fOQ);
            if (this.fOR != null) {
                aVar.e(4, this.fOR);
            }
            return 0;
        } else if (i == 1) {
            int r0;
            if (this.userName != null) {
                r0 = Baabba.f(1, this.userName) + 0;
            } else {
                r0 = 0;
            }
            if (this.chatNick != null) {
                r0 += Baabba.f(2, this.chatNick);
            }
            r0 += Baaa.fk(3, this.fOQ);
            if (this.fOR != null) {
                r0 += Baabba.f(4, this.fOR);
            }
            return r0;
        } else if (i == 2) {
            Baaaa aVar2 = new Baaaa((byte[]) objArr[0], unknownTagHandler);
            for (int r0 = ByteUtils.a(aVar2); r0 > 0; r0 = ByteUtils.a(aVar2)) {
                if (!super.a(aVar2, this, r0)) {
                    aVar2.cwC();
                }
            }
            return 0;
        } else if (i == 3) {
            Baaaa aVar3 = (Baaaa) objArr[0];
            ByteUtilsB bVar = (ByteUtilsB) objArr[1];
            switch (((Integer) objArr[2]).intValue()) {
                case 1:
                    bVar.userName = aVar3.yKX.readString();
                    return 0;
                case 2:
                    bVar.chatNick = aVar3.yKX.readString();
                    return 0;
                case 3:
                    bVar.fOQ = aVar3.yKX.nj();
                    return 0;
                case 4:
                    bVar.fOR = aVar3.yKX.readString();
                    return 0;
                default:
                    return -1;
            }
        } else {
            return -1;
        }
    }

    @Override
    public String toString() {
        return "ByteUtilsB{" +
                "chatNick='" + chatNick + '\'' +
                ", fOQ=" + fOQ +
                ", fOR='" + fOR + '\'' +
                ", userName='" + userName + '\'' +
                '}';
    }
}