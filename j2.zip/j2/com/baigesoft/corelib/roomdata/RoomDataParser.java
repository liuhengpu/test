package com.baigesoft.corelib.roomdata;

import com.baigesoft.corelib.model.RoomData;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Dawei on 17/01/2018.
 */

public class RoomDataParser {

    public static final String TAG = "Plugin_RoomDataParser";

    private byte[] bytes = null;

    public RoomDataParser(byte[] bytes) {
        this.bytes = bytes;
    }

    public List<RoomData> parse(){
        List<RoomData> roomDataList = new ArrayList<>();
        ByteUtils bu = (ByteUtils)new ByteUtils().aD(bytes);
        for(int i = 0; i < bu.memberList.size(); i++){
            ByteUtilsB bb = (ByteUtilsB)bu.memberList.get(i);
            roomDataList.add(new RoomData(bb.userName, bb.chatNick));
        }
        return roomDataList;
    }

}
