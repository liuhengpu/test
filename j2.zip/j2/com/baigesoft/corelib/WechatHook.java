package com.baigesoft.corelib;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.telephony.TelephonyManager;
import android.text.TextUtils;

import com.baigesoft.corelib.config.WechatConfig;
import com.baigesoft.corelib.db.SettingManager;
import com.baigesoft.corelib.utils.FileUtils;
import com.baigesoft.corelib.utils.LogUtils;
import com.baigesoft.corelib.wechat.ReceiveMessage;

import java.io.File;
import java.util.Random;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

import static android.content.Context.TELEPHONY_SERVICE;

/**
 * Created by Dawei on 05/09/2017.
 */

public class WechatHook implements IXposedHookLoadPackage {

    private static final String TAG = "Plugin_WechatHook";

    public static Context context;

    /**
     * 微信版本
     */
    public static String version;

    public WechatHook(Context _context, String version) {
        context = _context;
        this.version = version;
        WechatConfig.loadConfig(version);
    }

    public void handleLoadPackage(final XC_LoadPackage.LoadPackageParam packageParam) throws Throwable {

        if (packageParam.processName.equals("com.tencent.mm")) {
            initSn();
            initSettings();
        }

        //摇一摇
        XposedBridge.hookAllMethods(XposedHelpers.findClass("android.hardware.SystemSensorManager$SensorEventQueue", packageParam.classLoader), "dispatchSensorEvent", new XC_MethodHook() {
            protected void beforeHookedMethod(MethodHookParam param) throws Throwable {
                if (Constants.isShake) {
                    ((float[]) param.args[1])[0] = (new Random().nextFloat() * 1200.0f) + 125.0f;
                    Constants.isShake = false;
                }
            }
        });

        LogUtils.log(TAG, "进行WechatHook");

        //隐藏xposed及自身
        try {
            new HiddenModule().handleLoadPackage(packageParam);
        } catch (Exception ex) {
            LogUtils.log(TAG, "[HOOK微信]执行隐藏出错");
            ex.printStackTrace();
        }

        try {
            //Hook消息
            ReceiveMessage.hook(packageParam, context);
        } catch (Exception ex) {
            LogUtils.log(TAG, "[HOOK微信]Hook消息出错：" + ex.getMessage());
            ex.printStackTrace();
        }
    }

    /**
     * 获取imei
     */
    @SuppressLint("MissingPermission")
    private void initSn() {
        TelephonyManager telephonyManager = (TelephonyManager) context.getSystemService(TELEPHONY_SERVICE);
        Constants.SN = telephonyManager.getDeviceId();
        LogUtils.log(TAG, "设备号码: " + Constants.SN);
    }

    /**
     * 初始化配置
     */
    private void initSettings() {
        SettingManager settingManager = new SettingManager();
        settingManager.initAccount();
        if (Constants.ACCOUNT == null) {
            LogUtils.log(TAG, "未找到可用微信账号");
        } else {
            LogUtils.log(TAG, "载入账号：" + Constants.ACCOUNT.getUsername());
        }

        settingManager.initKeywordReply();
        LogUtils.log(TAG, "载入" + Constants.KEYWORD_REPLY.size() + "条关键词回复");

        settingManager.initSetting();
        settingManager.initRandomTalk();
        settingManager.initTulingFilter();
    }


    /**
     * 发送消息
     * ok
     * @param intent
     */
    public static void sendBroadcast(Intent intent) {
        if (context == null) {
            return;
        }
        context.sendBroadcast(intent);
    }

    public static String getSn() {
        if (!TextUtils.isEmpty(Constants.SN)) {
            return Constants.SN;
        }
        File snFile = new File("/sdcard/baigesoft/sn");
        if (!snFile.exists()) {
            LogUtils.log(TAG, "未能加载SN, 配置文件不存在！");
            return "";
        }
        Constants.SN = FileUtils.readFile(snFile);
        return Constants.SN;
    }


}
