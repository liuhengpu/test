package com.baigesoft.corelib;

/**
 * Created by Dawei on 22/05/2017.
 */

public class CommandActions {

    public static final String TYPE = "type";

    /**
     * 发送文本消息
     */
    public static final int SEND_MESSAGE = 1;

    /**
     * 发送图片消息
     */
    public static final int SEND_IMAGE = 2;

    /**
     * 发送语音消息
     */
    public static final int SEND_VOICE = 3;

    /**
     * 发送视频消息
     */
    public static final int SEND_VIDEO = 4;

    /**
     * 发送链接消息
     */
    public static final int SEND_URL = 5;

    /**
     * 给好友打标签
     */
    public static final int LABEL_FRIEND = 6;

    /**
     * 同步微信用户信息
     */
    public static final int SYNC_USER = 7;

    /**
     * 摇一摇
     */
    public static final int SHAKE = 8;

    /**
     * 加好友
     */
    public static final int ADD_FRIEND = 9;

    /**
     * 重新载入配置
     */
    public static final int RELOAD_SETTINGS = 10;

    /**
     * 同步微信群信息
     */
    public static final int CHATROOM_SYNC = 11;

    /**
     * 自动建群
     */
    public static final int CHATROOM_AUTO_CREATE = 12;

    /**
     * 拉人进群
     */
    public static final int CHATROOM_PULL_FRIEND = 13;

    /**
     * 从群中踢人
     */
    public static final int CHATROOM_DELETE_MEMBER = 14;

    /**
     * 修改群名称
     */
    public static final int CHATROOM_CHANGE_NAME = 15;

    /**
     * 修改群公告
     */
    public static final int CHATROOM_CHANGE_NOTICE = 16;

    /**
     * 将群保存到通讯录
     */
    public static final int CHATROOM_SAVE_TO_CONTACT = 17;

    /**
     * 修改群昵称
     */
    public static final int CHATROOM_CHANGE_NICK_NAME = 18;

    /**
     * 向微信群发送消息
     */
    public static final int CHATOOM_SEND_MSG = 19;

    /**
     * 给指定的人建群
     */
    public static final int CHATROOM_CREATE = 20;

    /**
     * 删除好友
     */
    public static final int DELETE_FRIEND = 21;

    /**
     * 退群
     */
    public static final int CHATROOM_QUIT = 22;

    /**
     * 发送小程序
     */
    public static final int SEND_SMALLAPP = 23;

    /**
     * 向好友群发消息
     */
    public static final int CONTACT_BATCH_SEND_MSG = 24;

    /**
     * 测试
     */
    public static final int TEST = 999;


}
