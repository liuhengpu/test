package com.baigesoft.corelib;

/**
 * Created by Dawei on 22/02/2018.
 */

public class VersionCode {

    public static final String V6523 = "6.5.23";

    public static final String V663 = "6.6.3";

    public static final String V665 = "6.6.5";

    public static final String V666 = "6.6.6";

    public static final String V667 = "6.6.7";

    public static final String V672 = "6.7.2";

    public static final String V673 = "6.7.3";

    public static final String V700 = "7.0.0";

    public static final String V703 = "7.0.3";

}
