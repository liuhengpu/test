package com.baigesoft.corelib;

import android.os.CountDownTimer;
import android.text.TextUtils;

import com.baigesoft.corelib.model.WechatMessage;
import com.baigesoft.corelib.model.WechatMessageType;
import com.baigesoft.corelib.model.WechatUser;
import com.baigesoft.corelib.utils.LogUtils;
import com.baigesoft.corelib.utils.MessageUtils;
import com.baigesoft.corelib.utils.ThreadUtils;
import com.baigesoft.corelib.wechat.SendImage;
import com.baigesoft.corelib.wechat.SendMessage;
import com.baigesoft.corelib.wechat.SendSmallApp;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import de.robv.android.xposed.callbacks.XC_LoadPackage;

public class NewFriendReply {

    private static final String TAG = "Plugin_NewFriendReply";

    private XC_LoadPackage.LoadPackageParam packageParam;

    private WechatUser wechatUser;

    public NewFriendReply(XC_LoadPackage.LoadPackageParam packageParam, WechatUser wechatUser) {
        this.packageParam = packageParam;
        this.wechatUser = wechatUser;
    }

    /**
     * 新好友自动消息
     *
     * @param talker
     * @param send_type 1为对方主动添加；2为主动添加对方
     * @param nickName
     * @param friendImg
     */
    public void reply(String talker, int send_type, String nickName, String friendImg) {
        //发送自动消息
        if (Constants.ACCOUNT == null
                || Constants.ACCOUNT.getReplys() == null
                || Constants.ACCOUNT.getReplys().length() <= 0) {
            return;
        }

        List<JSONObject> replyArray = new ArrayList<>();
        for (int i = 0; i < Constants.ACCOUNT.getReplys().length(); i++) {
            JSONObject replyObject = Constants.ACCOUNT.getReplys().optJSONObject(i);
            if (replyObject == null) {
                continue;
            }
            String content = replyObject.optString("content", "");
            int type = replyObject.optInt("type", 0);
            int reply_send_type = replyObject.optInt("send_type", 0);
            if (type <= 0 || TextUtils.isEmpty(content)) {
                continue;
            }

            if (send_type == 1) {
                if (reply_send_type == 2) {
                    continue;
                }
            } else if (send_type == 2) {
                if (reply_send_type == 1) {
                    continue;
                }
            }

            replyArray.add(replyObject);
        }

        if (Constants.ACCOUNT != null && Constants.ACCOUNT.getReply_delay() == 1) {
            //一分钟后发送自动招呼
            new NewFriendReplyCountDownTimer((replyArray.size() + 1 + 20) * 3000, 3000, replyArray, talker, true, wechatUser, nickName, friendImg).start();
        } else {
            new NewFriendReplyCountDownTimer((replyArray.size() + 1) * 3000, 3000, replyArray, talker, false, wechatUser, nickName, friendImg).start();
        }
    }

    /**
     * 新好友自动回复
     */
    class NewFriendReplyCountDownTimer extends CountDownTimer {

        private List<JSONObject> replyList;
        private int index = 0;
        private String talker;
        private int i = 0;
        private boolean delay = false;

        private WechatUser wechatUser;
        private String nickName;
        private String friendImg;

        public NewFriendReplyCountDownTimer(long millisInFuture, long countDownInterval, List<JSONObject> replyList, String talker, boolean delay,
                                            WechatUser wechatUser, String nickName, String friendImg) {
            super(millisInFuture, countDownInterval);
            this.replyList = replyList;
            this.talker = talker;
            this.delay = delay;

            this.wechatUser = wechatUser;
            this.nickName = nickName;
            this.friendImg = friendImg;
        }

        @Override
        public void onTick(long millisUntilFinished) {
            if (delay) {
                i++;
                if (i <= 20) {
                    return;
                }
            }

            if (index >= replyList.size()) {
                return;
            }

            JSONObject replyObject = replyList.get(index);
            String content = replyObject.optString("content", "");
            int type = replyObject.optInt("type", 0);

            if (type == 1) {        //回复文本
                ThreadUtils.runOnWorkerThreadDelayed(1, TimeUnit.SECONDS, new SendMessage(packageParam, talker, content));
                addMessage(content);
            } else if (type == 2) {     //回复图片
                File imageFile = new File(content);
                if (imageFile.exists()) {
                    ThreadUtils.runOnWorkerThreadDelayed(1, TimeUnit.SECONDS, new SendImage(packageParam, talker, content));
                }
            } else if (type == 3) {     //回复小程序
                JSONObject jsonObject = null;
                try {
                    jsonObject = new JSONObject(content);
                } catch (JSONException ex) {
                    LogUtils.log(TAG, "解析json失败");
                }
                if (jsonObject != null) {
                    String title = jsonObject.optString("title", "");
                    String name = jsonObject.optString("name", "");
                    String img = jsonObject.optString("img", "");
                    String path = jsonObject.optString("page", "");
                    String appid = jsonObject.optString("appid", "");
                    String gh = jsonObject.optString("gh", "");
                    ThreadUtils.runOnWorkerThreadDelayed(2, TimeUnit.SECONDS, new SendSmallApp(packageParam.classLoader, talker,
                            title, img, gh, appid, name, path));
                }
            }
            index++;
        }

        private void addMessage(String content) {
            if (wechatUser == null) {
                return;
            }
            WechatMessage replyMessage = new WechatMessage(WechatMessageType.TEXT);
            replyMessage.setSourceWeixinId(wechatUser.weixinId);
            replyMessage.setSourceMobile(wechatUser.mobile);
            replyMessage.setSourceTalker(wechatUser.talkerId);
            replyMessage.setTalker(talker);
            replyMessage.setNick(nickName);
            replyMessage.setFriendImg(friendImg);
            replyMessage.setCreateTime(System.currentTimeMillis());
            replyMessage.setStatus(0);
            replyMessage.setSend(true);
            replyMessage.setMsgId(0L);
            replyMessage.setMsgSvrId(0L);
            replyMessage.setContent(content);
            MessageUtils.addMessage(replyMessage, true);
        }

        @Override
        public void onFinish() {
            LogUtils.log(TAG, "给新好友「" + talker + "」发送了" + replyList.size() + "条消息");
        }
    }

}
