package com.baigesoft.corelib.config;

/**
 * Created by Dawei on 22/05/2017.
 */

public class WechatConfig6660 extends WechatConfig {

    public WechatConfig6660() {

        //消息、图片、语音、视频消息发送类
        CLASS_SEND_MODEL = "com.tencent.mm.z.au";

        //获取文本、图片消息发送者对象From[CLASS_SEND_MODEL]
        METHOD_SEND_MODEL_GET_MESSAGE_SENDER = "Dv";

        //消息发送者发送方法
        METHOD_SENDER_SEND = "d";

        //消息对象类
        CLASS_SEND_MESSAGE_MODEL_MULTI = "com.tencent.mm.modelmulti.i";

        //图片消息对象类
        CLASS_SEND_IMAGE_MODEL_MULTI = "com.tencent.mm.am.l";

        //获取语音、视频消息发送者对象
        METHOD_SEND_MODEL_GET_VOICE_SENDER = "Ec";

        //语音文件生成类
        CLASS_VOICE_CREATE = "com.tencent.mm.modelvoice.m";

        //
        CLASS_VOICE_FILE_CREATE = "com.tencent.mm.modelvoice.q";

        //语音文件名生成
        METHOD_VOICE_FILE_CREATE_NAME = "nR";

        //语音文件路径生成
        METHOD_VOICE_FILE_CREATE_PATH = "getFullPath";

        //生成语音文件时长
        METHOD_VOICE_FILE_LENGTH = "W";

        //传送语音文件到微信
        METHOD_VOICE_TRANSFER = "TI";

        //语音、视频发送者发送方法
        METHOD_SENDER_SEND_VOICE_VIDEO = "H";

        //获取source类
        CLASS_SOURCE_MODEL = "com.tencent.mm.z.q";

        //source类中获取source的方法名
        METHOD_SOURCE_MODEL_GET = "GC";

        //创建发送的视频文件类
        CLASS_CREATE_VIDEO_FILE = "com.tencent.mm.modelvideo.s";

        //创建发送的视频文件名
        METHOD_CREATE_VIDEO_FILE_NAME = "no";

        //创建发送的视频文件路径
        METHOD_CREATE_VIDEO_FILE_MP4 = "np";

        //创建发送的视频封面路径
        METHOD_CREATE_VIDEO_FILE_THUMBNAIL = "nq";

        //创建视频文件
        CLASS_CREATE_VIDEO = "com.tencent.mm.modelvideo.t";
        METHOD_CREATE_VIDEO_D = "a";
        METHOD_CREATE_VIDEO_F = "l";
        METHOD_CREATE_VIDEO_LT = "nw";


        METHOD_GET_TOOL = "HR";
        METHOD_GET_TOOL2 = "FO";
        FIELD_GET_QUERY_OBJECT = "fOK";

        CLASS_ABOUNT = "com.tencent.mm.z.q";
        METHOD_ABOUT_GET_WEIXIN_NUMBER = "GD";
        METHOD_ABOUT_GET_TALKER = "GC";
        METHOD_ABOUT_GET_NICK_NAME = "GE";

        //添加好友
        CLASS_PLUGINSDK_MODEL_M = "com.tencent.mm.pluginsdk.model.m";

        //Hook微信消息
        CLASS_RECEIVE_MESSAGE = "com.tencent.mm.bu.h";

        //获取目录
        CLASS_KERNEL_PATH = "com.tencent.mm.kernel.g";
        METHDO_KERNEL_GET_CACHE_PATH_OBJECT = "DY";
        FIELD_GET_CACHE_PATH = "fVo";

        //下载图片
        CLASS_IMG_SERVICE = "com.tencent.mm.am.o";
        METHOD_GET_STORE_OBJECT = "OZ";
        METHOD_GET_HD_DOWNLOAD_STATE = "bm";
        FIELD_HD_STATE = "fnK";
        FIELD_IMAGE_ID = "gDu";
        METHOD_GET_HD_IMAGE_LOGIC = "Pb";
        METHOD_GET_DOWNLOAD_IMAGE_SERVICE = "Pa";
        METHOD_DOWNLOAD_HD_TASK = "a";

        //下载小视频
        CLASS_DOWNLOAD_VIDEO = "com.tencent.mm.modelvideo.d";

        //建标签
        CLASS_LABEL_VAR = "com.tencent.mm.plugin.label.b.a";

        //打标签
        CLASS_GET_LABELID_OBJECT = "com.tencent.mm.plugin.label.e";
        METHOD_GET_LABELID_OBJECT = "aYt";
        METHOD_GET_LABELID = "ac";
        CLASS_JOIN_LABELID = "com.tencent.mm.plugin.label.c";
        METHOD_JOIN_LABELID = "be";
        CLASS_LABEL_OBJECT = "com.tencent.mm.protocal.c.bhf";
        FIELD_LABEL_OBJECT_LABEL = "xoP";
        FIELD_LABEL_OBJECT_USERNAME = "wsp";
        CLASS_MODITY_LABEL = "com.tencent.mm.plugin.label.b.d";

        //数据库操作com.tencent.mm.sdk.e.e
        DB_RAW_QUERY = "rawQuery";
        DB_RAW_INSERT = "insert";
        DB_RAW_DELETE = "delete";
        DB_RAW_EXECUTE = "fM";

        //采集好友-附近的人
        CLASS_NEARBY_BY = "com.tencent.mm.plugin.nearby.a.c";
        METHOD_NEARBY_BY = "biM";
        FIELD_NEARBY_TALKER_ID = "kkh";
        FIELD_NEARBY_NICKNAME = "kja";
        FIELD_NEARBY_LAT = "hHn";
        FIELD_NEARBY_LNG = "hHo";
        FIELD_NEARBY_SIGNATURE = "hHp";
        FIELD_NEARBY_SEX = "hHm";
        FIELD_NEARBY_HEAD_IMAGE = "wxW";

        //自动通过好友
        CLASS_THROUGH_OBJECT = "com.tencent.mm.pluginsdk.model.m";

        //发送链接
        CLASS_URL_IMAGE = "com.tencent.mm.am.c";
        METHOD_URL_IMAGE_PUSH = "h";
        CLASS_WEBPAGE_OBJECT = "com.tencent.mm.opensdk.modelmsg.WXWebpageObject";
        FIELD_WEBPAGE_URL = "webpageUrl";
        CLASS_MEDIA_MESSAGE = "com.tencent.mm.opensdk.modelmsg.WXMediaMessage";
        FIELD_MEDIA_MESSAGE_MEDIA_OBJECT = "mediaObject";
        FIELD_MEDIA_MESSAGE_TITLE = "title";
        FIELD_MEDIA_MESSAGE_DESCRIPTION = "description";
        FIELD_MEDIA_MESSAGE_THUMB_DATA = "thumbData";
        CLASS_URL_MESSAGE = "com.tencent.mm.g.a.oo";
        FIELD_URL_MESSAGE_MSG = "eIs";
        FIELD_URL_MESSAGE_MEDIA = "eAV";
        FIELD_URL_MESSAGE_APP_NAME = "appName";
        FIELD_URL_MESSAGE_TO_USER = "toUser";
        FIELD_URL_MESSAGE_INT = "eIt";
        FIELD_URL_MESSAGE_OWNER_TALKER = "eIu";
        FIELD_URL_MESSAGE_SNSAD = "eIB";
        FIELD_URL_MESSAGE_URL = "eIy";
        CLASS_URL_SENDER_GETTER = "com.tencent.mm.sdk.b.a";
        FIELD_URL_SENDER_GETTER_FIELD = "xJM";
        METHOD_URL_SENDER_SEND = "m";

        //群
        CHATROOM_CLASS_PULLFRIEND_ADD_MEMBER = "com.tencent.mm.plugin.chatroom.d.d";
        CHAT_ROOM_CLASS_PULLFRIEND_INVITE_MEMBER = "com.tencent.mm.plugin.chatroom.d.k";
        CHAT_ROOM_CLASS_CREATE_CHAT_ROOM = "com.tencent.mm.plugin.chatroom.d.f";
        CHAT_ROOM_CLASS_DELETE_MEMBER = "com.tencent.mm.plugin.chatroom.d.g";

        //修改群名称
        CHAT_ROOM_CLASS_MODEL_C = "com.tencent.mm.z.c";
        CHAT_ROOM_METHOD_MMCORE_INIT = "HR";
        CHAT_ROOM_METHOD_CHECK_MMCORE_INIT = "HJ";
        CHAT_ROOM_NAME_OBJECT_CLASS = "com.tencent.mm.protocal.c.bfk";
        CHAT_ROOM_NAME_OBJECT_METHOD_SET = "VJ";
        CHAT_ROOM_OBJECT_CLASS = "com.tencent.mm.protocal.c.asl";
        CHAT_ROOM_OBJECT_FIELD_TALKER = "wjl";
        CHAT_ROOM_OBJECT_FIELD_NAME = "xcz";
        CHAT_ROOM_CHANGE_NAME_OBJECT_CLASS = "com.tencent.mm.plugin.messenger.foundation.a.a.h.a";
        CHAT_ROOM_GET_FE_METHOD = "FN";
        CHAT_ROOM_CHANGE_NAME_SEND_METHOD = "b";

        //保存群到通讯录
        CHAT_ROOM_METHOD_GET_FF = "FO";
        CHAT_ROOM_METHOD_GET_XV = "Yc";
        CHAT_ROOM_CLASS_Y_S = "com.tencent.mm.z.s";
        CHAT_ROOM_METHOD_SAVE = "q";

        //修改群公告
        CHAT_ROOM_CLASS_SET_NOTICE = "com.tencent.mm.plugin.chatroom.d.m";

        //修改群昵称
        CHAT_ROOM_NICK_PROTOCOL = "com.tencent.mm.protocal.c.asi";
        CHAR_ROOM_FIELD_NICK_PROTOCOL_TALKER = "kja";
        CHAR_ROOM_FIELD_NICK_PROTOCOL_CHATROOM_TALKER = "wBL";
        CHAR_ROOM_FIELD_NICK_PROTOCOL_NICKNAME = "wxV";

        //将消息设置为已读
        MSG_READ_METHOD_Fh = "FQ";
        MSG_READ_METHOD_Fn = "GD";
        MSG_READ_CLASS_AU = "com.tencent.mm.storage.az";
        MSG_READ_METHOD_AU_B = "c";
        MSG_READ_METHOD_AU_eR = "eV";
        MSG_READ_METHOD_Fk = "FT";
        MSG_READ_METHOD_Fk_XH = "Yo";
        MSG_READ_METHOD_Fl = "GB";

    }
}
