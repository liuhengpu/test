package com.baigesoft.corelib.config;

/**
 * Created by Dawei on 22/05/2017.
 */

public class WechatConfig6720 extends WechatConfig {

    public WechatConfig6720() {

        //消息、图片、语音、视频消息发送类
        CLASS_SEND_MODEL = "com.tencent.mm.model.av";

        //获取文本、图片消息发送者对象From[CLASS_SEND_MODEL]
        METHOD_SEND_MODEL_GET_MESSAGE_SENDER = "CB";

        //消息发送者发送方法
        METHOD_SENDER_SEND = "d";

        //消息对象类
        CLASS_SEND_MESSAGE_MODEL_MULTI = "com.tencent.mm.modelmulti.h";

        //图片消息对象类
        CLASS_SEND_IMAGE_MODEL_MULTI = "com.tencent.mm.ap.l";

        //获取语音、视频消息发送者对象
        METHOD_SEND_MODEL_GET_VOICE_SENDER = "Dk";

        //语音文件生成类
        CLASS_VOICE_CREATE = "com.tencent.mm.modelvoice.m";

        //
        CLASS_VOICE_FILE_CREATE = "com.tencent.mm.modelvoice.q";

        //语音文件名生成
        METHOD_VOICE_FILE_CREATE_NAME = "oq";

        //语音文件路径生成
        METHOD_VOICE_FILE_CREATE_PATH = "getFullPath";

        //生成语音文件时长
        METHOD_VOICE_FILE_LENGTH = "X";

        //传送语音文件到微信
        METHOD_VOICE_TRANSFER = "Sz";

        //语音、视频发送者发送方法
        METHOD_SENDER_SEND_VOICE_VIDEO = "N";

        //获取source类
        CLASS_SOURCE_MODEL = "com.tencent.mm.model.q";

        //source类中获取source的方法名
        METHOD_SOURCE_MODEL_GET = "FC";

        //创建发送的视频文件类
        CLASS_CREATE_VIDEO_FILE = "com.tencent.mm.modelvideo.t";

        //创建发送的视频文件名
        METHOD_CREATE_VIDEO_FILE_NAME = "nI";

        //创建发送的视频文件路径
        METHOD_CREATE_VIDEO_FILE_MP4 = "nJ";

        //创建发送的视频封面路径
        METHOD_CREATE_VIDEO_FILE_THUMBNAIL = "nK";

        //创建视频文件
        CLASS_CREATE_VIDEO = "com.tencent.mm.modelvideo.u";
        METHOD_CREATE_VIDEO_D = "a";
        METHOD_CREATE_VIDEO_F = "k";
        METHOD_CREATE_VIDEO_LT = "nQ";


        METHOD_GET_TOOL = "GP";
        METHOD_GET_TOOL2 = "ET";
        FIELD_GET_QUERY_OBJECT = "dOC";

        CLASS_ABOUNT = CLASS_SOURCE_MODEL;
        METHOD_ABOUT_GET_WEIXIN_NUMBER = "FD";
        METHOD_ABOUT_GET_TALKER = "FC";
        METHOD_ABOUT_GET_NICK_NAME = "FE";

        //添加好友
        CLASS_PLUGINSDK_MODEL_M = "com.tencent.mm.pluginsdk.model.m";

        //Hook微信消息
        CLASS_RECEIVE_MESSAGE = "com.tencent.mm.bz.h";

        //获取目录
        CLASS_KERNEL_PATH = "com.tencent.mm.kernel.g";
        METHDO_KERNEL_GET_CACHE_PATH_OBJECT = "Dg";
        FIELD_GET_CACHE_PATH = "dBn";

        //下载图片
        CLASS_IMG_SERVICE = "com.tencent.mm.ap.o";
        METHOD_GET_STORE_OBJECT = "Oa";
        METHOD_GET_HD_DOWNLOAD_STATE = "bA";
        FIELD_HD_STATE = "cJw";
        FIELD_IMAGE_ID = "efs";
        METHOD_GET_HD_IMAGE_LOGIC = "Oc";
        METHOD_GET_DOWNLOAD_IMAGE_SERVICE = "Ob";
        METHOD_DOWNLOAD_HD_TASK = "a";

        //下载小视频
        CLASS_DOWNLOAD_VIDEO = "com.tencent.mm.modelvideo.d";

        //建标签
        CLASS_LABEL_VAR = "com.tencent.mm.plugin.label.b.a";

        //打标签
        CLASS_GET_LABELID_OBJECT = "com.tencent.mm.plugin.label.e";
        METHOD_GET_LABELID_OBJECT = "aZx";
        METHOD_GET_LABELID = "ac";
        CLASS_JOIN_LABELID = "com.tencent.mm.plugin.label.c";
        METHOD_JOIN_LABELID = "bC";
        CLASS_LABEL_OBJECT = "com.tencent.mm.protocal.c.cai";
        FIELD_LABEL_OBJECT_LABEL = "sgz";
        FIELD_LABEL_OBJECT_USERNAME = "hCW";
        CLASS_MODITY_LABEL = "com.tencent.mm.plugin.label.b.d";

        //数据库操作com.tencent.mm.sdk.e.e
        DB_RAW_QUERY = "rawQuery";
        DB_RAW_INSERT = "insert";
        DB_RAW_DELETE = "delete";
        DB_RAW_EXECUTE = "gf";

        //采集好友-附近的人
        CLASS_NEARBY_BY = "com.tencent.mm.plugin.nearby.a.c";
        METHOD_NEARBY_BY = "bke";
        FIELD_NEARBY_TALKER_ID = "hEd";
        FIELD_NEARBY_NICKNAME = "hCW";
        FIELD_NEARBY_LAT = "eXa";
        FIELD_NEARBY_LNG = "eXb";
        FIELD_NEARBY_SIGNATURE = "eXc";
        FIELD_NEARBY_SEX = "eWZ";
        FIELD_NEARBY_HEAD_IMAGE = "sch";

        //自动通过好友
        CLASS_THROUGH_OBJECT = "com.tencent.mm.pluginsdk.model.m";

        //发送链接
        CLASS_URL_IMAGE = "com.tencent.mm.ap.c";
        METHOD_URL_IMAGE_PUSH = "h";
        CLASS_WEBPAGE_OBJECT = "com.tencent.mm.opensdk.modelmsg.WXWebpageObject";
        FIELD_WEBPAGE_URL = "webpageUrl";
        CLASS_MEDIA_MESSAGE = "com.tencent.mm.opensdk.modelmsg.WXMediaMessage";
        FIELD_MEDIA_MESSAGE_MEDIA_OBJECT = "mediaObject";
        FIELD_MEDIA_MESSAGE_TITLE = "title";
        FIELD_MEDIA_MESSAGE_DESCRIPTION = "description";
        FIELD_MEDIA_MESSAGE_THUMB_DATA = "thumbData";
        CLASS_URL_MESSAGE = "com.tencent.mm.h.a.oy";
        FIELD_URL_MESSAGE_MSG = "bWr";
        FIELD_URL_MESSAGE_MEDIA = "bOM";
        FIELD_URL_MESSAGE_APP_NAME = "appName";
        FIELD_URL_MESSAGE_TO_USER = "toUser";
        FIELD_URL_MESSAGE_INT = "bWs";
        FIELD_URL_MESSAGE_OWNER_TALKER = "bWt";
        FIELD_URL_MESSAGE_SNSAD = "bWA";
        FIELD_URL_MESSAGE_URL = "bWx";
        CLASS_URL_SENDER_GETTER = "com.tencent.mm.sdk.b.a";
        FIELD_URL_SENDER_GETTER_FIELD = "tss";
        METHOD_URL_SENDER_SEND = "m";

        //群
        CHATROOM_CLASS_PULLFRIEND_ADD_MEMBER = "com.tencent.mm.chatroom.c.e";
        CHAT_ROOM_CLASS_PULLFRIEND_INVITE_MEMBER = "com.tencent.mm.chatroom.c.m";
        CHAT_ROOM_CLASS_CREATE_CHAT_ROOM = "com.tencent.mm.chatroom.c.g";
        CHAT_ROOM_CLASS_DELETE_MEMBER = "com.tencent.mm.chatroom.c.h";

        //修改群名称
        CHAT_ROOM_CLASS_MODEL_C = "com.tencent.mm.model.c";
        CHAT_ROOM_METHOD_MMCORE_INIT = "GP";
        CHAT_ROOM_METHOD_CHECK_MMCORE_INIT = "GH";
        CHAT_ROOM_NAME_OBJECT_CLASS = "com.tencent.mm.protocal.c.bks";
        CHAT_ROOM_NAME_OBJECT_METHOD_SET = "Xp";
        CHAT_ROOM_OBJECT_CLASS = "com.tencent.mm.protocal.c.avx";
        CHAT_ROOM_OBJECT_FIELD_TALKER = "rMh";
        CHAT_ROOM_OBJECT_FIELD_NAME = "sIW";
        CHAT_ROOM_CHANGE_NAME_OBJECT_CLASS = "com.tencent.mm.plugin.messenger.foundation.a.a.i.a";
        CHAT_ROOM_GET_FE_METHOD = "EN";
        CHAT_ROOM_CHANGE_NAME_SEND_METHOD = "b";

        //保存群到通讯录
        CHAT_ROOM_METHOD_GET_FF = "EO";
        CHAT_ROOM_METHOD_GET_XV = "ZQ";
        CHAT_ROOM_CLASS_Y_S = "com.tencent.mm.model.s";
        CHAT_ROOM_METHOD_SAVE = "r";

        //修改群公告
        CHAT_ROOM_CLASS_SET_NOTICE = "com.tencent.mm.chatroom.c.o";

        //修改群昵称
        CHAT_ROOM_NICK_PROTOCOL = "com.tencent.mm.protocal.c.avu";
        CHAR_ROOM_FIELD_NICK_PROTOCOL_TALKER = "hCW";
        CHAR_ROOM_FIELD_NICK_PROTOCOL_CHATROOM_TALKER = "rMe";
        CHAR_ROOM_FIELD_NICK_PROTOCOL_NICKNAME = "scg";

        //将消息设置为已读
        MSG_READ_METHOD_Fh = "EQ";
        MSG_READ_METHOD_Fn = "GG";
        MSG_READ_CLASS_AU = "com.tencent.mm.storage.bg";
        MSG_READ_METHOD_AU_B = "d";
        MSG_READ_METHOD_AU_eR = "setStatus";
        MSG_READ_METHOD_Fk = "ET";
        MSG_READ_METHOD_Fk_XH = "aac";
        MSG_READ_METHOD_Fl = "GE";

        //删除好友
        DELETE_FRIEND_MODEL_CLASS = "com.tencent.mm.av.b";
        DELETE_FRIEND_GA = "EX";
        DELETE_FRIEND_METHOD = "c";
        DELETE_FRIEND_CHAT_METHOD = "ZZ";
        DELETE_FRIEND_YM_METHOD = "ZW";
        DELETE_FRIEND_IN_METHOD = "io";

    }
}
