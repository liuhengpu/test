package com.baigesoft.corelib.config;

/**
 * Created by Dawei on 22/05/2017.
 */

public class WechatConfig6523 extends WechatConfig {

    public WechatConfig6523() {

        //*消息、图片、语音、视频消息发送类
        CLASS_SEND_MODEL = "com.tencent.mm.y.at";

        //*获取文本、图片消息发送者对象From[CLASS_SEND_MODEL]
        METHOD_SEND_MODEL_GET_MESSAGE_SENDER = "wY";

        //*消息发送者发送方法
        METHOD_SENDER_SEND = "d";

        //*消息对象类
        CLASS_SEND_MESSAGE_MODEL_MULTI = "com.tencent.mm.modelmulti.j";

        //*图片消息对象类
        CLASS_SEND_IMAGE_MODEL_MULTI = "com.tencent.mm.ao.k";

        //*获取语音、视频消息发送者对象
        METHOD_SEND_MODEL_GET_VOICE_SENDER = "xH";

        //*语音文件生成类
        CLASS_VOICE_CREATE = "com.tencent.mm.modelvoice.m";

        CLASS_VOICE_FILE_CREATE = "com.tencent.mm.modelvoice.q"; //*

        //*语音文件名生成
        METHOD_VOICE_FILE_CREATE_NAME = "mY";

        //*语音文件路径生成
        METHOD_VOICE_FILE_CREATE_PATH = "getFullPath";

        //*生成语音文件时长
        METHOD_VOICE_FILE_LENGTH = "j";

        //*传送语音文件到微信
        METHOD_VOICE_TRANSFER = "NZ";

        //*语音、视频发送者发送方法
        METHOD_SENDER_SEND_VOICE_VIDEO = "E";

        //*获取source类
        CLASS_SOURCE_MODEL = "com.tencent.mm.y.q";

        //*source类中获取source的方法名
        METHOD_SOURCE_MODEL_GET = "zK";

        //*创建发送的视频文件类
        CLASS_CREATE_VIDEO_FILE = "com.tencent.mm.modelvideo.s";

        //*创建发送的视频文件名
        METHOD_CREATE_VIDEO_FILE_NAME = "mv";

        //*创建发送的视频文件路径
        METHOD_CREATE_VIDEO_FILE_MP4 = "mw";

        //*创建发送的视频封面路径
        METHOD_CREATE_VIDEO_FILE_THUMBNAIL = "mx";

        //*创建视频文件
        CLASS_CREATE_VIDEO = "com.tencent.mm.modelvideo.t";  //*
        METHOD_CREATE_VIDEO_D = "a"; //*
        METHOD_CREATE_VIDEO_F = "i"; //*
        METHOD_CREATE_VIDEO_LT = "mD"; //*


        METHOD_GET_TOOL = "AX";  //*
        METHOD_GET_TOOL2 = "yQ"; //*
        FIELD_GET_QUERY_OBJECT = "fWy";  //*

        CLASS_ABOUNT = "com.tencent.mm.y.q"; //*
        METHOD_ABOUT_GET_WEIXIN_NUMBER = "zL";   //*
        METHOD_ABOUT_GET_TALKER = "zK";  //*
        METHOD_ABOUT_GET_NICK_NAME = "zM";   //*

        //*添加好友
        CLASS_PLUGINSDK_MODEL_M = "com.tencent.mm.pluginsdk.model.n";    //*

        //*Hook微信消息
        CLASS_RECEIVE_MESSAGE = "com.tencent.mm.bv.g";

        //*获取目录
        CLASS_KERNEL_PATH = "com.tencent.mm.kernel.h";
        METHDO_KERNEL_GET_CACHE_PATH_OBJECT = "xE";
        FIELD_GET_CACHE_PATH = "gbt";

        //下载图片
        CLASS_IMG_SERVICE = "com.tencent.mm.ao.n";   //*
        METHOD_GET_STORE_OBJECT = "Jf";  //*
        METHOD_GET_HD_DOWNLOAD_STATE = "ar"; //*
        FIELD_HD_STATE = "fyK";  //*
        FIELD_IMAGE_ID = "gJr";  //*
        METHOD_GET_HD_IMAGE_LOGIC = "Jh";    //*
        METHOD_GET_DOWNLOAD_IMAGE_SERVICE = "Jg";    //*
        METHOD_DOWNLOAD_HD_TASK = "a";   //*

        //*下载小视频
        CLASS_DOWNLOAD_VIDEO = "com.tencent.mm.modelvideo.d";

        //*建标签
        CLASS_LABEL_VAR = "com.tencent.mm.plugin.label.b.a"; //*

        //*打标签
        CLASS_GET_LABELID_OBJECT = "com.tencent.mm.plugin.label.e";  //*
        METHOD_GET_LABELID_OBJECT = "aLU";   //*
        METHOD_GET_LABELID = "ag";   //*
        CLASS_JOIN_LABELID = "com.tencent.mm.plugin.label.c";    //*
        METHOD_JOIN_LABELID = "aN";  //*
        CLASS_LABEL_OBJECT = "com.tencent.mm.protocal.c.bfv";    //*
        FIELD_LABEL_OBJECT_LABEL = "eHq";    //*
        FIELD_LABEL_OBJECT_USERNAME = "mTA"; //*
        CLASS_MODITY_LABEL = "com.tencent.mm.plugin.label.b.d";  //*

        //*数据库操作com.tencent.mm.sdk.e.e
        DB_RAW_QUERY = "rawQuery";
        DB_RAW_INSERT = "insert";
        DB_RAW_DELETE = "delete";
        DB_RAW_EXECUTE = "fm";

        //*采集好友-附近的人
        CLASS_NEARBY_BY = "com.tencent.mm.plugin.nearby.a.c";
        METHOD_NEARBY_BY = "aVT";
        FIELD_NEARBY_TALKER_ID = "jwx";
        FIELD_NEARBY_NICKNAME = "jvr";
        FIELD_NEARBY_LAT = "gEY";
        FIELD_NEARBY_LNG = "gEZ";
        FIELD_NEARBY_SIGNATURE = "gFa";
        FIELD_NEARBY_SEX = "gEX";
        FIELD_NEARBY_HEAD_IMAGE = "uuk";

        //*自动通过好友
        CLASS_THROUGH_OBJECT = "com.tencent.mm.pluginsdk.model.n";

        //*发送链接
        CLASS_URL_IMAGE = "com.tencent.mm.ao.b";
        METHOD_URL_IMAGE_PUSH = "g";
        CLASS_WEBPAGE_OBJECT = "com.tencent.mm.opensdk.modelmsg.WXWebpageObject";
        FIELD_WEBPAGE_URL = "webpageUrl";
        CLASS_MEDIA_MESSAGE = "com.tencent.mm.opensdk.modelmsg.WXMediaMessage";
        FIELD_MEDIA_MESSAGE_MEDIA_OBJECT = "mediaObject";
        FIELD_MEDIA_MESSAGE_TITLE = "title";
        FIELD_MEDIA_MESSAGE_DESCRIPTION = "description";
        FIELD_MEDIA_MESSAGE_THUMB_DATA = "thumbData";
        CLASS_URL_MESSAGE = "com.tencent.mm.g.a.ok";
        FIELD_URL_MESSAGE_MSG = "eVK";
        FIELD_URL_MESSAGE_MEDIA = "eOq";
        FIELD_URL_MESSAGE_APP_NAME = "appName";
        FIELD_URL_MESSAGE_TO_USER = "toUser";
        FIELD_URL_MESSAGE_INT = "eVL";
        FIELD_URL_MESSAGE_OWNER_TALKER = "eVM";
        FIELD_URL_MESSAGE_SNSAD = "eVT";
        FIELD_URL_MESSAGE_URL = "eVQ";
        CLASS_URL_SENDER_GETTER = "com.tencent.mm.sdk.b.a";
        FIELD_URL_SENDER_GETTER_FIELD = "vzT";
        METHOD_URL_SENDER_SEND = "m";
    }
}
