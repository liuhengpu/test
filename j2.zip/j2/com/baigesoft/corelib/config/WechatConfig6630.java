package com.baigesoft.corelib.config;

/**
 * Created by Dawei on 22/05/2017.
 */

public class WechatConfig6630 extends WechatConfig {

    public WechatConfig6630() {

        //消息、图片、语音、视频消息发送类
        CLASS_SEND_MODEL = "com.tencent.mm.z.ar";

        //获取文本、图片消息发送者对象From[CLASS_SEND_MODEL]
        METHOD_SEND_MODEL_GET_MESSAGE_SENDER = "CG";

        //消息发送者发送方法
        METHOD_SENDER_SEND = "d";

        //消息对象类
        CLASS_SEND_MESSAGE_MODEL_MULTI = "com.tencent.mm.modelmulti.j";

        //图片消息对象类
        CLASS_SEND_IMAGE_MODEL_MULTI = "com.tencent.mm.aq.l";

        //获取语音、视频消息发送者对象
        METHOD_SEND_MODEL_GET_VOICE_SENDER = "Dm";

        //语音文件生成类
        CLASS_VOICE_CREATE = "com.tencent.mm.modelvoice.m";

        //
        CLASS_VOICE_FILE_CREATE = "com.tencent.mm.modelvoice.q";

        //语音文件名生成
        METHOD_VOICE_FILE_CREATE_NAME = "nV";

        //语音文件路径生成
        METHOD_VOICE_FILE_CREATE_PATH = "getFullPath";

        //生成语音文件时长
        METHOD_VOICE_FILE_LENGTH = "k";

        //传送语音文件到微信
        METHOD_VOICE_TRANSFER = "UF";

        //语音、视频发送者发送方法
        METHOD_SENDER_SEND_VOICE_VIDEO = "F";

        //获取source类
        CLASS_SOURCE_MODEL = "com.tencent.mm.z.q";

        //source类中获取source的方法名
        METHOD_SOURCE_MODEL_GET = "FS";

        //创建发送的视频文件类
        CLASS_CREATE_VIDEO_FILE = "com.tencent.mm.modelvideo.s";

        //创建发送的视频文件名
        METHOD_CREATE_VIDEO_FILE_NAME = "ns";

        //创建发送的视频文件路径
        METHOD_CREATE_VIDEO_FILE_MP4 = "nt";

        //创建发送的视频封面路径
        METHOD_CREATE_VIDEO_FILE_THUMBNAIL = "nu";

        //创建视频文件
        CLASS_CREATE_VIDEO = "com.tencent.mm.modelvideo.t";
        METHOD_CREATE_VIDEO_D = "a";
        METHOD_CREATE_VIDEO_F = "j";
        METHOD_CREATE_VIDEO_LT = "nA";


        METHOD_GET_TOOL = "Hg";
        METHOD_GET_TOOL2 = "EY";
        FIELD_GET_QUERY_OBJECT = "gJP";

        CLASS_ABOUNT = "com.tencent.mm.z.q";
        METHOD_ABOUT_GET_WEIXIN_NUMBER = "FT";
        METHOD_ABOUT_GET_TALKER = "FS";
        METHOD_ABOUT_GET_NICK_NAME = "FU";

        //添加好友
        CLASS_PLUGINSDK_MODEL_M = "com.tencent.mm.pluginsdk.model.o";

        //Hook微信消息
        CLASS_RECEIVE_MESSAGE = "com.tencent.mm.by.h";

        //获取目录
        CLASS_KERNEL_PATH = "com.tencent.mm.kernel.g";
        METHDO_KERNEL_GET_CACHE_PATH_OBJECT = "Dj";
        FIELD_GET_CACHE_PATH = "gQi";

        //下载图片
        CLASS_IMG_SERVICE = "com.tencent.mm.aq.o";
        METHOD_GET_STORE_OBJECT = "Pw";
        METHOD_GET_HD_DOWNLOAD_STATE = "bh";
        FIELD_HD_STATE = "gjK";
        FIELD_IMAGE_ID = "hzP";
        METHOD_GET_HD_IMAGE_LOGIC = "Py";
        METHOD_GET_DOWNLOAD_IMAGE_SERVICE = "Px";
        METHOD_DOWNLOAD_HD_TASK = "a";

        //下载小视频
        CLASS_DOWNLOAD_VIDEO = "com.tencent.mm.modelvideo.d";

        //建标签
        CLASS_LABEL_VAR = "com.tencent.mm.plugin.label.b.a";

        //打标签
        CLASS_GET_LABELID_OBJECT = "com.tencent.mm.plugin.label.e";
        METHOD_GET_LABELID_OBJECT = "aUW";
        METHOD_GET_LABELID = "ae";
        CLASS_JOIN_LABELID = "com.tencent.mm.plugin.label.c";
        METHOD_JOIN_LABELID = "aY";
        CLASS_LABEL_OBJECT = "com.tencent.mm.protocal.c.bff";
        FIELD_LABEL_OBJECT_LABEL = "wKo";
        FIELD_LABEL_OBJECT_USERNAME = "vPs";
        CLASS_MODITY_LABEL = "com.tencent.mm.plugin.label.b.d";

        //数据库操作com.tencent.mm.sdk.e.e
        DB_RAW_QUERY = "rawQuery";
        DB_RAW_INSERT = "insert";
        DB_RAW_DELETE = "delete";
        DB_RAW_EXECUTE = "fx";

        //采集好友-附近的人
        CLASS_NEARBY_BY = "com.tencent.mm.plugin.nearby.a.c";
        METHOD_NEARBY_BY = "beV";
        FIELD_NEARBY_TALKER_ID = "kub";
        FIELD_NEARBY_NICKNAME = "ksU";
        FIELD_NEARBY_LAT = "hvu";
        FIELD_NEARBY_LNG = "hvv";
        FIELD_NEARBY_SIGNATURE = "hvw";
        FIELD_NEARBY_SEX = "hvt";
        FIELD_NEARBY_HEAD_IMAGE = "vUU";

        //自动通过好友
        CLASS_THROUGH_OBJECT = "com.tencent.mm.pluginsdk.model.o";

        //发送链接
        CLASS_URL_IMAGE = "com.tencent.mm.aq.c";
        METHOD_URL_IMAGE_PUSH = "g";
        CLASS_WEBPAGE_OBJECT = "com.tencent.mm.opensdk.modelmsg.WXWebpageObject";
        FIELD_WEBPAGE_URL = "webpageUrl";
        CLASS_MEDIA_MESSAGE = "com.tencent.mm.opensdk.modelmsg.WXMediaMessage";
        FIELD_MEDIA_MESSAGE_MEDIA_OBJECT = "mediaObject";
        FIELD_MEDIA_MESSAGE_TITLE = "title";
        FIELD_MEDIA_MESSAGE_DESCRIPTION = "description";
        FIELD_MEDIA_MESSAGE_THUMB_DATA = "thumbData";
        CLASS_URL_MESSAGE = "com.tencent.mm.g.a.op";
        FIELD_URL_MESSAGE_MSG = "fGx";
        FIELD_URL_MESSAGE_MEDIA = "fzc";
        FIELD_URL_MESSAGE_APP_NAME = "appName";
        FIELD_URL_MESSAGE_TO_USER = "toUser";
        FIELD_URL_MESSAGE_INT = "fGy";
        FIELD_URL_MESSAGE_OWNER_TALKER = "fGz";
        FIELD_URL_MESSAGE_SNSAD = "fGG";
        FIELD_URL_MESSAGE_URL = "fGD";
        CLASS_URL_SENDER_GETTER = "com.tencent.mm.sdk.b.a";
        FIELD_URL_SENDER_GETTER_FIELD = "xef";
        METHOD_URL_SENDER_SEND = "m";
    }
}
