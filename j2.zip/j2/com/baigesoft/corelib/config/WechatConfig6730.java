package com.baigesoft.corelib.config;

/**
 * Created by Dawei on 22/05/2017.
 */

public class WechatConfig6730 extends WechatConfig {

    public WechatConfig6730() {

        //消息、图片、语音、视频消息发送类
        CLASS_SEND_MODEL = "com.tencent.mm.model.au";

        //获取文本、图片消息发送者对象From[CLASS_SEND_MODEL]
        METHOD_SEND_MODEL_GET_MESSAGE_SENDER = "Dk";

        //消息发送者发送方法
        METHOD_SENDER_SEND = "d";

        //消息对象类
        CLASS_SEND_MESSAGE_MODEL_MULTI = "com.tencent.mm.modelmulti.h";

        //图片消息对象类
        CLASS_SEND_IMAGE_MODEL_MULTI = "com.tencent.mm.as.l";

        //获取语音、视频消息发送者对象
        METHOD_SEND_MODEL_GET_VOICE_SENDER = "DS";

        //语音文件生成类
        CLASS_VOICE_CREATE = "com.tencent.mm.modelvoice.m";

        //
        CLASS_VOICE_FILE_CREATE = "com.tencent.mm.modelvoice.q";

        //语音文件名生成
        METHOD_VOICE_FILE_CREATE_NAME = "oz";

        //语音文件路径生成
        METHOD_VOICE_FILE_CREATE_PATH = "getFullPath";

        //生成语音文件时长
        METHOD_VOICE_FILE_LENGTH = "Z";

        //传送语音文件到微信
        METHOD_VOICE_TRANSFER = "Ti";

        //语音、视频发送者发送方法
        METHOD_SENDER_SEND_VOICE_VIDEO = "O";

        //获取source类
        CLASS_SOURCE_MODEL = "com.tencent.mm.model.q";

        //source类中获取source的方法名
        METHOD_SOURCE_MODEL_GET = "Gj";

        //创建发送的视频文件类
        CLASS_CREATE_VIDEO_FILE = "com.tencent.mm.modelvideo.t";

        //创建发送的视频文件名
        METHOD_CREATE_VIDEO_FILE_NAME = "nR";

        //创建发送的视频文件路径
        METHOD_CREATE_VIDEO_FILE_MP4 = "nS";

        //创建发送的视频封面路径
        METHOD_CREATE_VIDEO_FILE_THUMBNAIL = "nT";

        //创建视频文件
        CLASS_CREATE_VIDEO = "com.tencent.mm.modelvideo.u";
        METHOD_CREATE_VIDEO_D = "a";
        METHOD_CREATE_VIDEO_F = "l";
        METHOD_CREATE_VIDEO_LT = "nZ";


        METHOD_GET_TOOL = "Hx";
        METHOD_GET_TOOL2 = "FB";
        FIELD_GET_QUERY_OBJECT = "dXw";

        CLASS_ABOUNT = CLASS_SOURCE_MODEL;
        METHOD_ABOUT_GET_WEIXIN_NUMBER = "Gk";
        METHOD_ABOUT_GET_TALKER = "Gj";
        METHOD_ABOUT_GET_NICK_NAME = "Gl";

        //添加好友
        CLASS_PLUGINSDK_MODEL_M = "com.tencent.mm.pluginsdk.model.m";

        //Hook微信消息
        CLASS_RECEIVE_MESSAGE = "com.tencent.mm.cf.h";

        //*获取目录
        CLASS_KERNEL_PATH = "com.tencent.mm.kernel.g";
        METHDO_KERNEL_GET_CACHE_PATH_OBJECT = "DP";
        FIELD_GET_CACHE_PATH = "dKt";

        //下载图片
        CLASS_IMG_SERVICE = "com.tencent.mm.as.o";
        METHOD_GET_STORE_OBJECT = "OJ";
        METHOD_GET_HD_DOWNLOAD_STATE = "bX";
        FIELD_HD_STATE = "cQK";
        FIELD_IMAGE_ID = "enp";
        METHOD_GET_HD_IMAGE_LOGIC = "OL";
        METHOD_GET_DOWNLOAD_IMAGE_SERVICE = "OK";
        METHOD_DOWNLOAD_HD_TASK = "a";

        //下载小视频
        CLASS_DOWNLOAD_VIDEO = "com.tencent.mm.modelvideo.d";

        //建标签
        CLASS_LABEL_VAR = "com.tencent.mm.plugin.label.b.a";

        //打标签
        CLASS_GET_LABELID_OBJECT = "com.tencent.mm.plugin.label.e";
        METHOD_GET_LABELID_OBJECT = "bdz";
        METHOD_GET_LABELID = "ad";
        CLASS_JOIN_LABELID = "com.tencent.mm.plugin.label.c";
        METHOD_JOIN_LABELID = "bG";
        CLASS_LABEL_OBJECT = "com.tencent.mm.protocal.c.cce";
        FIELD_LABEL_OBJECT_LABEL = "sQu";
        FIELD_LABEL_OBJECT_USERNAME = "hPY";
        CLASS_MODITY_LABEL = "com.tencent.mm.plugin.label.b.d";

        //数据库操作com.tencent.mm.sdk.e.e
        DB_RAW_QUERY = "rawQuery";
        DB_RAW_INSERT = "insert";
        DB_RAW_DELETE = "delete";
        DB_RAW_EXECUTE = "gk";

        //采集好友-附近的人
        CLASS_NEARBY_BY = "com.tencent.mm.plugin.nearby.a.c";
        METHOD_NEARBY_BY = "boe";
        FIELD_NEARBY_TALKER_ID = "hRf";
        FIELD_NEARBY_NICKNAME = "hPY";
        FIELD_NEARBY_LAT = "ffi";
        FIELD_NEARBY_LNG = "ffj";
        FIELD_NEARBY_SIGNATURE = "ffk";
        FIELD_NEARBY_SEX = "ffh";
        FIELD_NEARBY_HEAD_IMAGE = "sLD";

        //自动通过好友
        CLASS_THROUGH_OBJECT = "com.tencent.mm.pluginsdk.model.m";

        //发送链接
        CLASS_URL_IMAGE = "com.tencent.mm.as.c";
        METHOD_URL_IMAGE_PUSH = "g";
        CLASS_WEBPAGE_OBJECT = "com.tencent.mm.opensdk.modelmsg.WXWebpageObject";
        FIELD_WEBPAGE_URL = "webpageUrl";
        CLASS_MEDIA_MESSAGE = "com.tencent.mm.opensdk.modelmsg.WXMediaMessage";
        FIELD_MEDIA_MESSAGE_MEDIA_OBJECT = "mediaObject";
        FIELD_MEDIA_MESSAGE_TITLE = "title";
        FIELD_MEDIA_MESSAGE_DESCRIPTION = "description";
        FIELD_MEDIA_MESSAGE_THUMB_DATA = "thumbData";
        CLASS_URL_MESSAGE = "com.tencent.mm.h.a.pb";
        FIELD_URL_MESSAGE_MSG = "bYE";
        FIELD_URL_MESSAGE_MEDIA = "bRd";
        FIELD_URL_MESSAGE_APP_NAME = "appName";
        FIELD_URL_MESSAGE_TO_USER = "toUser";
        FIELD_URL_MESSAGE_INT = "bYF";
        FIELD_URL_MESSAGE_OWNER_TALKER = "bYG";
        FIELD_URL_MESSAGE_SNSAD = "bYN";
        FIELD_URL_MESSAGE_URL = "bYK";
        CLASS_URL_SENDER_GETTER = "com.tencent.mm.sdk.b.a";
        FIELD_URL_SENDER_GETTER_FIELD = "udP";
        METHOD_URL_SENDER_SEND = "m";

        //群
        CHATROOM_CLASS_PULLFRIEND_ADD_MEMBER = "com.tencent.mm.chatroom.c.e";
        CHAT_ROOM_CLASS_PULLFRIEND_INVITE_MEMBER = "com.tencent.mm.chatroom.c.m";
        CHAT_ROOM_CLASS_CREATE_CHAT_ROOM = "com.tencent.mm.chatroom.c.g";
        CHAT_ROOM_CLASS_DELETE_MEMBER = "com.tencent.mm.chatroom.c.h";

        //修改群名称
        CHAT_ROOM_CLASS_MODEL_C = "com.tencent.mm.model.c";
        CHAT_ROOM_METHOD_MMCORE_INIT = METHOD_GET_TOOL;
        CHAT_ROOM_METHOD_CHECK_MMCORE_INIT = "Hp";
        CHAT_ROOM_NAME_OBJECT_CLASS = "com.tencent.mm.protocal.c.bml";
        CHAT_ROOM_NAME_OBJECT_METHOD_SET = "YI";
        CHAT_ROOM_OBJECT_CLASS = "com.tencent.mm.protocal.c.axc";
        CHAT_ROOM_OBJECT_FIELD_TALKER = "svp";
        CHAT_ROOM_OBJECT_FIELD_NAME = "ttn";
        CHAT_ROOM_CHANGE_NAME_OBJECT_CLASS = "com.tencent.mm.plugin.messenger.foundation.a.a.i.a";
        CHAT_ROOM_GET_FE_METHOD = "Fv";
        CHAT_ROOM_CHANGE_NAME_SEND_METHOD = "b";

        //保存群到通讯录
        CHAT_ROOM_METHOD_GET_FF = "Fw";
        CHAT_ROOM_METHOD_GET_XV = "abl";
        CHAT_ROOM_CLASS_Y_S = "com.tencent.mm.model.s";
        CHAT_ROOM_METHOD_SAVE = "r";

        //修改群公告
        CHAT_ROOM_CLASS_SET_NOTICE = "com.tencent.mm.chatroom.c.o";

        //修改群昵称
        CHAT_ROOM_NICK_PROTOCOL = "com.tencent.mm.protocal.c.awz";
        CHAR_ROOM_FIELD_NICK_PROTOCOL_TALKER = "hPY";
        CHAR_ROOM_FIELD_NICK_PROTOCOL_CHATROOM_TALKER = "svm";
        CHAR_ROOM_FIELD_NICK_PROTOCOL_NICKNAME = "sLC";

        //将消息设置为已读
        MSG_READ_METHOD_Fh = "Fy";
        MSG_READ_METHOD_Fn = "HK";
        MSG_READ_CLASS_AU = "com.tencent.mm.storage.bi";
        MSG_READ_METHOD_AU_B = "d";
        MSG_READ_METHOD_AU_eR = "setStatus";
        MSG_READ_METHOD_Fk = "FB";
        MSG_READ_METHOD_Fk_XH = "abx";
        MSG_READ_METHOD_Fl = "HI";

        //删除好友
        DELETE_FRIEND_MODEL_CLASS = "com.tencent.mm.ay.b";
        DELETE_FRIEND_GA = "FF";
        DELETE_FRIEND_METHOD = "c";
        DELETE_FRIEND_CHAT_METHOD = "abu";
        DELETE_FRIEND_YM_METHOD = "abr";
        DELETE_FRIEND_IN_METHOD = "it";

        //退群
        METHOD_DELETE_CHATROOM_FV = "Fv";
        METHOD_DELETE_CHATROOM_B = "b";
        CLASS_CHATROOM_E_A = "com.tencent.mm.chatroom.e.a";
        METHOD_DELETE_CHATROOM_FB = "FB";
        METHOD_DELETE_CHATROOM_FROM_RCONVERSATION = "abu";
        CLASS_CHAT_ROOM_E_C = "com.tencent.mm.chatroom.e.c";
        METHOD_CHATROOM_INFO = "Dz";
        CLASS_CHATROOM_MEMBERS_LOGIC = "com.tencent.mm.model.m";
        METHOD_DELETE_CHATROOM = "gI";

        //小程序
        APP_BRAND_CLASS_SESSION = "com.tencent.mm.model.u";
        APP_BRAND_METNOD_CREATE_SESSION = "ij";
        APP_BRAND_METHOD_GET_OBJECT = "Hc";
        APP_BRAND_METHOD_GET_B = "v";
        APP_BRAND_METHOD_B_PRE_PUBLISH = "h";

        APP_BRAND_CLASS_MODEL = "com.tencent.mm.ae.g.a";
        APP_BRAND_MODEL_FIELD_TITLE = "title";
        APP_BRAND_MODEL_FIELD_XCXNAME = "bYH";
        APP_BRAND_MODEL_FIELD_TYPE = "dTa";
        APP_BRAND_MODEL_FIELD_10 = "dTg";
        APP_BRAND_MODEL_FIELD_USERNAME = "dSY";
        APP_BRAND_MODEL_FIELD_IMG_PATH = "dTh";
        APP_BRAND_MODEL_FIELD_URL = "dSX";
        APP_BRAND_MODEL_FIELD_GH = "bYG";
        APP_BRAND_MODEL_FIELD_APPID = "dSZ";
        APP_BRAND_MODEL_FIELD_WXAPP_APPID = "bYM";
        APP_BRAND_MODEL_FIELD_URLNAME = "url";

        APP_BRAND_CLASS_QX = "com.tencent.mm.plugin.appbrand.r";
        APP_BRAND_METHOD_QX = "qL";

        APP_BRAND_KERNEL_CLASS = "com.tencent.mm.kernel.g";
        APP_BRAND_KERNEL_METHOD_CREATE_OBJECT = "r";
        APP_BRAND_CLASS_COMPAT = "com.tencent.mm.plugin.appbrand.compat.a.a";
        APP_BRAND_METHOD_SEND = "a";

    }
}
