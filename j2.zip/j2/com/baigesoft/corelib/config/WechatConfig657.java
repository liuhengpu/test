package com.baigesoft.corelib.config;

/**
 * Created by Dawei on 22/05/2017.
 */

public class WechatConfig657 extends WechatConfig {

    public WechatConfig657() {

        //消息、图片、语音、视频消息发送类
        CLASS_SEND_MODEL = "com.tencent.mm.model.al";

        //获取文本、图片消息发送者对象From[CLASS_SEND_MODEL]
        METHOD_SEND_MODEL_GET_MESSAGE_SENDER = "vM";

        //消息发送者发送方法
        METHOD_SENDER_SEND = "d";

        //消息对象类
        CLASS_SEND_MESSAGE_MODEL_MULTI = "com.tencent.mm.modelmulti.j";

        //图片消息对象类
        CLASS_SEND_IMAGE_MODEL_MULTI = "com.tencent.mm.ad.k";

        //获取语音、视频消息发送者对象
        METHOD_SEND_MODEL_GET_VOICE_SENDER = "vO";

        //语音文件生成类
        CLASS_VOICE_CREATE = "com.tencent.mm.modelvoice.m";

        CLASS_VOICE_FILE_CREATE = "com.tencent.mm.modelvoice.q";

        //语音文件名生成
        METHOD_VOICE_FILE_CREATE_NAME = "lO";

        //语音文件路径生成
        METHOD_VOICE_FILE_CREATE_PATH = "ja";

        //生成语音文件时长
        METHOD_VOICE_FILE_LENGTH = "g";

        //传送语音文件到微信
        METHOD_VOICE_TRANSFER = "Mb";

        //语音、视频发送者发送方法
        METHOD_SENDER_SEND_VOICE_VIDEO = "x";

        //获取source类
        CLASS_SOURCE_MODEL = "com.tencent.mm.model.l";

        //source类中获取source的方法名
        METHOD_SOURCE_MODEL_GET = "xO";

        //创建发送的视频文件类
        CLASS_CREATE_VIDEO_FILE = "com.tencent.mm.as.o";

        //创建发送的视频文件名
        METHOD_CREATE_VIDEO_FILE_NAME = "lk";

        //创建发送的视频文件路径
        METHOD_CREATE_VIDEO_FILE_MP4 = "ll";

        //创建发送的视频封面路径
        METHOD_CREATE_VIDEO_FILE_THUMBNAIL = "lm";

        //创建视频文件
        CLASS_CREATE_VIDEO = "com.tencent.mm.as.p";
        METHOD_CREATE_VIDEO_D = "d";
        METHOD_CREATE_VIDEO_F = "f";
        METHOD_CREATE_VIDEO_LT = "lt";


        METHOD_GET_TOOL = "zg";
        METHOD_GET_TOOL2 = "wY";
        FIELD_GET_QUERY_OBJECT = "gWR";

        CLASS_ABOUNT = "com.tencent.mm.model.l";
        METHOD_ABOUT_GET_WEIXIN_NUMBER = "xP";
        METHOD_ABOUT_GET_TALKER = "xO";
        METHOD_ABOUT_GET_NICK_NAME = "xQ";

        //添加好友
        CLASS_PLUGINSDK_MODEL_M = "com.tencent.mm.pluginsdk.model.m";

        //Hook微信消息
        CLASS_RECEIVE_MESSAGE = "com.tencent.mm.bf.g";

        //获取目录
        CLASS_KERNEL_PATH = "com.tencent.mm.kernel.h";
        METHDO_KERNEL_GET_CACHE_PATH_OBJECT = "vK";
        FIELD_GET_CACHE_PATH = "gYS";

        //下载图片
        CLASS_IMG_SERVICE = "com.tencent.mm.ad.n";
        METHOD_GET_STORE_OBJECT = "Hc";
        METHOD_GET_HD_DOWNLOAD_STATE = "aj";
        FIELD_HD_STATE = "gBq";
        FIELD_IMAGE_ID = "hBf";
        METHOD_GET_HD_IMAGE_LOGIC = "He";
        METHOD_GET_DOWNLOAD_IMAGE_SERVICE = "Hd";
        METHOD_DOWNLOAD_HD_TASK = "a";

        //下载小视频
        CLASS_DOWNLOAD_VIDEO = "com.tencent.mm.as.b";

        //建标签
        CLASS_LABEL_VAR = "com.tencent.mm.plugin.label.a.a";

        //打标签
        CLASS_GET_LABELID_OBJECT = "com.tencent.mm.plugin.label.e";
        METHOD_GET_LABELID_OBJECT = "azE";
        METHOD_GET_LABELID = "X";
        CLASS_JOIN_LABELID = "com.tencent.mm.plugin.label.c";
        METHOD_JOIN_LABELID = "aF";
        CLASS_LABEL_OBJECT = "com.tencent.mm.protocal.c.bfd";
        FIELD_LABEL_OBJECT_LABEL = "sCi";
        FIELD_LABEL_OBJECT_USERNAME = "username";
        CLASS_MODITY_LABEL = "com.tencent.mm.plugin.label.a.d";

        //数据库操作com.tencent.mm.sdk.d.e
        DB_RAW_QUERY = "rawQuery";
        DB_RAW_INSERT = "insert";
        DB_RAW_DELETE = "delete";
        DB_RAW_EXECUTE = "ea";

        //采集好友-附近的人
        CLASS_NEARBY_BY = "com.tencent.mm.plugin.nearby.a.d";
        METHOD_NEARBY_BY = "aHG";
        FIELD_NEARBY_TALKER_ID = "jfs";
        FIELD_NEARBY_NICKNAME = "lwo";
        FIELD_NEARBY_LAT = "hwP";
        FIELD_NEARBY_LNG = "hwQ";
        FIELD_NEARBY_SIGNATURE = "hwR";
        FIELD_NEARBY_SEX = "hwO";
        FIELD_NEARBY_HEAD_IMAGE = "rNp";
    }
}
