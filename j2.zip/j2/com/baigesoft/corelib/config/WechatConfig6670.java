package com.baigesoft.corelib.config;

/**
 * Created by Dawei on 22/05/2017.
 */

public class WechatConfig6670 extends WechatConfig {

    public WechatConfig6670() {

        //*消息、图片、语音、视频消息发送类
        CLASS_SEND_MODEL = "com.tencent.mm.model.au";

        //*获取文本、图片消息发送者对象From[CLASS_SEND_MODEL]
        METHOD_SEND_MODEL_GET_MESSAGE_SENDER = "DF";

        //*消息发送者发送方法
        METHOD_SENDER_SEND = "d";

        //*消息对象类
        CLASS_SEND_MESSAGE_MODEL_MULTI = "com.tencent.mm.modelmulti.i";

        //*图片消息对象类
        CLASS_SEND_IMAGE_MODEL_MULTI = "com.tencent.mm.ak.l";

        //*获取语音、视频消息发送者对象
        METHOD_SEND_MODEL_GET_VOICE_SENDER = "Em";

        //*语音文件生成类
        CLASS_VOICE_CREATE = "com.tencent.mm.modelvoice.m";

        //*
        CLASS_VOICE_FILE_CREATE = "com.tencent.mm.modelvoice.q";

        //*语音文件名生成
        METHOD_VOICE_FILE_CREATE_NAME = "om";

        //*语音文件路径生成
        METHOD_VOICE_FILE_CREATE_PATH = "getFullPath";

        //*生成语音文件时长
        METHOD_VOICE_FILE_LENGTH = "X";

        //*传送语音文件到微信
        METHOD_VOICE_TRANSFER = "TK";

        //*语音、视频发送者发送方法
        METHOD_SENDER_SEND_VOICE_VIDEO = "H";

        //*获取source类
        CLASS_SOURCE_MODEL = "com.tencent.mm.model.q";

        //*source类中获取source的方法名
        METHOD_SOURCE_MODEL_GET = "GF";

        //*创建发送的视频文件类
        CLASS_CREATE_VIDEO_FILE = "com.tencent.mm.modelvideo.s";    //*

        //*创建发送的视频文件名
        METHOD_CREATE_VIDEO_FILE_NAME = "nJ";

        //*创建发送的视频文件路径
        METHOD_CREATE_VIDEO_FILE_MP4 = "nK";

        //*创建发送的视频封面路径
        METHOD_CREATE_VIDEO_FILE_THUMBNAIL = "nL";

        //*创建视频文件
        CLASS_CREATE_VIDEO = "com.tencent.mm.modelvideo.t"; //*
        METHOD_CREATE_VIDEO_D = "a";    //*
        METHOD_CREATE_VIDEO_F = "l";    //*
        METHOD_CREATE_VIDEO_LT = "nR";  //*


        METHOD_GET_TOOL = "HU"; //*
        METHOD_GET_TOOL2 = "FR";    //*
        FIELD_GET_QUERY_OBJECT = "diF"; //*

        CLASS_ABOUNT = "com.tencent.mm.model.q";    //*
        METHOD_ABOUT_GET_WEIXIN_NUMBER = "GG";  //*
        METHOD_ABOUT_GET_TALKER = "GF"; //*
        METHOD_ABOUT_GET_NICK_NAME = "GH";  //*

        //*添加好友
        CLASS_PLUGINSDK_MODEL_M = "com.tencent.mm.pluginsdk.model.m";

        //*Hook微信消息
        CLASS_RECEIVE_MESSAGE = "com.tencent.mm.bt.h";

        //*获取目录
        CLASS_KERNEL_PATH = "com.tencent.mm.kernel.g";  //*
        METHDO_KERNEL_GET_CACHE_PATH_OBJECT = "Ei"; //*
        FIELD_GET_CACHE_PATH = "dqp";   //*

        //*下载图片
        CLASS_IMG_SERVICE = "com.tencent.mm.ak.o";  //*
        METHOD_GET_STORE_OBJECT = "Pf"; //*
        METHOD_GET_HD_DOWNLOAD_STATE = "bq";    //*
        FIELD_HD_STATE = "cGG"; //*
        FIELD_IMAGE_ID = "dTK"; //*
        METHOD_GET_HD_IMAGE_LOGIC = "Ph";   //*
        METHOD_GET_DOWNLOAD_IMAGE_SERVICE = "Pg";   //*
        METHOD_DOWNLOAD_HD_TASK = "a";  //*

        //*下载小视频
        CLASS_DOWNLOAD_VIDEO = "com.tencent.mm.modelvideo.d";

        //*建标签
        CLASS_LABEL_VAR = "com.tencent.mm.plugin.label.b.a";    //*

        //*打标签
        CLASS_GET_LABELID_OBJECT = "com.tencent.mm.plugin.label.e"; //*
        METHOD_GET_LABELID_OBJECT = "aYJ";  //*
        METHOD_GET_LABELID = "ab";  //*
        CLASS_JOIN_LABELID = "com.tencent.mm.plugin.label.c";   //*
        METHOD_JOIN_LABELID = "bq";     //*
        CLASS_LABEL_OBJECT = "com.tencent.mm.protocal.c.bjw";   //*
        FIELD_LABEL_OBJECT_LABEL = "sjJ";   //*
        FIELD_LABEL_OBJECT_USERNAME = "rlo";    //*
        CLASS_MODITY_LABEL = "com.tencent.mm.plugin.label.b.d"; //*

        //*数据库操作com.tencent.mm.sdk.e.e
        DB_RAW_QUERY = "rawQuery";  //*
        DB_RAW_INSERT = "insert";   //*
        DB_RAW_DELETE = "delete";   //*
        DB_RAW_EXECUTE = "fV";      //*

        //*采集好友-附近的人
        CLASS_NEARBY_BY = "com.tencent.mm.plugin.nearby.a.c";   //*
        METHOD_NEARBY_BY = "biS";   //*
        FIELD_NEARBY_TALKER_ID = "hcS"; //*
        FIELD_NEARBY_NICKNAME = "hbL";  //*
        FIELD_NEARBY_LAT = "eJI";   //*
        FIELD_NEARBY_LNG = "eJJ";   //*
        FIELD_NEARBY_SIGNATURE = "eJK"; //*
        FIELD_NEARBY_SEX = "eJH";   //*
        FIELD_NEARBY_HEAD_IMAGE = "rqZ";    //*

        //*自动通过好友
        CLASS_THROUGH_OBJECT = "com.tencent.mm.pluginsdk.model.m";  //*

        //*发送链接
        CLASS_URL_IMAGE = "com.tencent.mm.ak.c";    //*
        METHOD_URL_IMAGE_PUSH = "h";    //*
        CLASS_WEBPAGE_OBJECT = "com.tencent.mm.opensdk.modelmsg.WXWebpageObject";   //*
        FIELD_WEBPAGE_URL = "webpageUrl";   //*
        CLASS_MEDIA_MESSAGE = "com.tencent.mm.opensdk.modelmsg.WXMediaMessage"; //*
        FIELD_MEDIA_MESSAGE_MEDIA_OBJECT = "mediaObject";   //*
        FIELD_MEDIA_MESSAGE_TITLE = "title";    //*
        FIELD_MEDIA_MESSAGE_DESCRIPTION = "description";    //*
        FIELD_MEDIA_MESSAGE_THUMB_DATA = "thumbData";   //*
        CLASS_URL_MESSAGE = "com.tencent.mm.g.a.ot";    //*
        FIELD_URL_MESSAGE_MSG = "bZE";      //*
        FIELD_URL_MESSAGE_MEDIA = "bSg";    //*
        FIELD_URL_MESSAGE_APP_NAME = "appName"; //*
        FIELD_URL_MESSAGE_TO_USER = "toUser";   //*
        FIELD_URL_MESSAGE_INT = "bZF";  //*
        FIELD_URL_MESSAGE_OWNER_TALKER = "bZG"; //*
        FIELD_URL_MESSAGE_SNSAD = "bZN";    //*
        FIELD_URL_MESSAGE_URL = "bZK";  //*
        CLASS_URL_SENDER_GETTER = "com.tencent.mm.sdk.b.a"; //*
        FIELD_URL_SENDER_GETTER_FIELD = "sFg";  //*
        METHOD_URL_SENDER_SEND = "m";   //*

        //*群
        CHATROOM_CLASS_PULLFRIEND_ADD_MEMBER = "com.tencent.mm.plugin.chatroom.d.d";    //*
        CHAT_ROOM_CLASS_PULLFRIEND_INVITE_MEMBER = "com.tencent.mm.plugin.chatroom.d.k";    //*
        CHAT_ROOM_CLASS_CREATE_CHAT_ROOM = "com.tencent.mm.plugin.chatroom.d.f";    //*
        CHAT_ROOM_CLASS_DELETE_MEMBER = "com.tencent.mm.plugin.chatroom.d.g";   //*

        //*修改群名称
        CHAT_ROOM_CLASS_MODEL_C = "com.tencent.mm.model.c"; //*
        CHAT_ROOM_METHOD_MMCORE_INIT = "HU";    //*
        CHAT_ROOM_METHOD_CHECK_MMCORE_INIT = "HM";  //*
        CHAT_ROOM_NAME_OBJECT_CLASS = "com.tencent.mm.protocal.c.bhz";  //*
        CHAT_ROOM_NAME_OBJECT_METHOD_SET = "VO";    //*
        CHAT_ROOM_OBJECT_CLASS = "com.tencent.mm.protocal.c.aud";   //*
        CHAT_ROOM_OBJECT_FIELD_TALKER = "rbR";  //*
        CHAT_ROOM_OBJECT_FIELD_NAME = "rXc";    //*
        CHAT_ROOM_CHANGE_NAME_OBJECT_CLASS = "com.tencent.mm.plugin.messenger.foundation.a.a.h.a";  //*
        CHAT_ROOM_GET_FE_METHOD = "FQ"; //*
        CHAT_ROOM_CHANGE_NAME_SEND_METHOD = "b";    //*

        //*保存群到通讯录
        CHAT_ROOM_METHOD_GET_FF = "FR"; //*
        CHAT_ROOM_METHOD_GET_XV = "Yg"; //*
        CHAT_ROOM_CLASS_Y_S = "com.tencent.mm.model.s"; //*
        CHAT_ROOM_METHOD_SAVE = "q";    //*

        //*修改群公告
        CHAT_ROOM_CLASS_SET_NOTICE = "com.tencent.mm.plugin.chatroom.d.m";  //*

        //*修改群昵称
        CHAT_ROOM_NICK_PROTOCOL = "com.tencent.mm.protocal.c.aua";  //*
        CHAR_ROOM_FIELD_NICK_PROTOCOL_TALKER = "hbL";   //*
        CHAR_ROOM_FIELD_NICK_PROTOCOL_CHATROOM_TALKER = "rvj";  //*
        CHAR_ROOM_FIELD_NICK_PROTOCOL_NICKNAME = "rqY"; //*

        //*将消息设置为已读
        MSG_READ_METHOD_Fh = "FT";  //*
        MSG_READ_METHOD_Fn = "GO";  //*
        MSG_READ_CLASS_AU = "com.tencent.mm.storage.bd";    //*
        MSG_READ_METHOD_AU_B = "d"; //*
        MSG_READ_METHOD_AU_eR = "setStatus";    //*
        MSG_READ_METHOD_Fk = "FW";  //*
        MSG_READ_METHOD_Fk_XH = "Ys";   //*
        MSG_READ_METHOD_Fl = "GM";      //*

        //删除好友
        DELETE_FRIEND_MODEL_CLASS = "com.tencent.mm.aq.c";
        DELETE_FRIEND_GA = "Ga";
        DELETE_FRIEND_METHOD = "c";
        DELETE_FRIEND_CHAT_METHOD = "Yp";
        DELETE_FRIEND_YM_METHOD = "Ym";
        DELETE_FRIEND_IN_METHOD = "in";

        //小程序
        APP_BRAND_CLASS_SESSION = "com.tencent.mm.model.u";
        APP_BRAND_METNOD_CREATE_SESSION = "ic";
        APP_BRAND_METHOD_GET_OBJECT = "Hx";
        APP_BRAND_METHOD_GET_B = "v";
        APP_BRAND_METHOD_B_PRE_PUBLISH = "p";

        APP_BRAND_CLASS_MODEL = "com.tencent.mm.y.g.a";
        APP_BRAND_MODEL_FIELD_TITLE = "title";
        APP_BRAND_MODEL_FIELD_XCXNAME = "bZH";
        APP_BRAND_MODEL_FIELD_TYPE = "dyU";
        APP_BRAND_MODEL_FIELD_10 = "dza";
        APP_BRAND_MODEL_FIELD_USERNAME = "dyS";
        APP_BRAND_MODEL_FIELD_IMG_PATH = "dzb";
        APP_BRAND_MODEL_FIELD_URL = "dyR";
        APP_BRAND_MODEL_FIELD_GH = "bZG";
        APP_BRAND_MODEL_FIELD_APPID = "dyT";
        APP_BRAND_MODEL_FIELD_WXAPP_APPID = "bZM";
        APP_BRAND_MODEL_FIELD_URLNAME = "url";

        APP_BRAND_CLASS_QX = "com.tencent.mm.plugin.appbrand.n";
        APP_BRAND_METHOD_QX = "qx";

        APP_BRAND_KERNEL_CLASS = "com.tencent.mm.kernel.g";
        APP_BRAND_KERNEL_METHOD_CREATE_OBJECT = "l";
        APP_BRAND_CLASS_COMPAT = "com.tencent.mm.plugin.appbrand.compat.a.a";
        APP_BRAND_METHOD_SEND = "a";

    }
}
