package com.baigesoft.corelib.config;

/**
 * Created by Dawei on 23/12/2017.
 */

public abstract class WechatConfig {

    //消息、图片、语音、视频消息发送类
    public static String CLASS_SEND_MODEL = "";

    //获取文本、图片消息发送者对象From[CLASS_SEND_MODEL]
    public static String METHOD_SEND_MODEL_GET_MESSAGE_SENDER = "";

    //消息发送者发送方法
    public static String METHOD_SENDER_SEND = "";

    //消息对象类
    public static String CLASS_SEND_MESSAGE_MODEL_MULTI = "";

    //图片消息对象类
    public static String CLASS_SEND_IMAGE_MODEL_MULTI = "";

    //获取语音、视频消息发送者对象
    public static String METHOD_SEND_MODEL_GET_VOICE_SENDER = "";
    public static String FIELD_GET_VOICE_SENDER_OBJECT = "";

    //语音文件生成类
    public static String CLASS_VOICE_CREATE = "";

    public static String CLASS_VOICE_FILE_CREATE = "";

    //语音文件名生成
    public static String METHOD_VOICE_FILE_CREATE_NAME = "";

    //语音文件路径生成
    public static String METHOD_VOICE_FILE_CREATE_PATH = "";

    //生成语音文件时长
    public static String METHOD_VOICE_FILE_LENGTH = "";

    //传送语音文件到微信
    public static String METHOD_VOICE_TRANSFER = "";

    //语音、视频发送者发送方法
    public static String METHOD_SENDER_SEND_VOICE_VIDEO = "";

    //获取source类
    public static String CLASS_SOURCE_MODEL = "";

    //source类中获取source的方法名
    public static String METHOD_SOURCE_MODEL_GET = "";

    //创建发送的视频文件类
    public static String CLASS_CREATE_VIDEO_FILE = "";

    //创建发送的视频文件名
    public static String METHOD_CREATE_VIDEO_FILE_NAME = "";

    //创建发送的视频文件路径
    public static String METHOD_CREATE_VIDEO_FILE_MP4 = "";

    //创建发送的视频封面路径
    public static String METHOD_CREATE_VIDEO_FILE_THUMBNAIL = "";

    //创建视频文件
    public static String CLASS_CREATE_VIDEO = "";
    public static String METHOD_CREATE_VIDEO_D = "";
    public static String METHOD_CREATE_VIDEO_F = "";
    public static String METHOD_CREATE_VIDEO_LT = "";


    public static String METHOD_GET_TOOL = "";
    public static String METHOD_GET_TOOL2 = "";
    public static String FIELD_GET_QUERY_OBJECT = "";

    public static String CLASS_ABOUNT = "";
    public static String METHOD_ABOUT_GET_WEIXIN_NUMBER = "";
    public static String METHOD_ABOUT_GET_TALKER = "";
    public static String METHOD_ABOUT_GET_NICK_NAME = "";

    //添加好友
    public static String CLASS_PLUGINSDK_MODEL_M = "";

    //Hook微信消息
    public static String CLASS_RECEIVE_MESSAGE = "";

    //获取目录
    public static String CLASS_KERNEL_PATH = "";
    public static String METHDO_KERNEL_GET_CACHE_PATH_OBJECT = "";
    public static String FIELD_GET_CACHE_PATH = "";

    //下载图片
    public static String CLASS_IMG_SERVICE = "";
    public static String METHOD_GET_STORE_OBJECT = "";
    public static String METHOD_GET_HD_DOWNLOAD_STATE = "";
    public static String FIELD_HD_STATE = "";
    public static String FIELD_IMAGE_ID = "";
    public static String METHOD_GET_HD_IMAGE_LOGIC = "";
    public static String METHOD_GET_DOWNLOAD_IMAGE_SERVICE = "";
    public static String METHOD_DOWNLOAD_HD_TASK = "";

    //下载小视频
    public static String CLASS_DOWNLOAD_VIDEO = "";

    //建标签
    public static String CLASS_LABEL_VAR = "";

    //打标签
    public static String CLASS_GET_LABELID_OBJECT = "";
    public static String METHOD_GET_LABELID_OBJECT = "";
    public static String METHOD_GET_LABELID = "";
    public static String CLASS_JOIN_LABELID = "";
    public static String METHOD_JOIN_LABELID = "";
    public static String CLASS_LABEL_OBJECT = "";
    public static String FIELD_LABEL_OBJECT_LABEL = "";
    public static String FIELD_LABEL_OBJECT_USERNAME = "";
    public static String CLASS_MODITY_LABEL = "";

    //数据库操作com.tencent.mm.sdk.d.e
    public static String DB_RAW_QUERY = "rawQuery";
    public static String DB_RAW_INSERT = "insert";
    public static String DB_RAW_DELETE = "delete";
    public static String DB_RAW_EXECUTE = "";

    //采集好友-附近的人
    public static String CLASS_NEARBY_BY = "";
    public static String METHOD_NEARBY_BY = "";
    public static String FIELD_NEARBY_TALKER_ID = "";
    public static String FIELD_NEARBY_NICKNAME = "";
    public static String FIELD_NEARBY_LAT = "";
    public static String FIELD_NEARBY_LNG = "";
    public static String FIELD_NEARBY_SIGNATURE = "";
    public static String FIELD_NEARBY_SEX = "";
    public static String FIELD_NEARBY_HEAD_IMAGE = "";

    //自动通过好友
    public static String CLASS_THROUGH_OBJECT = "";

    //发送链接
    public static String CLASS_URL_IMAGE = "";
    public static String METHOD_URL_IMAGE_PUSH = "";
    public static String CLASS_WEBPAGE_OBJECT = "";
    public static String FIELD_WEBPAGE_URL = "";
    public static String CLASS_MEDIA_MESSAGE = "";
    public static String FIELD_MEDIA_MESSAGE_MEDIA_OBJECT = "";
    public static String FIELD_MEDIA_MESSAGE_TITLE = "";
    public static String FIELD_MEDIA_MESSAGE_DESCRIPTION = "";
    public static String FIELD_MEDIA_MESSAGE_THUMB_DATA = "";
    public static String CLASS_URL_MESSAGE = "";
    public static String FIELD_URL_MESSAGE_MSG = "";
    public static String FIELD_URL_MESSAGE_MEDIA = "";
    public static String FIELD_URL_MESSAGE_APP_NAME = "";
    public static String FIELD_URL_MESSAGE_TO_USER = "";
    public static String FIELD_URL_MESSAGE_INT = "";
    public static String FIELD_URL_MESSAGE_OWNER_TALKER = "";
    public static String FIELD_URL_MESSAGE_SNSAD = "";
    public static String FIELD_URL_MESSAGE_URL = "";
    public static String CLASS_URL_SENDER_GETTER = "";
    public static String FIELD_URL_SENDER_GETTER_FIELD = "";
    public static String METHOD_URL_SENDER_SEND = "";

    //群
    public static String CHATROOM_CLASS_PULLFRIEND_ADD_MEMBER = "";
    public static String CHAT_ROOM_CLASS_PULLFRIEND_INVITE_MEMBER = "";
    public static String CHAT_ROOM_CLASS_CREATE_CHAT_ROOM = "";
    public static String CHAT_ROOM_CLASS_DELETE_MEMBER = "";

    //修改群名称
    public static String CHAT_ROOM_CLASS_MODEL_C = "";
    public static String CHAT_ROOM_METHOD_MMCORE_INIT = "";
    public static String CHAT_ROOM_METHOD_CHECK_MMCORE_INIT = "";
    public static String CHAT_ROOM_NAME_OBJECT_CLASS = "";
    public static String CHAT_ROOM_NAME_OBJECT_METHOD_SET = "";
    public static String CHAT_ROOM_OBJECT_CLASS = "";
    public static String CHAT_ROOM_OBJECT_FIELD_TALKER = "";
    public static String CHAT_ROOM_OBJECT_FIELD_NAME = "";
    public static String CHAT_ROOM_CHANGE_NAME_OBJECT_CLASS = "";
    public static String CHAT_ROOM_GET_FE_METHOD = "";
    public static String CHAT_ROOM_CHANGE_NAME_SEND_METHOD = "";

    //修改群公告
    public static String CHAT_ROOM_CLASS_SET_NOTICE = "";


    //保存群到通讯录
    public static String CHAT_ROOM_METHOD_GET_FF = "";
    public static String CHAT_ROOM_METHOD_GET_XV = "";
    public static String CHAT_ROOM_CLASS_Y_S = "";
    public static String CHAT_ROOM_METHOD_SAVE = "";

    //修改群昵称
    public static String CHAT_ROOM_NICK_PROTOCOL = "";
    public static String CHAR_ROOM_FIELD_NICK_PROTOCOL_TALKER = "";
    public static String CHAR_ROOM_FIELD_NICK_PROTOCOL_CHATROOM_TALKER = "";
    public static String CHAR_ROOM_FIELD_NICK_PROTOCOL_NICKNAME = "";

    //将消息设置为已读
    public static String MSG_READ_METHOD_Fh = "";
    public static String MSG_READ_METHOD_Fn = "";
    public static String MSG_READ_CLASS_AU = "";
    public static String MSG_READ_METHOD_AU_B = "";
    public static String MSG_READ_METHOD_AU_eR = "";
    public static String MSG_READ_METHOD_Fk = "";
    public static String MSG_READ_METHOD_Fk_XH = "";
    public static String MSG_READ_METHOD_Fl = "";

    //删除好友
    public static String DELETE_FRIEND_MODEL_CLASS = "";
    public static String DELETE_FRIEND_GA = "";
    public static String DELETE_FRIEND_METHOD = "";
    public static String DELETE_FRIEND_CHAT_METHOD = "";
    public static String DELETE_FRIEND_YM_METHOD = "";
    public static String DELETE_FRIEND_IN_METHOD = "";

    //退群
    public static String METHOD_DELETE_CHATROOM_FV = "";
    public static String METHOD_DELETE_CHATROOM_B = "";
    public static String CLASS_CHATROOM_E_A = "";
    public static String METHOD_DELETE_CHATROOM_FB = "";
    public static String METHOD_DELETE_CHATROOM_FROM_RCONVERSATION = "";
    public static String CLASS_CHAT_ROOM_E_C = "";
    public static String METHOD_CHATROOM_INFO = "";
    public static String CLASS_CHATROOM_MEMBERS_LOGIC = "";
    public static String METHOD_DELETE_CHATROOM = "";

    //小程序
    public static String APP_BRAND_CLASS_SESSION = "";
    public static String APP_BRAND_METNOD_CREATE_SESSION = "";
    public static String APP_BRAND_METHOD_GET_OBJECT = "";
    public static String APP_BRAND_METHOD_GET_B = "";
    public static String APP_BRAND_METHOD_B_PRE_PUBLISH = "";

    public static String APP_BRAND_CLASS_MODEL = "";
    public static String APP_BRAND_MODEL_FIELD_TITLE = "";
    public static String APP_BRAND_MODEL_FIELD_XCXNAME = "";
    public static String APP_BRAND_MODEL_FIELD_TYPE = "";
    public static String APP_BRAND_MODEL_FIELD_10 = "";
    public static String APP_BRAND_MODEL_FIELD_USERNAME = "";
    public static String APP_BRAND_MODEL_FIELD_IMG_PATH = "";
    public static String APP_BRAND_MODEL_FIELD_URL = "";
    public static String APP_BRAND_MODEL_FIELD_GH = "";
    public static String APP_BRAND_MODEL_FIELD_APPID = "";
    public static String APP_BRAND_MODEL_FIELD_WXAPP_APPID = "";
    public static String APP_BRAND_MODEL_FIELD_URLNAME = "";

    public static String APP_BRAND_CLASS_QX = "";
    public static String APP_BRAND_METHOD_QX = "";

    public static String APP_BRAND_KERNEL_CLASS = "";
    public static String APP_BRAND_KERNEL_METHOD_CREATE_OBJECT = "";
    public static String APP_BRAND_CLASS_COMPAT = "";
    public static String APP_BRAND_METHOD_SEND = "";


    public static void loadConfig(String version) {
        if (version.equals("6.5.7")) {
            new WechatConfig657();
        } else if (version.equals("6.5.23")) {
            new WechatConfig6523();
        } else if (version.equals("6.6.3")) {
            new WechatConfig6630();
        } else if (version.equals("6.6.5")) {
            new WechatConfig6650();
        } else if (version.equals("6.6.6")) {
            new WechatConfig6660();
        } else if (version.equals("6.6.7")) {
            new WechatConfig6670();
        } else if (version.equals("6.7.2")) {
            new WechatConfig6720();
        } else if (version.equals("6.7.3")) {
            new WechatConfig6730();
        } else if (version.equals("7.0.0")) {
            new WechatConfig7000();
        } else if(version.equals("7.0.3")){
            new WechatConfig7030();
        }
    }

}
