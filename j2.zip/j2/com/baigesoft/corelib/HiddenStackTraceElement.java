package com.baigesoft.corelib;

import java.util.LinkedHashMap;

import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedHelpers;

/**
 * 躲避StackTraceElement方式的检测xposed
 * Created by Dawei on 10/02/2018.
 */
public class HiddenStackTraceElement {

    public void antiDetectXposed() {
        XposedHelpers.findAndHookMethod(Thread.class, "getStackTrace", new Object[0], new hook());
        XposedHelpers.findAndHookMethod(Throwable.class, "getStackTrace", new Object[0], new hook());
    }

    public class hook extends XC_MethodHook {
        @Override
        protected void afterHookedMethod(MethodHookParam param) throws Throwable {
            super.afterHookedMethod(param);
            if (param.getResult() instanceof StackTraceElement[]) {
                StackTraceElement[] trace = (StackTraceElement[]) param.getResult();
                LinkedHashMap map = new LinkedHashMap();
                int i = 0;
                for (StackTraceElement st : trace) {
                    if (!st.getClassName().equals("de.robv.android.xposed.XposedBridge")) {
                        map.put(i, st);
                        i++;
                    }
                }
                StackTraceElement[] newTrace = new StackTraceElement[i];
                for (int j = 0; j < i; j++) {
                    newTrace[j] = (StackTraceElement) map.get(j);
                }
                param.setResult((StackTraceElement[]) newTrace);
            }
        }

        @Override
        protected void beforeHookedMethod(MethodHookParam param) throws Throwable {
            super.beforeHookedMethod(param);
        }
    }

}
