package vicmob.micropowder.ui.activity;

import vicmob.micropowder.base.BaseActivity;

/**
 * Created by Eren on 2017/6/23.
 * <p>
 * 问候语
 */
public class GreetingActivity extends BaseActivity {

}
