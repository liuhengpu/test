package vicmob.micropowder.base;

/**
 * 从网络上加载数据的接口
 * 加载数据的方法
 */
public interface BaseLoadNetDataOperator {

    void loadNetData();
}
