package vicmob.micropowder.config;

/**
 * Created by Eren on 2017/7/13.
 * <p/>
 * 删除单个条目接口
 */
public interface Delete {
    void Delete(int position);
}
