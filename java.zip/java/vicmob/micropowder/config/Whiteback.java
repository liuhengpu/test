package vicmob.micropowder.config;

/**
 * Created by sanmu on 2016/10/13 0013.
 * <p/>
 * 自定义对话框接口
 */
public interface Whiteback {
    void WeChat();

    void QQ();

    void Cancel();
}
