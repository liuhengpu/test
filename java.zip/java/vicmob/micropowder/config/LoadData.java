package vicmob.micropowder.config;

/**
 * Created by Eren on 2017/7/13.
 * <p/>
 * 网络数据接口
 */
public interface LoadData {
    void loadAddressData();

    void loadCityData();
}
